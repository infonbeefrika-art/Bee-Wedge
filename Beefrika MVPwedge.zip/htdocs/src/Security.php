<?php
declare(strict_types=1);

namespace Beefrika;

final class Security
{
    private const ID_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no I, L, O, 0, 1

    public static function secret(): string
    {
        $s = Env::need('OTP_HMAC_SECRET');
        if (strlen($s) < 32) {
            throw new \RuntimeException('OTP_HMAC_SECRET must be at least 32 characters');
        }
        return $s;
    }

    public static function hmac(string $data): string
    {
        return hash_hmac('sha256', $data, self::secret());
    }

    /** Raw IPs are not stored; only a keyed hash. */
    public static function ipHash(string $ip): string
    {
        return self::hmac('ip|' . $ip);
    }

    public static function newToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    public static function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }

    public static function newBeefrikaId(): string
    {
        $out = '';
        $max = strlen(self::ID_ALPHABET) - 1;
        for ($i = 0; $i < 6; $i++) {
            $out .= self::ID_ALPHABET[random_int(0, $max)];
        }
        return 'BF-' . $out;
    }

    /** Returns an error message, or null if the password is acceptable. */
    public static function passwordProblem(string $password, string $phone): ?string
    {
        $len = mb_strlen($password);
        if ($len < 8) {
            return 'Password must be at least 8 characters.';
        }
        if ($len > 128) {
            return 'Password is too long.';
        }
        $digits = preg_replace('/\D/', '', $phone) ?? '';
        $last10 = substr($digits, -10);
        if (in_array($password, [$digits, $last10, '0' . $last10], true)) {
            return 'Do not use your phone number as your password.';
        }
        if (count(array_unique(mb_str_split($password))) < 3) {
            return 'Choose a password that is harder to guess.';
        }
        $weak = ['password', '12345678', '123456789', '1234567890', 'qwertyui', 'password1', 'beefrika', 'abcd1234', '11111111', '00000000'];
        if (in_array(strtolower($password), $weak, true)) {
            return 'Choose a password that is harder to guess.';
        }
        return null;
    }
}
