<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Hiring fee = round100( round100(band base x category factor) x engagement multiplier ).
 * Engagement types at launch: short_gig (0.5x) and contract (1x). Permanent hires are not offered yet.
 * Base amounts and factors live in the database and are empty until pricing is set, so no quote is shown by default.
 */
final class FeeCalculator
{
    public function __construct(private PDO $db)
    {
    }

    public static function round100(float $value): int
    {
        return (int)(round($value / 100) * 100);
    }

    /** @return array{base:int,fee:int,multiplier:float} */
    public static function compute(int $baseNgn, float $categoryFactor, float $multiplier): array
    {
        $base = self::round100($baseNgn * $categoryFactor);
        return ['base' => $base, 'fee' => self::round100($base * $multiplier), 'multiplier' => $multiplier];
    }

    /** @return array<string,array{base:int,fee:int,multiplier:float}>|null null when pricing is not configured */
    public function quotesFor(?int $tradeId, ?string $band): ?array
    {
        if (!$tradeId || !$band) {
            return null;
        }
        $st = $this->db->prepare('SELECT c.factor FROM trades t JOIN trade_categories c ON c.id = t.category_id WHERE t.id = ?');
        $st->execute([$tradeId]);
        $factor = $st->fetchColumn();
        $st = $this->db->prepare('SELECT base_ngn FROM hiring_fee_base WHERE experience_band = ?');
        $st->execute([$band]);
        $base = $st->fetchColumn();
        if ($factor === false || $base === false) {
            return null;
        }
        $out = [];
        foreach ($this->db->query('SELECT engagement_type, multiplier FROM hiring_fee_rules')->fetchAll() as $rule) {
            $out[$rule['engagement_type']] = self::compute((int)$base, (float)$factor, (float)$rule['multiplier']);
        }
        return $out ?: null;
    }
}
