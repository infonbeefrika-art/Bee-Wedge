<?php
declare(strict_types=1);

namespace Beefrika;

use Beefrika\Controllers\Input;
use PDO;
use PDOException;

/**
 * Customer vouches. A past customer opens the worker's vouch link (no account), says the worker did work for them,
 * gives 1 to 5 honey drops and a few details. Shown as "Customer-vouched": separate from "Recorded on Beefrika" hires and
 * never called "verified". The customer's phone number is stored only as a keyed hash.
 */
final class Vouch
{
    public const JOB_TYPES = ['made' => 'Made or built something', 'repair' => 'Repaired or fixed something', 'service' => 'Regular service',
        'event' => 'Event or special job', 'delivery' => 'Delivery or errand', 'taught' => 'Taught or trained me', 'other' => 'Something else'];
    public const FLAG_REASONS = ['not_a_customer' => 'This person was not my customer', 'fake' => 'This looks fake', 'abusive' => 'Rude or unfair words', 'other' => 'Something else'];
    public const MAX_SHOWN = 10;
    public const AVG_MIN_VOUCHES = 3;       // an average is shown only from this many vouches
    public const MIN_FORM_SECONDS = 4;      // a person cannot fill the form faster than this
    public const MAX_FORM_SECONDS = 7200;
    // Soft checks. A vouch that trips one is saved as "held" and shown only after the Beefrika team approves it.
    public const HOLD_SAME_NETWORK = 3;     // the 3rd vouch for one worker from one network within 24 hours
    public const HOLD_BURST = 5;            // the 5th vouch for one worker within 10 minutes
    public const HOLD_PHONE_WORKERS = 5;    // one phone number vouching for its 5th different worker within 24 hours
    public const HOLD_NETWORK_WORKERS = 5;  // one network vouching for its 5th different worker within 24 hours

    // ------------------------------------------------------------------ links

    /** The worker's active link, created on first use. $rotate retires the old link and makes a new one (old vouches stay). */
    public static function linkFor(PDO $db, int $workerId, bool $rotate = false): array
    {
        $st = $db->prepare("SELECT id, token, opens, created_at FROM vouch_links WHERE worker_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $st->execute([$workerId]);
        $row = $st->fetch();
        if ($row && !$rotate) {
            return $row;
        }
        if ($row) {
            $db->prepare("UPDATE vouch_links SET status = 'retired', retired_at = ? WHERE worker_id = ? AND status = 'active'")
                ->execute([Clock::dt(), $workerId]);
        }
        $token = bin2hex(random_bytes(12));
        $db->prepare('INSERT INTO vouch_links (worker_id, token, status, opens, created_at) VALUES (?, ?, ?, 0, ?)')
            ->execute([$workerId, $token, 'active', Clock::dt()]);
        return ['id' => (int)$db->lastInsertId(), 'token' => $token, 'opens' => 0, 'created_at' => Clock::dt()];
    }

    public static function urlFor(string $token): string
    {
        return PublicProfile::baseUrl() . '/v/' . $token;
    }

    /** Link plus the worker details the customer page needs. Null if the link is unknown, retired, or the worker is not active. */
    public static function findLink(PDO $db, string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{24}$/', $token)) {
            return null;
        }
        $st = $db->prepare(
            "SELECT l.id AS link_id, l.token, l.worker_id, u.beefrika_id, u.full_name, u.phone, t.name AS trade_name, a.name AS area_name
             FROM vouch_links l
             JOIN users u ON u.id = l.worker_id
             JOIN worker_profiles wp ON wp.user_id = u.id
             LEFT JOIN trades t ON t.id = wp.primary_trade_id
             LEFT JOIN lagos_areas a ON a.id = wp.area_id
             WHERE l.token = ? AND l.status = 'active' AND u.role = 'worker' AND u.status = 'active'"
        );
        $st->execute([$token]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /** Counts a human opening the page. Crawlers and link-preview bots (WhatsApp) are not counted. */
    public static function recordOpen(PDO $db, int $linkId, string $userAgent): void
    {
        if ($userAgent === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|whatsapp|telegram|preview|curl|wget|python|http-client|go-http/i', $userAgent)) {
            return;
        }
        $db->prepare('UPDATE vouch_links SET opens = opens + 1, last_opened_at = ? WHERE id = ?')->execute([Clock::dt(), $linkId]);
    }

    // ------------------------------------------------------------------ form token (stops replays and instant bot posts)

    public static function formToken(string $linkToken): string
    {
        $ts = Clock::now();
        return $ts . '.' . Security::hmac('vouchform|' . $linkToken . '|' . $ts);
    }

    private static function checkFormToken(string $linkToken, string $submitted): void
    {
        $bad = new ApiException('This page expired. Please try again.', 422);
        if (!preg_match('/^(\d{9,12})\.([a-f0-9]{64})$/', $submitted, $m)) {
            throw $bad;
        }
        if (!hash_equals(Security::hmac('vouchform|' . $linkToken . '|' . $m[1]), $m[2])) {
            throw $bad;
        }
        $age = Clock::now() - (int)$m[1];
        if ($age > self::MAX_FORM_SECONDS) {
            throw $bad;
        }
        if ($age < self::MIN_FORM_SECONDS) {
            throw new ApiException('That was very quick. Please check your answers and send again.', 422);
        }
    }

    // ------------------------------------------------------------------ submitting a vouch

    /** @param array<string,mixed> $in the form fields. @return array{ok:bool,held:bool} */
    public static function submit(PDO $db, array $link, array $in, string $ip): array
    {
        if (trim((string)($in['website'] ?? '')) !== '') { // hidden field: only bots fill it. Pretend it worked.
            return ['ok' => true, 'held' => false];
        }
        self::checkFormToken((string)$link['token'], (string)($in['ft'] ?? ''));

        $limit = new RateLimit($db);
        $ipHash = Security::ipHash($ip);
        if ($limit->tooMany('vouch:ip:' . $ipHash, 8, 3600) || $limit->tooMany('vouch:link:' . $link['link_id'], 40, 86400)) {
            throw new ApiException('Too many vouches from this network. Please try again later.', 429);
        }
        $limit->hit('vouch:ip:' . $ipHash);

        if (($in['did_work'] ?? '') !== '1') {
            throw new ApiException('Please confirm that this person did work for you.', 422);
        }
        $rating = $in['rating'] ?? '';
        if (!is_string($rating) || !preg_match('/^[1-5]$/', $rating)) {
            throw new ApiException('Choose 1 to 5 honey drops.', 422);
        }
        $job = Input::enum($in, 'job_type', array_keys(self::JOB_TYPES), 'Choose what they did for you.');
        $name = explode(' ', Input::text($in, 'name', 2, 40, 'Your first name'))[0];
        if (!preg_match('/^[\p{L}\p{M}][\p{L}\p{M}.\'\-]{1,39}$/u', $name)) {
            throw new ApiException('Please enter your first name, using letters only.', 422);
        }
        $comment = Input::optionalText($in, 'comment', 160, 'Your comment');
        if ($comment !== null && (preg_match('/https?:|www\.|\.com\b|\.ng\b|@/i', $comment) || strlen(preg_replace('/\D/', '', $comment) ?? '') >= 9)) {
            throw new ApiException('Please do not put links, emails or phone numbers in your comment.', 422);
        }
        $phone = Phone::normalizeNg((string)($in['phone'] ?? ''));
        if ($phone === null) {
            throw new ApiException('Enter a valid Nigerian mobile number, for example 0801 234 5678.', 422);
        }
        if ($phone === ($link['phone'] ?? null)) {
            throw new ApiException('You cannot vouch for yourself.', 422);
        }
        $areaId = null;
        $rawArea = (string)($in['area_id'] ?? '');
        if ($rawArea !== '') {
            $a = $db->prepare('SELECT id FROM lagos_areas WHERE id = ?');
            $a->execute([ctype_digit($rawArea) ? (int)$rawArea : 0]);
            $areaId = $a->fetchColumn() ?: null;
            if ($areaId === null) {
                throw new ApiException('Choose your area from the list, or leave it empty.', 422);
            }
            $areaId = (int)$areaId;
        }

        $workerId = (int)$link['worker_id'];
        $phoneHash = Security::hmac('vouchphone|' . $phone);
        $dup = $db->prepare('SELECT 1 FROM vouches WHERE worker_id = ? AND phone_hash = ?');
        $dup->execute([$workerId, $phoneHash]);
        if ($dup->fetchColumn()) {
            throw new ApiException('This number has already vouched for ' . explode(' ', (string)$link['full_name'])[0] . '. Thank you.', 409);
        }

        $hold = self::holdReason($db, $workerId, $ipHash, $phoneHash);
        $status = $hold === null ? 'published' : 'held';
        try {
            $db->prepare(
                'INSERT INTO vouches (worker_id, link_id, phone_hash, customer_name, area_id, rating, job_type, comment, ip_hash, status, hold_reason, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([$workerId, (int)$link['link_id'], $phoneHash, $name, $areaId, (int)$rating, $job, $comment, $ipHash, $status, $hold, Clock::dt()]);
        } catch (PDOException $e) {
            if ((string)$e->getCode() === '23000') { // two taps at once
                throw new ApiException('This number has already vouched. Thank you.', 409);
            }
            throw $e;
        }
        $limit->hit('vouch:link:' . $link['link_id']);
        return ['ok' => true, 'held' => $hold !== null];
    }

    /** Soft fake-vouch checks. Returns why a vouch should wait for review, or null. */
    private static function holdReason(PDO $db, int $workerId, string $ipHash, string $phoneHash): ?string
    {
        $one = function (string $sql, array $p) use ($db): int {
            $st = $db->prepare($sql);
            $st->execute($p);
            return (int)$st->fetchColumn();
        };
        $day = Clock::dt(Clock::now() - 86400);
        if ($one('SELECT COUNT(*) FROM vouches WHERE worker_id = ? AND ip_hash = ? AND created_at >= ?', [$workerId, $ipHash, $day]) >= self::HOLD_SAME_NETWORK - 1) {
            return 'same_network';
        }
        if ($one('SELECT COUNT(*) FROM vouches WHERE worker_id = ? AND created_at >= ?', [$workerId, Clock::dt(Clock::now() - 600)]) >= self::HOLD_BURST - 1) {
            return 'burst';
        }
        if ($one('SELECT COUNT(DISTINCT worker_id) FROM vouches WHERE phone_hash = ? AND worker_id <> ? AND created_at >= ?', [$phoneHash, $workerId, $day]) >= self::HOLD_PHONE_WORKERS - 1) {
            return 'serial_phone';
        }
        if ($one('SELECT COUNT(DISTINCT worker_id) FROM vouches WHERE ip_hash = ? AND worker_id <> ? AND created_at >= ?', [$ipHash, $workerId, $day]) >= self::HOLD_NETWORK_WORKERS - 1) {
            return 'network_many';
        }
        // Same network as the worker's own recent log-ins: the worker may be vouching for themselves.
        if ($one('SELECT COUNT(*) FROM sessions WHERE user_id = ? AND ip_hash = ? AND created_at >= ?', [$workerId, $ipHash, Clock::dt(Clock::now() - 30 * 86400)]) > 0) {
            return 'worker_network';
        }
        return null;
    }

    // ------------------------------------------------------------------ reading

    /** What visitors and employers see: published vouches only, newest first, at most MAX_SHOWN. */
    public static function publicList(PDO $db, int $workerId): array
    {
        $st = $db->prepare("SELECT COUNT(*) AS n, AVG(rating) AS avg_rating FROM vouches WHERE worker_id = ? AND status = 'published'");
        $st->execute([$workerId]);
        $agg = $st->fetch() ?: ['n' => 0, 'avg_rating' => null];
        $count = (int)$agg['n'];
        $rows = $db->prepare(
            "SELECT v.customer_name, v.rating, v.job_type, v.comment, v.created_at, a.name AS area_name
             FROM vouches v LEFT JOIN lagos_areas a ON a.id = v.area_id
             WHERE v.worker_id = ? AND v.status = 'published' ORDER BY v.id DESC LIMIT " . self::MAX_SHOWN
        );
        $rows->execute([$workerId]);
        return [
            'count' => $count,
            'average' => $count >= self::AVG_MIN_VOUCHES ? round((float)$agg['avg_rating'], 1) : null,
            'items' => array_map(fn($r) => [
                'name' => $r['customer_name'], 'area' => $r['area_name'], 'rating' => (int)$r['rating'], 'job_type' => $r['job_type'],
                'comment' => $r['comment'], 'month' => self::month((string)$r['created_at']),
            ], $rows->fetchAll()),
        ];
    }

    /** The worker's own inbox: published vouches and the ones waiting for review. No phone data exists to show. */
    public static function mine(PDO $db, int $workerId): array
    {
        $st = $db->prepare(
            "SELECT v.id, v.customer_name, v.rating, v.job_type, v.comment, v.status, v.worker_flagged_at, v.created_at, a.name AS area_name
             FROM vouches v LEFT JOIN lagos_areas a ON a.id = v.area_id
             WHERE v.worker_id = ? AND v.status IN ('published','held') ORDER BY v.id DESC LIMIT 100"
        );
        $st->execute([$workerId]);
        $items = [];
        $published = 0;
        $waiting = 0;
        foreach ($st->fetchAll() as $r) {
            $r['status'] === 'published' ? $published++ : $waiting++;
            $items[] = ['id' => (int)$r['id'], 'name' => $r['customer_name'], 'area' => $r['area_name'], 'rating' => (int)$r['rating'],
                        'job_type' => $r['job_type'], 'comment' => $r['comment'], 'status' => $r['status'],
                        'flagged' => $r['worker_flagged_at'] !== null, 'month' => self::month((string)$r['created_at'])];
        }
        return ['counts' => ['published' => $published, 'waiting' => $waiting], 'items' => $items];
    }

    /** A worker may report a vouch. It stays visible until the Beefrika team decides, so a worker cannot hide an honest one. */
    public static function flag(PDO $db, int $workerId, int $vouchId, string $reason): void
    {
        $upd = $db->prepare(
            "UPDATE vouches SET worker_flag_reason = ?, worker_flagged_at = ?
             WHERE id = ? AND worker_id = ? AND status IN ('published','held') AND worker_flagged_at IS NULL"
        );
        $upd->execute([$reason, Clock::dt(), $vouchId, $workerId]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('Vouch not found, or you already reported it.', 404);
        }
    }

    public static function month(string $utc): string
    {
        $t = strtotime($utc . ' UTC');
        return $t === false ? '' : gmdate('M Y', $t);
    }
}
