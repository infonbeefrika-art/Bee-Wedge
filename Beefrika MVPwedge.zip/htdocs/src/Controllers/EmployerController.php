<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Trust;
use PDO;

final class EmployerController
{
    public const TYPES = ['household', 'small_business', 'contractor', 'organisation'];

    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        $u = (new Auth($this->db))->requireUser('employer');
        return $this->payload($u);
    }

    /** PUT /employer/profile */
    public function update(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('employer');

        $type = Input::enum($in, 'employer_type', self::TYPES, 'Choose what kind of employer you are.', false);
        $business = Input::optionalText($in, 'business_name', 120, 'Business or household name');
        $hiresFor = Input::optionalText($in, 'hires_for', 120, 'What you hire for');
        $location = Input::optionalText($in, 'location_note', 255, 'Where you work');
        $assoc = Input::optionalText($in, 'association_name', 120, 'Association');
        $cac = Input::optionalText($in, 'cac_number', 20, 'CAC number');
        if ($cac !== null && !preg_match('/^[A-Za-z0-9\- ]{3,20}$/', $cac)) {
            throw new ApiException('CAC number can only have letters, numbers and dashes. You can leave it empty.', 422);
        }
        $areaId = $in['area_id'] ?? null;
        if ($areaId !== null && $areaId !== '') {
            $st = $this->db->prepare('SELECT id FROM lagos_areas WHERE id = ? AND is_active = 1');
            $st->execute([(int)$areaId]);
            if (!is_numeric($areaId) || !$st->fetchColumn()) {
                throw new ApiException('Choose a valid area.', 422);
            }
            $areaId = (int)$areaId;
        } else {
            $areaId = null;
        }

        $this->db->prepare(
            'UPDATE employer_profiles SET employer_type = ?, business_name = ?, area_id = ?, hires_for = ?, location_note = ?,
             association_name = ?, cac_number = ?, updated_at = ? WHERE user_id = ?'
        )->execute([$type, $business, $areaId, $hiresFor, $location, $assoc, $cac, Clock::dt(), $u['id']]);

        return $this->payload($u);
    }

    public static function isComplete(PDO $db, int $userId): bool
    {
        $st = $db->prepare('SELECT employer_type, business_name, area_id FROM employer_profiles WHERE user_id = ?');
        $st->execute([$userId]);
        $p = $st->fetch();
        return $p && !empty($p['employer_type']) && !empty($p['business_name']) && !empty($p['area_id']);
    }

    private function payload(array $u): array
    {
        $st = $this->db->prepare('SELECT * FROM employer_profiles WHERE user_id = ?');
        $st->execute([$u['id']]);
        $p = $st->fetch() ?: [];
        $checklist = [
            ['key' => 'phone',    'done' => (bool)$u['phone_verified_at']],
            ['key' => 'type',     'done' => !empty($p['employer_type'])],
            ['key' => 'business', 'done' => !empty($p['business_name'])],
            ['key' => 'area',     'done' => !empty($p['area_id'])],
            ['key' => 'where',    'done' => !empty($p['location_note'])],
            ['key' => 'evidence', 'done' => Trust::bestLevel($this->db, (int)$u['id'], 'business') !== 'self_reported'],
        ];
        return ['profile' => [
            'employer_type'    => $p['employer_type'] ?? null,
            'business_name'    => $p['business_name'] ?? '',
            'area_id'          => isset($p['area_id']) ? (int)$p['area_id'] : null,
            'hires_for'        => $p['hires_for'] ?? '',
            'location_note'    => $p['location_note'] ?? '',
            'association_name' => $p['association_name'] ?? '',
            'cac_number'       => $p['cac_number'] ?? '',
            'complete'         => self::isComplete($this->db, (int)$u['id']),
            'business_trust'   => Trust::bestLevel($this->db, (int)$u['id'], 'business'),
            'checklist'        => $checklist,
        ]];
    }
}
