<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\FeeCalculator;
use Beefrika\RateLimit;
use Beefrika\Trust;
use PDO;

/**
 * Hiring requests and the hire workflow.
 *   sent -> accepted | declined | withdrawn
 *   accepted -> (employer proposes hire, worker confirms) -> hired -> completed | cancelled
 * A hire exists only when BOTH sides confirm. The hiring fee is recorded at that moment, never collected online.
 * "Completed" jobs are labelled "recorded on Beefrika", not "verified": two accounts could be controlled by one person.
 */
final class HiringController
{
    public const TYPES = ['short_gig', 'contract'];
    public const PERIODS = ['per_job', 'per_day', 'per_week', 'per_month'];
    private const ACTIONS = ['accept', 'decline', 'withdraw', 'propose_hire', 'cancel_proposal', 'confirm_hire', 'decline_hire', 'complete', 'cancel'];
    public const OPEN = ['sent', 'accepted', 'hired'];

    public function __construct(private PDO $db)
    {
    }

    /** POST /requests */
    public function create(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('employer');
        if (!EmployerController::isComplete($this->db, (int)$u['id'])) {
            throw new ApiException('Add your business details first, so workers know who is hiring.', 403, ['code' => 'business_profile_incomplete']);
        }
        $type = Input::enum($in, 'engagement_type', self::TYPES, 'Choose short gig or contract.');
        $title = Input::text($in, 'title', 3, 100, 'Job title');
        $details = Input::multiline($in, 'details', 1000, 'Job details');
        if (mb_strlen($details) < 10) {
            throw new ApiException('Describe the job in a few words so the worker knows what is needed.', 422);
        }
        $hours = Input::optionalText($in, 'working_hours', 160, 'Working hours');
        $location = Input::optionalText($in, 'location_note', 255, 'Where the work is');
        [$pay, $period] = $this->payOffer($in);

        $st = $this->db->prepare(
            "SELECT u.id FROM users u JOIN worker_profiles wp ON wp.user_id = u.id
             WHERE u.beefrika_id = ? AND u.role = 'worker' AND u.status = 'active' AND wp.is_discoverable = 1"
        );
        $st->execute([(string)($in['worker_id'] ?? '')]);
        $workerId = $st->fetchColumn();
        if (!$workerId) {
            throw new ApiException('Worker not found.', 404);
        }
        $workerId = (int)$workerId;

        $unverified = Trust::counts($this->db, $workerId)['verified'] === 0;
        if ($unverified && empty($in['ack_unverified'])) {
            throw new ApiException('This worker has no verified proof yet. Please confirm you understand before you send.', 422, ['code' => 'ack_required']);
        }
        $dup = $this->db->prepare("SELECT 1 FROM hiring_requests WHERE employer_id = ? AND worker_id = ? AND status IN ('sent','accepted','hired')");
        $dup->execute([$u['id'], $workerId]);
        if ($dup->fetchColumn()) {
            throw new ApiException('You already have an open request with this worker.', 409);
        }
        $limit = new RateLimit($this->db);
        $key = 'hire_request:user:' . $u['id'];
        if ($limit->tooMany($key, 10, 86400)) {
            throw new ApiException('You have sent many requests today. Please try again tomorrow.', 429);
        }

        $now = Clock::dt();
        $this->db->beginTransaction();
        try {
            $this->db->prepare(
                'INSERT INTO hiring_requests (employer_id, worker_id, engagement_type, title, details, working_hours, location_note,
                 pay_offer_ngn, pay_period, ack_unverified, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([$u['id'], $workerId, $type, $title, $details, $hours, $location, $pay, $period, $unverified ? 1 : 0, 'sent', $now, $now]);
            $id = (int)$this->db->lastInsertId();
            $this->db->prepare('INSERT INTO messages (request_id, sender_id, kind, body, created_at) VALUES (?,?,?,?,?)')
                ->execute([$id, $u['id'], 'text', $details, $now]);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
        $limit->hit($key);
        return ['id' => $id];
    }

    /** GET /requests */
    public function index(): array
    {
        $u = $this->participant();
        $col = $u['role'] === 'employer' ? 'employer_id' : 'worker_id'; // fixed names, never user input
        $st = $this->db->prepare(
            "SELECT r.id, r.status, r.engagement_type, r.title, r.updated_at,
                    ew.full_name AS employer_name, ep.business_name, wu.full_name AS worker_name, wu.beefrika_id AS worker_bfid, t.name AS trade_name,
                    (SELECT COUNT(*) FROM messages m WHERE m.request_id = r.id AND m.kind = 'text' AND m.sender_id <> ? AND m.read_at IS NULL) AS unread,
                    (SELECT m.body FROM messages m WHERE m.request_id = r.id AND m.kind = 'text' ORDER BY m.id DESC LIMIT 1) AS last_body
             FROM hiring_requests r
             JOIN users ew ON ew.id = r.employer_id
             JOIN employer_profiles ep ON ep.user_id = ew.id
             JOIN users wu ON wu.id = r.worker_id
             LEFT JOIN worker_profiles wp ON wp.user_id = wu.id
             LEFT JOIN trades t ON t.id = wp.primary_trade_id
             WHERE r.$col = ?
             ORDER BY r.updated_at DESC, r.id DESC LIMIT 50"
        );
        $st->execute([$u['id'], $u['id']]);
        return ['requests' => array_map(fn($r) => [
            'id'             => (int)$r['id'],
            'status'         => $r['status'],
            'engagement_type' => $r['engagement_type'],
            'title'          => $r['title'],
            'other_name'     => $u['role'] === 'employer' ? $r['worker_name'] : ($r['business_name'] ?: $r['employer_name']),
            'trade'          => $u['role'] === 'employer' ? $r['trade_name'] : null,
            'unread'         => (int)$r['unread'],
            'last_message'   => $r['last_body'] === null ? '' : mb_substr($r['last_body'], 0, 80),
            'updated_at'     => $r['updated_at'],
        ], $st->fetchAll())];
    }

    /** GET /requests/{id} */
    public function show(int $id): array
    {
        $u = $this->participant();
        $req = self::loadFor($this->db, $id, $u);
        $role = self::roleIn($req, $u);
        $hire = self::hireOf($this->db, $id);

        if ($role === 'employer') {
            $st = $this->db->prepare(
                "SELECT u.beefrika_id, u.full_name, wp.primary_trade_id, wp.experience_band, t.name AS trade_name, a.name AS area_name
                 FROM users u JOIN worker_profiles wp ON wp.user_id = u.id
                 LEFT JOIN trades t ON t.id = wp.primary_trade_id LEFT JOIN lagos_areas a ON a.id = wp.area_id WHERE u.id = ?"
            );
            $st->execute([$req['worker_id']]);
            $w = $st->fetch() ?: [];
            $trust = Trust::counts($this->db, (int)$req['worker_id']);
            $other = ['name' => $w['full_name'] ?? '', 'beefrika_id' => $w['beefrika_id'] ?? '', 'trade' => $w['trade_name'] ?? null,
                      'area' => $w['area_name'] ?? null, 'headline_level' => $trust['headline']];
            $preview = (new FeeCalculator($this->db))->quotesFor(
                isset($w['primary_trade_id']) ? (int)$w['primary_trade_id'] : null, $w['experience_band'] ?? null
            );
            $feePreview = $preview[$req['engagement_type']]['fee'] ?? null;
        } else {
            $st = $this->db->prepare(
                'SELECT u.full_name, ep.employer_type, ep.business_name, a.name AS area_name
                 FROM users u JOIN employer_profiles ep ON ep.user_id = u.id LEFT JOIN lagos_areas a ON a.id = ep.area_id WHERE u.id = ?'
            );
            $st->execute([$req['employer_id']]);
            $e = $st->fetch() ?: [];
            $other = ['name' => $e['full_name'] ?? '', 'business_name' => $e['business_name'] ?? '', 'employer_type' => $e['employer_type'] ?? null,
                      'area' => $e['area_name'] ?? null, 'business_trust' => Trust::bestLevel($this->db, (int)$req['employer_id'], 'business')];
            $feePreview = null;
        }

        $hireOut = null;
        if ($hire && $hire['status'] !== 'cancelled') {
            $hireOut = [
                'status'             => $hire['status'],
                'agreed_pay_ngn'     => $hire['agreed_pay_ngn'] === null ? null : (int)$hire['agreed_pay_ngn'],
                'start_date'         => $hire['start_date'],
                'employer_confirmed' => $hire['confirmed_by_employer_at'] !== null,
                'worker_confirmed'   => $hire['confirmed_by_worker_at'] !== null,
            ];
            if ($role === 'employer') { // the fee is between Beefrika and the employer
                $hireOut['fee'] = ['amount' => $hire['fee_amount_ngn'] === null ? null : (int)$hire['fee_amount_ngn'],
                                   'multiplier' => $hire['fee_multiplier'] === null ? null : (float)$hire['fee_multiplier'], 'status' => $hire['fee_status']];
            }
        }
        return [
            'role'    => $role,
            'request' => [
                'id' => (int)$req['id'], 'status' => $req['status'], 'engagement_type' => $req['engagement_type'], 'title' => $req['title'],
                'details' => $req['details'], 'working_hours' => $req['working_hours'], 'location_note' => $req['location_note'],
                'pay_offer_ngn' => $req['pay_offer_ngn'] === null ? null : (int)$req['pay_offer_ngn'], 'pay_period' => $req['pay_period'],
                'created_at' => $req['created_at'],
            ],
            'other'   => $other,
            'hire'    => $hireOut,
            'fee_preview' => $feePreview,
            'actions' => self::actionsFor($req, $hire, $role),
            'can_message' => in_array($req['status'], self::OPEN, true),
        ];
    }

    /** POST /requests/{id}/action {action, agreed_pay_ngn?, start_date?} */
    public function act(int $id, array $in): array
    {
        $u = $this->participant();
        $req = self::loadFor($this->db, $id, $u);
        $role = self::roleIn($req, $u);
        $action = Input::enum($in, 'action', self::ACTIONS, 'Unknown action.');
        $hire = self::hireOf($this->db, $id);
        if (!in_array($action, self::actionsFor($req, $hire, $role), true)) {
            throw new ApiException('That is not possible right now.', 409);
        }
        $uid = (int)$u['id'];

        $this->db->beginTransaction();
        try {
            switch ($action) {
                case 'accept':
                    $this->move($id, 'sent', 'accepted');
                    self::system($this->db, $id, $uid, 'accepted');
                    break;
                case 'decline':
                    $this->move($id, 'sent', 'declined');
                    self::system($this->db, $id, $uid, 'declined');
                    break;
                case 'withdraw':
                    $this->move($id, $req['status'], 'withdrawn');
                    $this->cancelPendingHire($id);
                    self::system($this->db, $id, $uid, 'withdrawn');
                    break;
                case 'propose_hire':
                    $this->proposeHire($req, $hire, $in);
                    self::system($this->db, $id, $uid, 'hire_proposed');
                    break;
                case 'cancel_proposal':
                case 'decline_hire':
                    $this->cancelPendingHire($id);
                    $this->touch($id);
                    self::system($this->db, $id, $uid, 'hire_proposal_cancelled');
                    break;
                case 'confirm_hire':
                    $this->confirmHire($req);
                    self::system($this->db, $id, $uid, 'hire_confirmed');
                    break;
                case 'complete':
                    $this->complete($req);
                    self::system($this->db, $id, $uid, 'completed');
                    break;
                case 'cancel':
                    $now = Clock::dt();
                    $this->db->prepare("UPDATE hires SET status = 'cancelled', updated_at = ? WHERE hiring_request_id = ? AND status = 'confirmed'")->execute([$now, $id]);
                    $this->move($id, 'hired', 'cancelled');
                    self::system($this->db, $id, $uid, 'cancelled');
                    break;
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
        return $this->show($id);
    }

    /** GET /summary: numbers for the app badge */
    public function summary(): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['employer', 'worker'], true)) {
            return ['unread' => 0, 'todo' => 0];
        }
        $st = $this->db->prepare(
            "SELECT COUNT(*) FROM messages m JOIN hiring_requests r ON r.id = m.request_id
             WHERE (r.employer_id = ? OR r.worker_id = ?) AND m.kind = 'text' AND m.sender_id <> ? AND m.read_at IS NULL"
        );
        $st->execute([$u['id'], $u['id'], $u['id']]);
        $unread = (int)$st->fetchColumn();
        $todo = 0;
        if ($u['role'] === 'worker') {
            $st = $this->db->prepare(
                "SELECT COUNT(*) FROM hiring_requests r WHERE r.worker_id = ? AND (r.status = 'sent' OR
                 (r.status = 'accepted' AND EXISTS (SELECT 1 FROM hires h WHERE h.hiring_request_id = r.id AND h.status = 'pending_confirmation')))"
            );
            $st->execute([$u['id']]);
            $todo = (int)$st->fetchColumn();
        }
        return ['unread' => $unread, 'todo' => $todo];
    }

    // ------------------------------------------------------------------ shared helpers

    public static function loadFor(PDO $db, int $id, array $u): array
    {
        $st = $db->prepare('SELECT * FROM hiring_requests WHERE id = ? AND (employer_id = ? OR worker_id = ?)');
        $st->execute([$id, $u['id'], $u['id']]);
        $r = $st->fetch();
        if (!$r) {
            throw new ApiException('Request not found.', 404);
        }
        return $r;
    }

    public static function roleIn(array $req, array $u): string
    {
        return (int)$req['employer_id'] === (int)$u['id'] ? 'employer' : 'worker';
    }

    public static function hireOf(PDO $db, int $requestId): ?array
    {
        $st = $db->prepare('SELECT * FROM hires WHERE hiring_request_id = ?');
        $st->execute([$requestId]);
        return $st->fetch() ?: null;
    }

    /** What this person may do right now. The client shows only these buttons; the server enforces them again. */
    public static function actionsFor(array $req, ?array $hire, string $role): array
    {
        $pending = $hire && $hire['status'] === 'pending_confirmation';
        $out = [];
        if ($role === 'employer') {
            if ($req['status'] === 'sent') {
                $out = ['withdraw'];
            } elseif ($req['status'] === 'accepted') {
                $out = $pending ? ['cancel_proposal', 'withdraw'] : ['propose_hire', 'withdraw'];
            } elseif ($req['status'] === 'hired') {
                $out = ['complete', 'cancel'];
            }
        } else {
            if ($req['status'] === 'sent') {
                $out = ['accept', 'decline'];
            } elseif ($req['status'] === 'accepted' && $pending) {
                $out = ['confirm_hire', 'decline_hire'];
            } elseif ($req['status'] === 'hired') {
                $out = ['cancel'];
            }
        }
        return $out;
    }

    public static function system(PDO $db, int $requestId, int $actorId, string $code): void
    {
        $db->prepare('INSERT INTO messages (request_id, sender_id, kind, body, created_at) VALUES (?,?,?,?,?)')
            ->execute([$requestId, $actorId, 'system', $code, Clock::dt()]);
    }

    private function participant(): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['employer', 'worker'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        return $u;
    }

    private function move(int $id, string $from, string $to): void
    {
        $st = $this->db->prepare('UPDATE hiring_requests SET status = ?, updated_at = ? WHERE id = ? AND status = ?');
        $st->execute([$to, Clock::dt(), $id, $from]);
        if ($st->rowCount() !== 1) {
            throw new ApiException('This request has just changed. Please refresh.', 409);
        }
    }

    private function touch(int $id): void
    {
        $this->db->prepare('UPDATE hiring_requests SET updated_at = ? WHERE id = ?')->execute([Clock::dt(), $id]);
    }

    private function cancelPendingHire(int $id): void
    {
        $this->db->prepare("UPDATE hires SET status = 'cancelled', updated_at = ? WHERE hiring_request_id = ? AND status = 'pending_confirmation'")
            ->execute([Clock::dt(), $id]);
    }

    private function proposeHire(array $req, ?array $hire, array $in): void
    {
        $pay = $this->money($in['agreed_pay_ngn'] ?? $req['pay_offer_ngn'], 'Agreed pay');
        $start = $in['start_date'] ?? null;
        if ($start !== null && $start !== '') {
            $ok = is_string($start) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $start, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1]);
            $ts = $ok ? strtotime($start . ' UTC') : false;
            if (!$ok || $ts < Clock::now() - 2 * 86400 || $ts > Clock::now() + 400 * 86400) {
                throw new ApiException('Enter a valid start date within the next year.', 422);
            }
        } else {
            $start = null;
        }
        $now = Clock::dt();
        if ($hire) { // a cancelled proposal is reused
            $this->db->prepare(
                "UPDATE hires SET status = 'pending_confirmation', agreed_pay_ngn = ?, start_date = ?, confirmed_by_employer_at = ?, confirmed_by_worker_at = NULL,
                 fee_multiplier = NULL, fee_amount_ngn = NULL, fee_status = 'not_due', fee_note = NULL, updated_at = ? WHERE hiring_request_id = ?"
            )->execute([$pay, $start, $now, $now, $req['id']]);
        } else {
            $this->db->prepare(
                'INSERT INTO hires (hiring_request_id, employer_id, worker_id, engagement_type, agreed_pay_ngn, start_date, confirmed_by_employer_at, status, created_at, updated_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([$req['id'], $req['employer_id'], $req['worker_id'], $req['engagement_type'], $pay, $start, $now, 'pending_confirmation', $now, $now]);
        }
        $this->touch((int)$req['id']);
    }

    private function confirmHire(array $req): void
    {
        $st = $this->db->prepare('SELECT primary_trade_id, experience_band FROM worker_profiles WHERE user_id = ?');
        $st->execute([$req['worker_id']]);
        $wp = $st->fetch() ?: [];
        $quotes = (new FeeCalculator($this->db))->quotesFor(
            isset($wp['primary_trade_id']) ? (int)$wp['primary_trade_id'] : null, $wp['experience_band'] ?? null
        );
        $m = $this->db->prepare('SELECT multiplier FROM hiring_fee_rules WHERE engagement_type = ?');
        $m->execute([$req['engagement_type']]);
        $multiplier = $m->fetchColumn();
        $amount = $quotes[$req['engagement_type']]['fee'] ?? null;
        $now = Clock::dt();
        $upd = $this->db->prepare(
            "UPDATE hires SET status = 'confirmed', confirmed_by_worker_at = ?, fee_multiplier = ?, fee_amount_ngn = ?, fee_status = ?, fee_note = ?, updated_at = ?
             WHERE hiring_request_id = ? AND status = 'pending_confirmation'"
        );
        $upd->execute([$now, $multiplier === false ? null : $multiplier, $amount, $amount === null ? 'not_due' : 'due',
                       $amount === null ? 'Pricing was not set when this hire was confirmed. Set the fee by hand.' : null, $now, $req['id']]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This hire has just changed. Please refresh.', 409);
        }
        $this->move((int)$req['id'], 'accepted', 'hired');
    }

    private function complete(array $req): void
    {
        $now = Clock::dt();
        $upd = $this->db->prepare("UPDATE hires SET status = 'completed', completed_at = ?, updated_at = ? WHERE hiring_request_id = ? AND status = 'confirmed'");
        $upd->execute([$now, $now, $req['id']]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This hire has just changed. Please refresh.', 409);
        }
        $this->move((int)$req['id'], 'hired', 'completed');
        $hire = self::hireOf($this->db, (int)$req['id']);
        $info = $this->db->prepare(
            'SELECT t.name AS trade_name, wp.primary_trade_id, ep.business_name
             FROM worker_profiles wp LEFT JOIN trades t ON t.id = wp.primary_trade_id, employer_profiles ep WHERE wp.user_id = ? AND ep.user_id = ?'
        );
        $info->execute([$req['worker_id'], $req['employer_id']]);
        $i = $info->fetch() ?: [];
        $this->db->prepare(
            'INSERT INTO work_history (user_id, title, employer_name, trade_id, start_date, description, source, hire_id, created_at) VALUES (?,?,?,?,?,?,?,?,?)'
        )->execute([$req['worker_id'], $i['trade_name'] ?? 'Job', $i['business_name'] ?? null, $i['primary_trade_id'] ?? null,
                    $hire['start_date'] ?? null, $req['engagement_type'], 'beefrika_hire', $hire['id'] ?? null, $now]);
    }

    private function payOffer(array $in): array
    {
        $pay = $this->money($in['pay_offer_ngn'] ?? null, 'Pay');
        if ($pay === null) {
            return [null, null];
        }
        return [$pay, Input::enum($in, 'pay_period', self::PERIODS, 'Say how the pay is counted: per job, day, week or month.')];
    }

    private function money(mixed $raw, string $label): ?int
    {
        if ($raw === null || $raw === '') {
            return null;
        }
        if (!is_numeric($raw) || (int)$raw < 1 || (int)$raw > 100000000) {
            throw new ApiException("$label must be a number in naira, for example 15000.", 422);
        }
        return (int)$raw;
    }
}
