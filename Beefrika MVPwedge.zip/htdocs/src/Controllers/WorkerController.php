<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\FeeCalculator;
use Beefrika\Trust;
use PDO;

final class WorkerController
{
    public const AVAILABILITY = ['available', 'busy', 'not_looking'];
    public const BANDS = ['apprentice', 'junior', 'established', 'master'];

    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        return $this->payload($u);
    }

    /** PUT /worker/profile */
    public function update(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');

        $headline = Input::text($in, 'headline', 0, 100, 'Headline');
        $bio = Input::multiline($in, 'bio', 600, 'About you');
        $years = $in['years_experience'] ?? null;
        $years = ($years === null || $years === '') ? null : $years;
        if ($years !== null && (!is_numeric($years) || (int)$years < 0 || (int)$years > 60)) {
            throw new ApiException('Years of experience must be between 0 and 60.', 422);
        }
        $availability = $in['availability'] ?? 'available';
        if (!in_array($availability, self::AVAILABILITY, true)) {
            throw new ApiException('Choose a valid availability.', 422);
        }
        $band = Input::enum($in, 'experience_band', self::BANDS, 'Choose your experience level.', false);
        $tradeId = $this->existingId('trades', $in['primary_trade_id'] ?? null, 'trade');
        $areaId = $this->existingId('lagos_areas', $in['area_id'] ?? null, 'area');

        $wantsDiscoverable = !empty($in['is_discoverable']);
        $wantsPublic = !empty($in['is_public']);
        if (($wantsDiscoverable || $wantsPublic) && ($tradeId === null || $areaId === null || $headline === '' || $band === null)) {
            throw new ApiException('Add your trade, area, experience level and a short headline before employers can find you or you can share your page.', 422);
        }

        $this->db->prepare(
            'UPDATE worker_profiles SET headline = ?, bio = ?, primary_trade_id = ?, area_id = ?, years_experience = ?,
             experience_band = ?, availability = ?, is_discoverable = ?, is_public = ?, updated_at = ? WHERE user_id = ?'
        )->execute([$headline, $bio, $tradeId, $areaId, $years === null ? null : (int)$years, $band, $availability, $wantsDiscoverable ? 1 : 0, $wantsPublic ? 1 : 0, Clock::dt(), $u['id']]);

        return $this->payload($u);
    }

    private function payload(array $u): array
    {
        $st = $this->db->prepare('SELECT * FROM worker_profiles WHERE user_id = ?');
        $st->execute([$u['id']]);
        $p = $st->fetch() ?: [];

        $counts = Trust::counts($this->db, (int)$u['id']);
        $checklist = [
            ['key' => 'phone',    'done' => (bool)$u['phone_verified_at']],
            ['key' => 'trade',    'done' => !empty($p['primary_trade_id'])],
            ['key' => 'area',     'done' => !empty($p['area_id'])],
            ['key' => 'band',     'done' => !empty($p['experience_band'])],
            ['key' => 'headline', 'done' => !empty($p['headline'])],
            ['key' => 'bio',      'done' => !empty($p['bio'])],
            ['key' => 'evidence', 'done' => $counts['evidence'] + $counts['verified'] > 0],
        ];
        $done = count(array_filter($checklist, fn($c) => $c['done']));
        $completion = (int)round($done / count($checklist) * 100);
        $this->db->prepare('UPDATE worker_profiles SET profile_completion = ? WHERE user_id = ?')->execute([$completion, $u['id']]);

        $quotes = (new FeeCalculator($this->db))->quotesFor(
            isset($p['primary_trade_id']) ? (int)$p['primary_trade_id'] : null,
            $p['experience_band'] ?? null
        );

        return ['profile' => [
            'headline'         => $p['headline'] ?? '',
            'bio'              => $p['bio'] ?? '',
            'primary_trade_id' => isset($p['primary_trade_id']) ? (int)$p['primary_trade_id'] : null,
            'area_id'          => isset($p['area_id']) ? (int)$p['area_id'] : null,
            'years_experience' => isset($p['years_experience']) ? (int)$p['years_experience'] : null,
            'experience_band'  => $p['experience_band'] ?? null,
            'availability'     => $p['availability'] ?? 'available',
            'is_discoverable'  => !empty($p['is_discoverable']),
            'is_public'        => !empty($p['is_public']),
            'beefrika_id'      => $u['beefrika_id'],
            'completion'       => $completion,
            'checklist'        => $checklist,
            'trust'            => $counts,
            'fee_quotes'       => $quotes,
        ]];
    }

    private function existingId(string $table, mixed $value, string $label): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            throw new ApiException("Choose a valid $label.", 422);
        }
        // $table is one of two fixed names above, never user input.
        $st = $this->db->prepare("SELECT id FROM $table WHERE id = ? AND is_active = 1");
        $st->execute([(int)$value]);
        if (!$st->fetchColumn()) {
            throw new ApiException("Choose a valid $label.", 422);
        }
        return (int)$value;
    }
}
