<?php
declare(strict_types=1);

namespace Beefrika;

final class Phone
{
    /** Returns +234XXXXXXXXXX for a valid Nigerian mobile number, otherwise null. */
    public static function normalizeNg(string $raw): ?string
    {
        $d = preg_replace('/[\s\-().]/', '', trim($raw));
        if ($d === null || $d === '') {
            return null;
        }
        if ($d[0] === '+') {
            $d = substr($d, 1);
        }
        if (!ctype_digit($d)) {
            return null;
        }
        if (str_starts_with($d, '234')) {
            $n = substr($d, 3);
        } elseif ($d[0] === '0') {
            $n = substr($d, 1);
        } else {
            $n = $d;
        }
        if ($n !== '' && $n[0] === '0') { // typed +234 0801...
            $n = substr($n, 1);
        }
        if (!preg_match('/^[789][01]\d{8}$/', $n)) {
            return null;
        }
        return '+234' . $n;
    }

    /** Termii expects the number without the leading plus. */
    public static function forTermii(string $e164): string
    {
        return ltrim($e164, '+');
    }
}
