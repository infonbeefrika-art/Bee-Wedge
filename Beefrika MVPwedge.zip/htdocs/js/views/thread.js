import { h, field, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { levelBadge, miniJar, bee } from '../honey.js';
import { api, state } from '../api.js';
import { shell, refreshSummary } from '../ui.js';
import { naira, formatTime, statusLabel } from '../format.js';
import { reportPanel } from './report.js';

const PRIMARY = ['accept', 'confirm_hire', 'complete'];

export async function threadView(id, rerender) {
  const d = await api('/requests/' + id);
  const r = d.request;
  const role = d.role;
  const ctx = { status: r.status, hire: d.hire ? d.hire.status : null };

  const row = (label, value) => (value ? h('div', { class: 'kv' }, h('span', { class: 'muted' }, label), h('span', {}, value)) : '');
  const who = role === 'employer'
    ? h('div', { class: 'card' }, h('div', { class: 'muted' }, T.to),
        h('a', { href: '#/w/' + d.other.beefrika_id }, h('b', {}, d.other.name)),
        h('div', { class: 'muted' }, [d.other.trade, d.other.area].filter(Boolean).join(' \u00B7 ')),
        h('div', { class: 'evhead' }, levelBadge(d.other.headline_level), h('span', { class: 'hint' }, T.headlineLevel[d.other.headline_level])))
    : h('div', { class: 'card' }, h('div', { class: 'muted' }, T.from),
        h('b', {}, d.other.business_name || d.other.name),
        h('div', { class: 'muted' }, [d.other.business_name ? d.other.name : null, d.other.employer_type ? T.types[d.other.employer_type] : null, d.other.area].filter(Boolean).join(' \u00B7 ')),
        h('div', { class: 'evhead' }, levelBadge(d.other.business_trust), h('span', { class: 'hint' }, T.bizLevel[d.other.business_trust])));

  const pay = r.pay_offer_ngn ? `${naira(r.pay_offer_ngn)} ${T.periods[r.pay_period] || ''}` : '';
  const details = h('div', { class: 'card' }, h('b', {}, T.jobDetails),
    row(T.jobType, T[r.engagement_type]), row(T.jobPay, pay), row(T.jobHours, r.working_hours), row(T.jobWhere, r.location_note));

  // hire summary
  let hireCard = '';
  if (d.hire) {
    const hs = d.hire.status;
    const line = hs === 'pending_confirmation' ? (role === 'employer' ? T.hireWaitWorker : T.hireWaitEmployer) : hs === 'completed' ? T.hireDone : T.hireConfirmed;
    hireCard = h('div', { class: 'card honeycard' }, h('b', {}, T.hireBox), h('p', {}, line),
      row(T.hireAgreedPay, d.hire.agreed_pay_ngn ? naira(d.hire.agreed_pay_ngn) : ''), row(T.hireStart, d.hire.start_date),
      d.hire.fee && hs !== 'pending_confirmation'
        ? [row(T.feeYours, d.hire.fee.amount ? `${naira(d.hire.fee.amount)} (${d.hire.fee.multiplier}x)` : T.feeNotSet), h('p', { class: 'hint' }, T.feeRecorded)] : '');
  }

  // actions
  const err = h('div');
  const doAct = async (action, extra = {}) => {
    err.replaceChildren();
    if (T.actAsk[action] && !window.confirm(T.actAsk[action])) return;
    try { await api(`/requests/${id}/action`, 'POST', { action, ...extra }); rerender(); }
    catch (e) { err.replaceChildren(note('err', e.message)); }
  };
  const actions = h('div', { class: 'actions' });
  for (const a of d.actions) {
    if (a === 'propose_hire') {
      const pay2 = h('input', { type: 'number', inputmode: 'numeric', min: 1, value: r.pay_offer_ngn || '' });
      const start = h('input', { type: 'date' });
      const go = h('button', { class: 'btn', onclick: async () => { setBusy(go, true); await doAct('propose_hire', { agreed_pay_ngn: pay2.value, start_date: start.value }); setBusy(go, false); } }, T.act.propose_hire);
      actions.append(h('div', { class: 'card' }, h('p', { class: 'hint' }, T.proposeHint),
        d.fee_preview ? h('p', { class: 'hint' }, `${T.feeIfHired}: ${naira(d.fee_preview)}`) : '',
        ...field(T.hireAgreedPay, pay2), ...field(T.hireStart, start), go));
    } else {
      const b = h('button', { class: 'btn' + (PRIMARY.includes(a) ? '' : ' ghost'), onclick: () => doAct(a) }, T.act[a]);
      actions.append(b);
    }
  }

  // chat
  const list = h('div', { class: 'chat', role: 'log', 'aria-live': 'polite' });
  const jars = new Map();
  let lastId = 0;
  let seenUpTo = 0;
  const reportSlot = h('div');
  const bubble = (m) => {
    if (m.kind === 'system') {
      const t = T.sys[m.body];
      return h('div', { class: 'sysmsg' }, bee(14), t ? t[m.mine ? 0 : 1] : '');
    }
    const meta = h('div', { class: 'bmeta' }, formatTime(m.created_at));
    if (m.mine) {
      const jar = h('span', { class: 'jarwrap' }, miniJar(m.id <= seenUpTo));
      if (m.id <= seenUpTo) jar.dataset.seen = '1';
      jars.set(m.id, jar);
      meta.append(jar);
    } else {
      meta.append(h('button', { class: 'link tiny', onclick: () => { reportSlot.replaceChildren(reportPanel({ target_type: 'message', target_id: m.id }, () => reportSlot.replaceChildren())); reportSlot.scrollIntoView(); } }, T.reportMsg));
    }
    return h('div', { class: 'bubble ' + (m.mine ? 'mine' : 'theirs') }, h('div', { class: 'btext' }, m.body), meta);
  };
  const paintSeen = () => { for (const [mid, el] of jars) if (mid <= seenUpTo && !el.dataset.seen) { el.replaceChildren(miniJar(true)); el.dataset.seen = '1'; } };
  const toBottom = () => { if (list.lastElementChild) list.lastElementChild.scrollIntoView({ block: 'end' }); };

  async function pull() {
    const data = await api(`/requests/${id}/messages?after=${lastId}`);
    if (data.seen_up_to > seenUpTo) { seenUpTo = data.seen_up_to; paintSeen(); }
    data.messages.forEach((m) => { list.append(bubble(m)); lastId = Math.max(lastId, m.id); });
    if (data.messages.length) toBottom();
    const hs = data.hire_status === 'cancelled' ? null : (data.hire_status || null);
    if (data.status !== ctx.status || hs !== ctx.hire) { saveDraft(); rerender(); return; }
    refreshSummary();
  }

  const box = h('textarea', { class: 'composer', rows: 2, maxlength: 1000, placeholder: T.msgPlaceholder });
  box.value = state.drafts[id] || '';
  const saveDraft = () => { state.drafts[id] = box.value; };
  const msgErr = h('div');
  const sendBtn = h('button', { class: 'btn', onclick: async () => {
    const body = box.value;
    if (!body.trim()) return;
    msgErr.replaceChildren(); setBusy(sendBtn, true);
    try {
      const res = await api(`/requests/${id}/messages`, 'POST', { body });
      box.value = ''; delete state.drafts[id];
      list.append(bubble(res.message)); lastId = Math.max(lastId, res.message.id); toBottom();
    } catch (e) { msgErr.replaceChildren(note('err', e.message)); }
    setBusy(sendBtn, false);
  } }, T.msgSend);
  const composer = d.can_message
    ? h('div', { class: 'composerwrap' }, box, h('p', { class: 'hint' }, T.msgLinks), msgErr, sendBtn)
    : h('p', { class: 'muted' }, T.msgClosed);

  const view = shell('/requests',
    h('a', { class: 'link', href: '#/requests' }, '\u2190 ' + T.back),
    h('h1', {}, r.title),
    h('span', { class: 'chip-s ' + (['accepted', 'hired', 'completed'].includes(r.status) ? 'good' : 'warn') }, statusLabel(T, role, r.status)),
    who, details, hireCard, err, actions, h('div', { class: 'divider' }), list, reportSlot, composer);

  setTimeout(async () => {
    try { await pull(); toBottom(); } catch (e) { list.append(note('err', e.message)); return; }
    state.poll = setInterval(() => {
      if (!list.isConnected) { clearInterval(state.poll); state.poll = null; return; }
      if (document.visibilityState === 'visible') pull().catch(() => {});
    }, 4000);
  }, 0);
  return view;
}
