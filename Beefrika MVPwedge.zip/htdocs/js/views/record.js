import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { idCard } from './idcard.js';
import { honeyJar, levelBadge } from '../honey.js';
import { api, state } from '../api.js';
import { shell } from '../ui.js';
import { trustBadges, evidenceBox, emailBox, passwordBox, checklistView } from './shared.js';
import { shareCard } from './share.js';

export async function recordView(flash, rerender) {
  const { profile } = await api('/worker/profile');
  const meta = state.meta;
  const trade = select(meta.trades.map((t) => ({ value: t.id, label: t.name })), profile.primary_trade_id, T.choose);
  const area = select(meta.areas.map((a) => ({ value: a.id, label: a.name })), profile.area_id, T.choose);
  const band = select(meta.bands.map((b) => ({ value: b, label: T.bands[b][0] })), profile.experience_band, T.choose);
  const years = h('input', { type: 'number', inputmode: 'numeric', min: 0, max: 60, value: profile.years_experience ?? '' });
  const headline = h('input', { type: 'text', maxlength: 100, placeholder: T.headlineHint, value: profile.headline });
  const bio = h('textarea', { maxlength: 600 }, profile.bio);
  const avail = select(Object.entries(T.availOpts).map(([k, v]) => ({ value: k, label: v })), profile.availability);
  const disc = h('input', { type: 'checkbox', id: 'disc', checked: profile.is_discoverable });
  const pub = h('input', { type: 'checkbox', id: 'pub', checked: profile.is_public });
  const err = h('div');
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      await api('/worker/profile', 'PUT', { primary_trade_id: trade.value, area_id: area.value, years_experience: years.value, experience_band: band.value,
        headline: headline.value, bio: bio.value, availability: avail.value, is_discoverable: disc.checked, is_public: pub.checked });
      return rerender(note('ok', T.saved));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.save);
  return shell('/record',
    flash || '',
    state.summary && state.summary.todo ? h('a', { class: 'msg info bannerlink', href: '#/requests' }, T.todoBanner(state.summary.todo)) : '',
    h('h1', {}, `${T.welcome}, ${state.me.full_name.split(' ')[0]}`),
    h('div', { class: 'jarcard card' }, honeyJar(profile.completion), h('div', {}, h('b', {}, T.jarTitle(profile.completion)), h('p', { class: 'muted' }, T.jarSub))),
    checklistView(profile.checklist, T.checklist),
    idCard({ worker: true, isPublic: profile.is_public }),
    h('h2', {}, T.trustTitle), trustBadges(state.me.trust),
    h('div', { class: 'card' }, h('div', { class: 'evhead' }, levelBadge(profile.trust.headline), h('span', { class: 'muted' }, T.headlineLevel[profile.trust.headline]))),
    h('h2', {}, T.navRecord),
    ...field(T.trade, trade), ...field(T.area, area), ...field(T.band, band), ...field(T.years, years),
    ...field(T.headline, headline), ...field(T.bio, bio), ...field(T.avail, avail),
    h('div', { class: 'checkrow' }, disc, h('label', { for: 'disc' }, T.discover)),
    h('div', { class: 'checkrow' }, pub, h('label', { for: 'pub' }, T.shareToggle)),
    h('p', { class: 'hint' }, T.discoverNeed), err, btn,
    h('a', { class: 'card bannerlink', href: '#/vouches' }, T.vcBanner),
    shareCard(profile, state.me, meta),
    evidenceBox(), emailBox(), passwordBox());
}
