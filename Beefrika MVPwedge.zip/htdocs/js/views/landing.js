import { h } from '../dom.js';
import { T } from '../strings.js';
import { brand, bee, hexBadge, levelBadge } from '../honey.js';
import { go } from '../ui.js';

export function landing() {
  const legend = ['self_reported', 'evidence', 'verified'].map((l) =>
    h('div', { class: 'card' }, levelBadge(l), h('p', { class: 'muted' }, T.levels[l].meaning)));
  const steps = T.steps.map(([title, text], i) =>
    h('li', { class: 'step' }, h('span', { class: 'stepno' }, hexBadge('self_reported', 34), h('b', {}, String(i + 1))), h('div', {}, h('b', {}, title), h('p', { class: 'muted' }, text))));
  return [
    h('div', { class: 'hero' }, brand(),
      h('p', { class: 'eyebrow' }, bee(20), T.earlyAccess),
      h('h1', {}, T.heroTitle), h('p', { class: 'lead' }, T.heroSub),
      h('button', { class: 'btn', onclick: () => go('/join?role=employer') }, T.iHire),
      h('button', { class: 'btn ghost', onclick: () => go('/join?role=worker') }, T.iWork),
      h('button', { class: 'link', onclick: () => go('/login') }, T.login),
      h('p', { class: 'muted' }, T.freeNote)),
    h('h2', {}, T.truthTitle), h('p', { class: 'muted' }, T.truthSub), ...legend,
    h('h2', {}, T.stepsTitle), h('ol', { class: 'steps' }, steps),
    h('h2', {}, T.feeTitle), h('p', {}, T.feeBody),
    h('ul', { class: 'plain' }, h('li', {}, T.feeShort), h('li', {}, T.feeContract)),
    h('p', { class: 'muted' }, T.feeNote),
    h('h2', {}, T.notTitle), h('ul', { class: 'plain' }, T.notList.map((t) => h('li', {}, t))),
  ];
}
