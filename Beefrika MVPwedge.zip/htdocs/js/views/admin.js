import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { levelBadge, emptyHive } from '../honey.js';
import { api } from '../api.js';
import { shell } from '../ui.js';
import { naira, barHeights } from '../format.js';
import { photoThumb } from './photos.js';
import { drops } from '../honey.js';

export async function adminView(opts, flash, rerender) {
  const { section, status } = opts;
  const tabs = (items, current, key) => h('div', { class: 'chips wrap' }, Object.entries(items).map(([k, label]) =>
    h('button', { type: 'button', class: 'chip', 'aria-pressed': String(k === current), onclick: () => rerender(null, { ...opts, [key]: k, ...(key === 'section' ? { status: undefined } : {}) }) }, label)));
  const top = tabs(T.adminSections, section, 'section');
  let body;
  if (section === 'fees') body = await feesBody(opts, tabs, rerender);
  else if (section === 'reports') body = await reportsBody(opts, tabs, rerender);
  else if (section === 'vouches') body = await vouchesBody(opts, tabs, rerender);
  else if (section === 'traction') body = await tractionBody();
  else if (section === 'invites') body = await invitesBody(opts, rerender);
  else if (section === 'people') body = await peopleBody(opts, rerender);
  else body = await proofBody(opts, tabs, rerender);
  return shell('/admin', flash || '', h('h1', {}, T.adminTitle), top, body);
}

async function proofBody(opts, tabs, rerender) {
  const status = opts.status || 'evidence_submitted';
  const data = await api('/admin/verifications?status=' + encodeURIComponent(status));
  const items = data.items.map((it) => {
    const head = [h('div', { class: 'evhead' }, levelBadge(it.level), h('b', {}, it.label)),
      h('div', { class: 'hint' }, `${it.person.name} \u00B7 ${it.person.beefrika_id} \u00B7 ${it.person.role} \u00B7 ${T.claimTypes[it.claim_type] || it.claim_type}`),
      it.detail ? h('p', { class: 'evdetail prewrap' }, it.detail) : '',
      it.photos && it.photos.length ? h('div', { class: 'photos' }, it.photos.map((id) => photoThumb(id, it.label))) : '',
      it.source_name ? h('div', { class: 'hint' }, T.confirmedBy(it.source_name)) : '',
      it.review_note ? h('div', { class: 'msg info' }, it.review_note) : ''];
    if (status !== 'evidence_submitted') return h('div', { class: 'card' }, ...head);
    const err = h('div');
    const src = select(Object.entries(T.srcOpts).map(([v, l]) => ({ value: v, label: l })), 'admin');
    const srcName = h('input', { type: 'text', maxlength: 120 });
    const rn = h('textarea', { maxlength: 500 });
    const send = async (decision, btn) => {
      err.replaceChildren(); setBusy(btn, true);
      try {
        await api(`/admin/verifications/${it.id}/decide`, 'POST', { decision, source: src.value, source_name: srcName.value, review_note: rn.value });
        rerender(note('ok', T.decided), opts);
      } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    };
    const v = h('button', { class: 'btn', onclick: () => send('verify', v) }, T.verifyBtn);
    const r = h('button', { class: 'btn ghost', onclick: () => send('reject', r) }, T.rejectBtn);
    return h('div', { class: 'card' }, ...head, ...field(T.srcLabel, src), ...field(T.srcName, srcName), ...field(T.reviewNote, rn), err, v, r);
  });
  return [tabs(T.adminTabs, status, 'status'), items.length ? items : emptyHive(T.adminEmpty)];
}

async function feesBody(opts, tabs, rerender) {
  const status = opts.status || 'due';
  const data = await api('/admin/hires?fee_status=' + encodeURIComponent(status));
  const items = data.items.map((it) => {
    const err = h('div');
    const st = select(Object.entries(T.feeStatus).map(([v, l]) => ({ value: v, label: l })), it.fee_status);
    const amount = h('input', { type: 'number', inputmode: 'numeric', min: 0, value: it.fee_amount_ngn ?? '' });
    const note2 = h('input', { type: 'text', maxlength: 255, value: it.fee_note || '' });
    const save = h('button', { class: 'btn', onclick: async () => {
      err.replaceChildren(); setBusy(save, true);
      try { await api(`/admin/hires/${it.id}/fee`, 'POST', { fee_status: st.value, fee_amount_ngn: amount.value, fee_note: note2.value }); rerender(note('ok', T.decided), opts); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(save, false); }
    } }, T.feeSet);
    return h('div', { class: 'card' },
      h('b', {}, `${it.employer} \u2192 ${it.worker}`), h('div', { class: 'hint' }, `${it.worker_bfid} \u00B7 ${T[it.engagement_type]} \u00B7 ${it.status}${it.agreed_pay_ngn ? ' \u00B7 ' + naira(it.agreed_pay_ngn) : ''}`),
      h('p', {}, it.fee_amount_ngn ? `${T.feeYours}: ${naira(it.fee_amount_ngn)} (${it.fee_multiplier}x)` : T.feeNotSet),
      it.fee_note ? h('div', { class: 'msg info' }, it.fee_note) : '',
      ...field(T.feeStatusLabel, st), ...field(T.feeAmount, amount), ...field(T.feeNote2, note2), err, save);
  });
  return [h('p', { class: 'hint' }, T.feeLedgerNote), tabs(T.feeStatus, status, 'status'), items.length ? items : emptyHive(T.adminEmpty)];
}

async function reportsBody(opts, tabs, rerender) {
  const status = opts.status || 'open';
  const data = await api('/admin/reports?status=' + encodeURIComponent(status));
  const items = data.items.map((it) => {
    const t = it.target;
    const head = [h('b', {}, T.reasons[it.reason] || it.reason),
      h('div', { class: 'hint' }, `${T.reporter}: ${it.reporter.name} (${it.reporter.beefrika_id})`),
      h('div', { class: 'hint' }, `${t.name} \u00B7 ${t.beefrika_id}${t.role ? ' \u00B7 ' + t.role : ''}${t.account_status === 'suspended' ? ' \u00B7 suspended' : ''}`),
      t.type === 'message' ? h('div', { class: 'evdetail prewrap' }, h('span', { class: 'hint' }, T.reportedMsg + ': '), t.body) : '',
      it.details ? h('p', {}, it.details) : '', it.resolution_note ? h('div', { class: 'msg info' }, it.resolution_note) : ''];
    if (status !== 'open') return h('div', { class: 'card' }, ...head);
    const err = h('div');
    const rn = h('textarea', { maxlength: 500 });
    const act = async (s, btn) => {
      err.replaceChildren(); setBusy(btn, true);
      try { await api(`/admin/reports/${it.id}/resolve`, 'POST', { status: s, resolution_note: rn.value }); rerender(note('ok', T.decided), opts); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    };
    const a = h('button', { class: 'btn', onclick: () => act('resolved', a) }, T.repResolve);
    const b = h('button', { class: 'btn ghost', onclick: () => act('dismissed', b) }, T.repDismiss);
    const why = h('input', { type: 'text', maxlength: 300 });
    const sus = h('button', { class: 'btn ghost', onclick: async () => {
      err.replaceChildren(); setBusy(sus, true);
      try { await api(`/admin/users/${t.beefrika_id}/status`, 'POST', { status: t.account_status === 'suspended' ? 'active' : 'suspended', note: why.value }); rerender(note('ok', T.decided), opts); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(sus, false); }
    } }, t.account_status === 'suspended' ? T.unsuspend : T.suspend);
    return h('div', { class: 'card' }, ...head, ...field(T.repNote, rn), a, b, h('hr'), ...field(T.suspendReason, why), sus, err);
  });
  return [tabs(T.repTabs, status, 'status'), items.length ? items : emptyHive(T.adminEmpty)];
}

async function tractionBody() {
  const s = await api('/admin/stats');
  const x = T.tr;
  const stat = (label, value) => h('div', { class: 'stat' }, h('div', { class: 'statn num' }, String(value)), h('div', { class: 'hint' }, label));
  const group = (title, cards) => [h('h2', {}, title), h('div', { class: 'stats' }, cards)];
  const heights = barHeights(s.growth.signups.map((d) => d.n));
  const bars = h('div', { class: 'bars', role: 'img', 'aria-label': x.signups }, s.growth.signups.map((d, i) => {
    const b = h('div', { class: 'bar', title: `${d.day}: ${d.n}` });
    b.style.height = heights[i] + '%';
    return b;
  }));
  const top = s.growth.top_referrers.length
    ? h('ul', { class: 'plain' }, s.growth.top_referrers.map((r) => h('li', {}, `${r.name} (${r.beefrika_id}): ${r.n}`)))
    : h('p', { class: 'muted' }, x.none);
  return [
    ...group(x.people, [stat(x.workers, s.people.workers), stat(x.employers, s.people.employers)]),
    ...group(x.funnel, [stat(x.profile70, s.workers.profile_70), stat(x.discoverable, s.workers.discoverable), stat(x.publicPages, s.workers.public_pages)]),
    ...group(x.proof, [stat(x.pending, s.proof.pending), stat(x.verified, s.proof.verified), stat(x.photos, s.proof.photos)]),
    ...group(x.hiring, [stat(x.requests, s.hiring.requests), stat(x.accepted, s.hiring.accepted), stat(x.hires, s.hiring.hires), stat(x.completed, s.hiring.completed)]),
    ...group(x.fees, [stat(x.feeOpen, naira(s.fees.open_ngn)), stat(x.feePaid, naira(s.fees.paid_ngn))]),
    ...group(x.growth, [stat(x.views7, s.growth.views_7d), stat(x.viewsAll, s.growth.views_total), stat(x.viaPages, s.growth.signups_via_pages)]),
    ...group(x.vouches, [stat(x.vWithLink, s.vouches.workers_with_link), stat(x.vOpened, s.vouches.links_opened), stat(x.vWorkers, s.vouches.workers_vouched), stat(x.vTotal, s.vouches.vouches), stat(x.vWaiting, s.vouches.waiting)]),
    h('p', { class: 'muted' }, x.vCohort(s.vouches.cohort_vouched_14d, s.vouches.cohort_eligible)),
    h('h2', {}, x.signups), bars, h('h2', {}, x.top), top,
  ];
}

async function invitesBody(opts, rerender) {
  const x = T.inv;
  const data = await api('/admin/invites');
  const role = select(Object.entries(T.roleNames).map(([v, l]) => ({ value: v, label: l })), 'worker');
  const uses = h('input', { type: 'number', inputmode: 'numeric', min: 1, max: 200, value: 1 });
  const days = h('input', { type: 'number', inputmode: 'numeric', min: 0, max: 90, value: 14 });
  const noteIn = h('input', { type: 'text', maxlength: 120, placeholder: x.noteHint });
  const count = h('input', { type: 'number', inputmode: 'numeric', min: 1, max: 20, value: 1 });
  const err = h('div');
  const make = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(make, true);
    try {
      const r = await api('/admin/invites', 'POST', { role: role.value, max_uses: uses.value, expires_days: days.value, note: noteIn.value, count: count.value });
      rerender(h('div', { class: 'msg ok' }, h('b', {}, x.fresh), h('div', { class: 'codes' }, r.codes.map((c) => h('div', { class: 'bfid' }, c)))), opts);
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(make, false); }
  } }, x.make);
  const items = data.items.map((it) => {
    const off = it.status === 'active' ? h('button', { class: 'link', onclick: async () => { try { await api(`/admin/invites/${it.id}/deactivate`, 'POST', {}); rerender(null, opts); } catch (e) { err.replaceChildren(note('err', e.message)); } } }, x.off) : '';
    return h('div', { class: 'card' }, h('div', { class: 'wtop' }, h('b', { class: 'bfid' }, it.code), h('span', { class: 'chip-s ' + (it.status === 'active' ? 'good' : 'warn') }, x.status[it.status])),
      h('div', { class: 'hint' }, [T.roleNames[it.role], x.used(it.uses, it.max_uses), it.expires_at ? x.until(it.expires_at) : null, it.note].filter(Boolean).join(' \u00B7 ')), off);
  });
  return [h('div', { class: 'card' }, h('h2', {}, x.title), ...field(x.role, role), ...field(x.uses, uses), ...field(x.days, days), ...field(x.note, noteIn), ...field(x.count, count), err, make),
    h('h2', {}, x.list), items.length ? items : emptyHive(x.none)];
}

async function peopleBody(opts, rerender) {
  const x = T.ppl;
  const q = h('input', { type: 'search', maxlength: 60, placeholder: x.search, enterkeyhint: 'search' });
  const out = h('div');
  const err = h('div');
  const run = async () => {
    out.replaceChildren(); err.replaceChildren();
    try {
      const { items } = await api('/admin/people?q=' + encodeURIComponent(q.value.trim()));
      if (!items.length) { out.append(emptyHive(x.none)); return; }
      for (const p of items) {
        const result = h('div');
        const reset = h('button', { class: 'btn ghost', onclick: async () => {
          if (!window.confirm(x.ask)) return;
          setBusy(reset, true);
          try { const r = await api(`/admin/people/${p.beefrika_id}/reset-password`, 'POST', {}); result.replaceChildren(h('div', { class: 'msg ok' }, h('div', { class: 'hint' }, x.temp), h('div', { class: 'bfid' }, r.temporary_password), h('p', { class: 'hint' }, x.tempNote))); }
          catch (e) { result.replaceChildren(note('err', e.message)); }
          setBusy(reset, false);
        } }, x.reset);
        out.append(h('div', { class: 'card' }, h('b', {}, p.name), h('div', { class: 'hint' }, `${p.beefrika_id} \u00B7 ${p.role}${p.status === 'suspended' ? ' \u00B7 suspended' : ''}`),
          h('div', { class: 'hint' }, p.phone), h('div', { class: 'hint' }, [p.phone_confirmed ? x.confirmed : x.unconfirmed, p.signup_via === 'invite' ? x.viaInvite : null].filter(Boolean).join(' \u00B7 ')),
          p.role === 'admin' ? '' : reset, result));
      }
    } catch (e) { err.replaceChildren(note('err', e.message)); }
  };
  const find = h('button', { class: 'btn', onclick: run }, x.find);
  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') run(); });
  return [h('div', { class: 'card' }, q, find), err, out];
}

async function vouchesBody(opts, tabs, rerender) {
  const tab = opts.status || 'review';
  const data = await api('/admin/vouches?tab=' + encodeURIComponent(tab));
  const items = data.items.map((it) => {
    const head = [h('div', { class: 'evhead' }, drops(it.rating), h('b', {}, `${it.customer}${it.area ? ', ' + it.area : ''}`)),
      h('div', { class: 'hint' }, `${T.vcJobTypes[it.job_type] || it.job_type} \u00B7 for ${it.worker.name} (${it.worker.beefrika_id})`),
      it.comment ? h('p', { class: 'evdetail prewrap' }, it.comment) : '',
      it.hold_reason ? h('div', { class: 'msg info' }, T.vcHold[it.hold_reason] || it.hold_reason) : '',
      it.worker_flag_reason ? h('div', { class: 'msg info' }, `${T.vcFlagBy}: ${T.vcFlagReasons[it.worker_flag_reason] || it.worker_flag_reason}`) : '',
      it.review_note ? h('div', { class: 'hint' }, it.review_note) : ''];
    if (tab !== 'review') return h('div', { class: 'card' }, ...head);
    const err = h('div');
    const rn = h('textarea', { maxlength: 500 });
    const act = async (decision, btn) => {
      err.replaceChildren(); setBusy(btn, true);
      try { await api(`/admin/vouches/${it.id}/decide`, 'POST', { decision, note: rn.value }); rerender(note('ok', T.decided), opts); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    };
    const keep = h('button', { class: 'btn', onclick: () => act('approve', keep) }, T.vcKeep);
    const del = h('button', { class: 'btn ghost', onclick: () => act('remove', del) }, T.vcRemove);
    return h('div', { class: 'card' }, ...head, ...field(T.vcAdminNote, rn), keep, del, err);
  });
  return [tabs(T.vcAdminTabs, tab, 'status'), items.length ? items : emptyHive(T.adminEmpty)];
}
