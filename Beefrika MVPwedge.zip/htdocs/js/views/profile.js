import { h, note } from '../dom.js';
import { T } from '../strings.js';
import { levelBadge, hexBadge } from '../honey.js';
import { api } from '../api.js';
import { shell } from '../ui.js';
import { naira } from '../format.js';
import { api as _api, state } from '../api.js';
import { hireBox } from './hirebox.js';
import { photoThumb } from './photos.js';
import { reportPanel } from './report.js';
import { vouchSummary } from './vouches.js';

export async function workerProfileView(id) {
  const { worker: w } = await api('/workers/' + id);
  const bandLabel = w.band ? T.bands[w.band][0] : null;
  const detail = (c) => {
    switch (c.detail_code) {
      case 'name_self': return T.claimDetail.name_self;
      case 'area_self': return T.claimDetail.area_self(c.value);
      case 'experience_self': return T.claimDetail.experience_self(c.years, bandLabel);
      case 'confirmed_by': return T.confirmedBy(c.source || 'Beefrika team');
      default: return T.claimDetail.evidence_only;
    }
  };
  const claims = w.claims.map((c) => h('li', { class: 'claim' },
    h('div', { class: 'evhead' }, levelBadge(c.level), h('b', {}, T.claimNames[c.key] || c.label)),
    h('p', { class: 'muted' }, detail(c)),
    c.photos && c.photos.length ? h('div', { class: 'photos' }, c.photos.map((id) => photoThumb(id, c.label))) : ''));

  const q = w.fee_quotes;
  const feeBox = h('div', { class: 'card' }, h('b', {}, T.feeBoxTitle),
    q ? h('ul', { class: 'plain' }, Object.entries(q).map(([type, v]) => h('li', {}, h('span', {}, `${T[type] || type} (${v.multiplier}x): `), h('b', { class: 'num' }, naira(v.fee)))))
      : h('p', { class: 'muted' }, T.feePending),
    h('p', { class: 'hint' }, T.feeBoxNote));

  const contact = [
    h('li', {}, w.contact_checks.phone ? T.trust.phone.verified : T.trust.phone.unverified),
    h('li', {}, w.contact_checks.email ? T.trust.email.verified : T.trust.email.not_added),
  ];

  const reportSlot = h('div');
  const reportBtn = h('button', { class: 'link', onclick: () => { reportSlot.replaceChildren(reportPanel({ target_type: 'user', target_id: w.beefrika_id }, () => reportSlot.replaceChildren())); } }, T.reportPerson);
  reportSlot.append(reportBtn);

  return shell('/find',
    h('a', { class: 'link', href: '#/find' }, '\u2190 ' + T.back),
    h('h1', {}, w.name),
    h('p', { class: 'muted' }, [w.trade, w.area].filter(Boolean).join(' \u00B7 ') + (w.years !== null ? ' \u00B7 ' + T.yearsText(w.years) : '')),
    h('div', { class: 'card idcard' }, h('div', { class: 'evhead' }, hexBadge('self_reported', 20), h('b', { class: 'bfid' }, w.beefrika_id)),
      h('span', { class: 'chip-s ' + (w.availability === 'available' ? 'good' : 'warn') }, T.availShort[w.availability] || '')),
    h('div', { class: 'card' }, h('div', { class: 'evhead' }, levelBadge(w.trust.headline), h('span', {}, T.headlineLevel[w.trust.headline]))),
    w.headline ? h('p', { class: 'lead' }, w.headline) : '',
    w.about ? [h('h2', {}, T.profAbout), h('p', { class: 'prewrap' }, w.about)] : '',
    h('h2', {}, T.profRecord), h('ul', { class: 'claims' }, claims),
    h('h2', {}, T.profHistory2),
    w.history.length
      ? [h('p', { class: 'muted' }, T.jobsCount(w.jobs_count)),
         h('ul', { class: 'plain' }, w.history.map((j) => h('li', {}, T.histLine(j.title, j.employer, j.year) + (j.engagement_type ? ` (${T[j.engagement_type] || j.engagement_type})` : '')))),
         h('p', { class: 'hint' }, T.histNote)]
      : h('p', { class: 'muted' }, T.profNoHistory),
    ...vouchSummary(w.vouches),
    h('h2', {}, T.profContact), h('ul', { class: 'plain' }, contact), h('p', { class: 'hint' }, T.contactNote),
    state.me.role === 'employer' ? hireBox(w) : feeBox,
    reportSlot);
}
