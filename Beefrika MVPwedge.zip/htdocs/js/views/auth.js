import { h, field, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { brand } from '../honey.js';
import { api, store, loadMe, loadMeta, entry, state } from '../api.js';
import { go } from '../ui.js';

const signup = () => (state.meta && state.meta.signup) || { mode: 'sms', sms_live: false };

export function join(roleHint, after) {
  let role = roleHint === 'employer' ? 'employer' : 'worker';
  return step1({ role }, after);
}

function step1(d, after) {
  const err = h('div');
  const name = h('input', { type: 'text', autocomplete: 'name', maxlength: 80, value: d.name || '' });
  const phone = h('input', { type: 'tel', inputmode: 'tel', autocomplete: 'tel', placeholder: T.phoneHint, value: d.phone || '' });
  const chips = h('div', { class: 'chips' });
  const draw = () => chips.replaceChildren(...['worker', 'employer'].map((r) =>
    h('button', { type: 'button', class: 'chip', 'aria-pressed': String(d.role === r), onclick: () => { d.role = r; draw(); } }, T[r])));
  draw();
  const mode = signup().mode;
  const keep = () => { d.name = name.value; d.phone = phone.value; };
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      keep();
      if (mode === 'invite') return after(stepInvite(d, after));
      const r = await api('/auth/otp/request', 'POST', { phone: phone.value });
      return after(step2(d, r, after));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, mode === 'invite' ? T.continue : T.sendCode);
  return [brand(), h('h1', {}, T.create), mode === 'invite' ? h('p', { class: 'muted' }, T.inviteIntro) : '', h('p', {}, T.roleQ), chips,
    ...field(T.name, name), ...field(T.phone, phone), err, btn,
    mode === 'both' ? h('button', { class: 'link block', onclick: () => { keep(); after(stepInvite(d, after)); } }, T.inviteHave) : '',
    h('button', { class: 'btn ghost', onclick: () => go('/') }, T.back)];
}

function step2(d, sent, after) {
  const err = h('div');
  const code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, pattern: '[0-9]*' });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const resend = h('button', { class: 'link', disabled: true });
  let left = sent.resend_after || 60;
  const tick = () => {
    if (!resend.isConnected) return;
    if (left > 0) { resend.textContent = `${T.resendIn} ${left}s`; resend.disabled = true; left--; setTimeout(tick, 1000); }
    else { resend.textContent = T.resend; resend.disabled = false; }
  };
  resend.addEventListener('click', async () => {
    err.replaceChildren(); resend.disabled = true;
    try { const r = await api('/auth/otp/request', 'POST', { phone: d.phone }); left = r.resend_after || 60; err.replaceChildren(note('ok', T.codeSent)); }
    catch (e) { err.replaceChildren(note('err', e.message)); left = (e.data && e.data.retry_after) || 0; }
    tick();
  });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/register', 'POST', { phone: d.phone, code: code.value.trim(), password: pw.value, full_name: d.name, role: d.role, ref: entry.ref || undefined });
      entry.clearRef(); store.token = r.token; await loadMe(); go('/');
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.finish);
  const view = [brand(), h('h1', {}, T.create), h('p', {}, T.weSent(d.phone)), sent.dev_note ? note('info', sent.dev_note) : '',
    ...field(T.code, code), ...field(T.password, pw, T.passwordHint), err, btn, resend,
    h('button', { class: 'btn ghost', onclick: () => after(step1(d, after)) }, T.back)];
  setTimeout(tick, 0);
  return view;
}

function stepInvite(d, after) {
  const err = h('div');
  const code = h('input', { type: 'text', autocapitalize: 'characters', autocomplete: 'off', maxlength: 12, placeholder: T.inviteHint });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/register', 'POST', { phone: d.phone, invite_code: code.value, password: pw.value, full_name: d.name, role: d.role, ref: entry.ref || undefined });
      entry.clearRef(); store.token = r.token; await loadMe(); go('/');
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.finish);
  return [brand(), h('h1', {}, T.create), h('p', { class: 'muted' }, T.inviteIntro), ...field(T.inviteCode, code), ...field(T.password, pw, T.passwordHint),
    note('info', T.inviteNote), err, btn,
    signup().mode === 'both' ? h('button', { class: 'link block', onclick: async () => {
      try { const r = await api('/auth/otp/request', 'POST', { phone: d.phone }); after(step2(d, r, after)); } catch (e) { err.replaceChildren(note('err', e.message)); }
    } }, T.smsInstead) : '',
    h('button', { class: 'btn ghost', onclick: () => after(step1(d, after)) }, T.back)];
}

export function loginView() {
  const err = h('div');
  const phone = h('input', { type: 'text', inputmode: 'text', autocomplete: 'username', autocapitalize: 'characters', spellcheck: 'false', placeholder: T.loginWhoHint });
  const pw = h('input', { type: 'password', autocomplete: 'current-password', maxlength: 128 });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try { const r = await api('/auth/login', 'POST', { identifier: phone.value, password: pw.value }); store.token = r.token; await loadMe(); go('/'); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.login);
  return [brand(), h('h1', {}, T.login), ...field(T.loginWho, phone), ...field(T.password, pw), err, btn,
    h('a', { class: 'link block', href: '#/forgot' }, T.forgot), h('button', { class: 'btn ghost', onclick: () => go('/') }, T.back)];
}

export function forgotView(after) {
  if (!signup().sms_live) {
    return [brand(), h('h1', {}, T.forgotTitle), note('info', T.resetUnavailable), h('button', { class: 'btn', onclick: () => go('/login') }, T.back)];
  }
  const err = h('div');
  const phone = h('input', { type: 'tel', inputmode: 'tel', autocomplete: 'tel', placeholder: T.phoneHint });
  const send = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(send, true);
    try { const r = await api('/auth/reset/request', 'POST', { phone: phone.value }); after(codeStep(phone.value, r)); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(send, false); }
  } }, T.resetSend);
  function codeStep(ph, sent) {
    const e2 = h('div');
    const code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, pattern: '[0-9]*' });
    const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
    const fin = h('button', { class: 'btn', onclick: async () => {
      e2.replaceChildren(); setBusy(fin, true);
      try { await api('/auth/reset', 'POST', { phone: ph, code: code.value.trim(), password: pw.value }); after([brand(), note('ok', T.resetDone), h('button', { class: 'btn', onclick: () => go('/login') }, T.login)]); }
      catch (e) { e2.replaceChildren(note('err', e.message)); setBusy(fin, false); }
    } }, T.resetFinish);
    return [brand(), h('h1', {}, T.forgotTitle), h('p', {}, T.weSent(ph)), ...field(T.code, code), ...field(T.resetNew, pw, T.passwordHint), e2, fin,
      h('button', { class: 'btn ghost', onclick: () => go('/login') }, T.back)];
  }
  return [brand(), h('h1', {}, T.forgotTitle), ...field(T.phone, phone), err, send, h('button', { class: 'btn ghost', onclick: () => go('/login') }, T.back)];
}
