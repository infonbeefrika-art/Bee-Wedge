import { T } from './strings.js';

export const store = {
  get token() { try { return localStorage.getItem('bf_token'); } catch (e) { return null; } },
  set token(v) { try { v ? localStorage.setItem('bf_token', v) : localStorage.removeItem('bf_token'); } catch (e) { /* storage blocked */ } },
};
export const state = { me: null, meta: null, summary: null, poll: null, drafts: {}, onLogout: () => {} };

async function send(path, method, headers, body) {
  if (store.token) headers.Authorization = 'Bearer ' + store.token;
  let res;
  try {
    res = await fetch('/api' + path, { method, headers, body });
  } catch (e) {
    throw new Error(T.neterr);
  }
  let data = {};
  let parsed = true;
  try { data = await res.json(); } catch (e) { parsed = false; /* non-JSON */ }
  if (res.status === 401 && store.token && !path.startsWith('/auth/')) {
    store.token = null; state.me = null; state.onLogout();
    throw new Error(data.error || 'Please log in.');
  }
  if (!res.ok) { const err = new Error(data.error || 'Something went wrong. Please try again.'); err.data = data; err.status = res.status; throw err; }
  if (!parsed) throw new Error('The server sent an unexpected reply. Please try again in a minute. If it keeps happening, open /api/health and tell the Beefrika team what you see.');
  return data;
}

export function api(path, method = 'GET', body) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return send(path, method, headers, body === undefined ? undefined : JSON.stringify(body));
}

/** Multipart upload. The browser sets the Content-Type (with the boundary) itself. */
export function apiUpload(path, formData) {
  return send(path, 'POST', { Accept: 'application/json' }, formData);
}

const photoCache = new Map();
/** Photos need the login header, so they are fetched and shown from a local blob address. */
export async function photoUrl(id) {
  if (photoCache.has(id)) return photoCache.get(id);
  let res;
  try { res = await fetch('/api/photos/' + id, { headers: { Authorization: 'Bearer ' + store.token } }); } catch (e) { throw new Error(T.neterr); }
  if (!res.ok) throw new Error('Photo not available.');
  const url = URL.createObjectURL(await res.blob());
  photoCache.set(id, url);
  return url;
}

/** Remembers where a person was heading (a worker page) and who sent them, across sign-up and login. */
export const entry = {
  remember(query) {
    try {
      if (query.next) sessionStorage.setItem('bf_next', query.next);
      if (query.ref) sessionStorage.setItem('bf_ref', query.ref);
    } catch (e) { /* storage blocked */ }
  },
  get next() { try { return sessionStorage.getItem('bf_next'); } catch (e) { return null; } },
  get ref() { try { return sessionStorage.getItem('bf_ref'); } catch (e) { return null; } },
  clearNext() { try { sessionStorage.removeItem('bf_next'); } catch (e) { /* ignore */ } },
  clearRef() { try { sessionStorage.removeItem('bf_ref'); } catch (e) { /* ignore */ } },
};

export async function loadMeta() { if (!state.meta) state.meta = await api('/meta'); return state.meta; }
export async function loadMe() {
  const data = await api('/me');
  if (!data.user) throw new Error('Could not load your account. Please log in again.');
  state.me = data.user;
  return state.me;
}
