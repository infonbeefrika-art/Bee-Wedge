// Beefrika brand pieces: bee, hexagon trust badges, honey jar. Shapes carry meaning as well as colour.
import { h, svg } from './dom.js';
import { T } from './strings.js';

const HEX = '12,1.5 21.5,6.8 21.5,17.2 12,22.5 2.5,17.2 2.5,6.8';
let uid = 0;

export function hexBadge(level, size = 22) {
  const id = 'hx' + (++uid);
  const root = svg('svg', { viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': 'true', class: 'hexb' });
  if (level === 'verified') {
    root.append(svg('polygon', { points: HEX, fill: '#F0A500', stroke: '#121212', 'stroke-width': 1.5 }),
      svg('path', { d: 'M7.5 12.4l3 3 6-6.4', fill: 'none', stroke: '#121212', 'stroke-width': 2.2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
  } else if (level === 'evidence') {
    root.append(svg('defs', {}, svg('clipPath', { id }, svg('rect', { x: 0, y: 12, width: 24, height: 12 }))),
      svg('polygon', { points: HEX, fill: '#fff', stroke: '#121212', 'stroke-width': 1.5 }),
      svg('polygon', { points: HEX, fill: '#F0A500', 'clip-path': `url(#${id})` }),
      svg('polygon', { points: HEX, fill: 'none', stroke: '#121212', 'stroke-width': 1.5 }));
  } else if (level === 'rejected') {
    root.append(svg('polygon', { points: HEX, fill: '#fff', stroke: '#A33', 'stroke-width': 1.5 }),
      svg('path', { d: 'M8.5 8.5l7 7M15.5 8.5l-7 7', stroke: '#A33', 'stroke-width': 2, 'stroke-linecap': 'round' }));
  } else {
    root.append(svg('polygon', { points: HEX, fill: '#fff', stroke: '#121212', 'stroke-width': 1.5, 'stroke-dasharray': '3 2' }));
  }
  return root;
}

/** A level label: hexagon shape + the word. */
export function levelBadge(level) {
  const meta = T.levels[level] || T.levels.self_reported;
  return h('span', { class: 'level level-' + level }, hexBadge(level, 18), h('span', {}, meta.label));
}

export function bee(size = 28) {
  // Drawn facing right, then mirrored and turned so the head points up and to the left, like the Beefrika logo.
  return svg('svg', { viewBox: '-3 -3 38 38', width: size, height: size, 'aria-hidden': 'true', class: 'bee' },
   svg('g', { transform: 'rotate(38 16 16) translate(32 0) scale(-1 1)' },
    svg('ellipse', { cx: 11, cy: 9, rx: 6, ry: 3.6, fill: '#fff', stroke: '#121212', 'stroke-width': 1, transform: 'rotate(-25 11 9)' }),
    svg('ellipse', { cx: 19, cy: 8, rx: 6, ry: 3.6, fill: '#fff', stroke: '#121212', 'stroke-width': 1, transform: 'rotate(20 19 8)' }),
    svg('ellipse', { cx: 15, cy: 18, rx: 9, ry: 7, fill: '#F0A500', stroke: '#121212', 'stroke-width': 1.2 }),
    svg('path', { d: 'M12 11.6v12.8M17 11.2v13.6', stroke: '#121212', 'stroke-width': 2.4 }),
    svg('circle', { cx: 25, cy: 17, r: 3.4, fill: '#121212' }),
    svg('path', { d: 'M26 14c1-2 2-2.600 3-2.800M27.500 15.400c1.200-1 2.200-1.200 3-1.200', stroke: '#121212', 'stroke-width': 1, fill: 'none', 'stroke-linecap': 'round' })));
}

export function honeyJar(percent, label) {
  const id = 'jar' + (++uid);
  const p = Math.max(0, Math.min(100, percent));
  const top = 116 - 78 * p / 100;
  const body = 'M28 30h44v6c12 6 16 16 16 28v36c0 10-6 16-16 16H28c-10 0-16-6-16-16V64c0-12 4-22 16-28z';
  const root = svg('svg', { viewBox: '0 0 100 124', width: 96, height: 119, role: 'img', 'aria-label': label || T.jarTitle(p), class: 'jar' },
    svg('defs', {}, svg('clipPath', { id }, svg('path', { d: body }))),
    svg('path', { d: body, fill: '#FFF8E6' }),
    svg('rect', { x: 0, y: top, width: 100, height: 124 - top, fill: '#F0A500', 'clip-path': `url(#${id})` }),
    p > 0 && p < 100 ? svg('ellipse', { cx: 50, cy: top, rx: 38, ry: 3, fill: '#FFBE2E', 'clip-path': `url(#${id})` }) : null,
    svg('path', { d: body, fill: 'none', stroke: '#121212', 'stroke-width': 3 }),
    svg('rect', { x: 24, y: 14, width: 52, height: 16, rx: 4, fill: '#121212' }),
    svg('path', { d: 'M40 60l5 3v6l-5 3-5-3v-6z', fill: 'none', stroke: '#121212', 'stroke-width': 2, opacity: 0.55 }),
    svg('path', { d: 'M55 74l5 3v6l-5 3-5-3v-6z', fill: 'none', stroke: '#121212', 'stroke-width': 2, opacity: 0.55 }));
  return root;
}

export function brand() {
  return h('div', { class: 'brandbar' }, h('img', { src: 'icons/logo-96.png', alt: '', width: 40, height: 40 }), h('b', {}, T.brand));
}

export function emptyHive(text) {
  return h('div', { class: 'empty' }, bee(44), h('p', {}, text));
}

/** Tiny honey jar for message status: empty outline = sent, filled with honey = seen. */
export function miniJar(seen) {
  const body = 'M6 6h6v1.5c2 1 3 2.600 3 4.500v4.500c0 1.200-.8 2-2 2H5c-1.200 0-2-.8-2-2V12c0-1.900 1-3.500 3-4.500z';
  const id = 'mj' + (++uid);
  return svg('svg', { viewBox: '0 0 18 20', width: 18, height: 20, role: 'img', 'aria-label': seen ? T.seen : T.sentLabel, class: 'minijar' + (seen ? ' seen' : '') },
    svg('defs', {}, svg('clipPath', { id }, svg('path', { d: body }))),
    svg('path', { d: body, fill: '#fff' }),
    seen ? svg('rect', { x: 0, y: 8, width: 18, height: 12, fill: '#F0A500', 'clip-path': `url(#${id})` }) : null,
    svg('path', { d: body, fill: 'none', stroke: '#121212', 'stroke-width': 1.300 }),
    svg('rect', { x: 5, y: 2, width: 8, height: 3, rx: 1, fill: '#121212' }));
}

const DROP = 'M12 2.5C12 2.5 5.5 10 5.5 15a6.5 6.5 0 0 0 13 0C18.5 10 12 2.5 12 2.5z';

/** One honey drop: filled = honey, empty = white outline. Used for customer ratings. */
export function dropIcon(filled, size = 18) {
  return svg('svg', { viewBox: '0 0 24 24', width: size, height: size, 'aria-hidden': 'true', class: 'drop' },
    svg('path', { d: DROP, fill: filled ? '#F0A500' : '#fff', stroke: '#121212', 'stroke-width': 1.5 }));
}

export function drops(rating) {
  const wrap = h('span', { class: 'drops', role: 'img', 'aria-label': `${rating} out of 5 honey drops` });
  for (let i = 1; i <= 5; i++) wrap.append(dropIcon(i <= rating));
  return wrap;
}
