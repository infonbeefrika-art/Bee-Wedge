<?php
declare(strict_types=1);

// Two layouts: public/ + src/ side by side (normal), or "flat" (htdocs/api + htdocs/src) for hosts that cannot change the document root.
$bfBase = is_dir(dirname(__DIR__) . '/src') ? dirname(__DIR__) : dirname(__DIR__, 2);
require $bfBase . '/src/bootstrap.php';

use Beefrika\ApiException;
use Beefrika\Controllers\AdminController;
use Beefrika\Controllers\AuthController;
use Beefrika\Controllers\EmployerController;
use Beefrika\Controllers\EvidenceController;
use Beefrika\Controllers\HiringController;
use Beefrika\Controllers\MessageController;
use Beefrika\Controllers\PhotoController;
use Beefrika\Controllers\StatsController;
use Beefrika\Controllers\VouchController;
use Beefrika\Controllers\ReportController;
use Beefrika\Controllers\MeController;
use Beefrika\Controllers\MetaController;
use Beefrika\Controllers\WorkerController;
use Beefrika\Controllers\WorkerSearchController;
use Beefrika\Db;
use Beefrika\Http;

Http::securityHeaders();
Http::cors();

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $path = '/' . trim(preg_replace('#^/api#', '', $path) ?? '', '/');

    if ($method === 'GET' && $path === '/health') {
        Http::send(['ok' => true]);
    }

    $db = Db::pdo();
    $in = in_array($method, ['POST', 'PUT'], true) ? Http::body() : [];
    $result = null;

    // Routes with an id in the path: [method, pattern, handler]
    $withId = [
        ['GET',    '#^/workers/(BF-[A-Z0-9]{6})$#',            fn($m) => (new WorkerSearchController($db))->show($m[1])],
        ['POST',   '#^/me/evidence/(\d{1,12})/photos$#',      fn($m) => (new PhotoController($db))->add((int)$m[1], $_FILES['photo'] ?? [])],
        ['DELETE', '#^/me/evidence/photos/(\d{1,12})$#',       fn($m) => (new PhotoController($db))->remove((int)$m[1])],
        ['GET',    '#^/photos/(\d{1,12})$#',                   fn($m) => (new PhotoController($db))->stream((int)$m[1])],
        ['DELETE', '#^/me/evidence/(\d{1,12})$#',              fn($m) => (new EvidenceController($db))->remove((int)$m[1])],
        ['GET',    '#^/requests/(\d{1,12})$#',                 fn($m) => (new HiringController($db))->show((int)$m[1])],
        ['POST',   '#^/requests/(\d{1,12})/action$#',          fn($m) => (new HiringController($db))->act((int)$m[1], $in)],
        ['GET',    '#^/requests/(\d{1,12})/messages$#',        fn($m) => (new MessageController($db))->list((int)$m[1], $_GET)],
        ['POST',   '#^/requests/(\d{1,12})/messages$#',        fn($m) => (new MessageController($db))->send((int)$m[1], $in)],
        ['POST',   '#^/admin/verifications/(\d{1,12})/decide$#', fn($m) => (new AdminController($db))->decide((int)$m[1], $in)],
        ['POST',   '#^/me/vouches/(\d{1,12})/flag$#',         fn($m) => (new VouchController($db))->flag((int)$m[1], $in)],
        ['POST',   '#^/admin/vouches/(\d{1,12})/decide$#',     fn($m) => (new VouchController($db))->adminDecide((int)$m[1], $in)],
        ['POST',   '#^/admin/hires/(\d{1,12})/fee$#',          fn($m) => (new AdminController($db))->setFee((int)$m[1], $in)],
        ['POST',   '#^/admin/reports/(\d{1,12})/resolve$#',    fn($m) => (new AdminController($db))->resolveReport((int)$m[1], $in)],
        ['POST',   '#^/admin/invites/(\d{1,12})/deactivate$#', fn($m) => (new AdminController($db))->deactivateInvite((int)$m[1])],
        ['POST',   '#^/admin/people/(BF-[A-Z0-9]{6})/reset-password$#', fn($m) => (new AdminController($db))->resetPassword($m[1])],
        ['POST',   '#^/admin/users/(BF-[A-Z0-9]{6})/status$#',  fn($m) => (new AdminController($db))->setUserStatus($m[1], $in)],
    ];
    foreach ($withId as [$verb, $pattern, $handler]) {
        if ($verb === $method && preg_match($pattern, $path, $m)) {
            $result = $handler($m);
            break;
        }
    }
    if ($result === null) {
        $result = match ("$method $path") {
            'GET /meta'                 => (new MetaController($db))->show(),
            'POST /auth/otp/request'    => (new AuthController($db))->requestRegistrationOtp($in),
            'POST /auth/register'       => (new AuthController($db))->register($in),
            'POST /auth/login'          => (new AuthController($db))->login($in),
            'POST /auth/logout'         => (new AuthController($db))->logout(),
            'POST /auth/reset/request'  => (new AuthController($db))->requestPasswordReset($in),
            'POST /auth/reset'          => (new AuthController($db))->resetPassword($in),
            'POST /me/password'         => (new MeController($db))->changePassword($in),
            'GET /admin/people'         => (new AdminController($db))->people($_GET),
            'GET /admin/invites'        => (new AdminController($db))->invites(),
            'POST /admin/invites'       => (new AdminController($db))->createInvites($in),
            'GET /me/vouches'           => (new VouchController($db))->mine(),
            'POST /me/vouches/link'     => (new VouchController($db))->link($in),
            'GET /admin/vouches'        => (new VouchController($db))->adminQueue($_GET),
            'GET /me'                   => (new MeController($db))->show(),
            'POST /me/email/request'    => (new MeController($db))->requestEmailCode($in),
            'POST /me/email/verify'     => (new MeController($db))->verifyEmail($in),
            'GET /me/evidence'          => (new EvidenceController($db))->listMine(),
            'POST /me/evidence'         => (new EvidenceController($db))->add($in),
            'GET /worker/profile'       => (new WorkerController($db))->show(),
            'PUT /worker/profile'       => (new WorkerController($db))->update($in),
            'GET /employer/profile'     => (new EmployerController($db))->show(),
            'PUT /employer/profile'     => (new EmployerController($db))->update($in),
            'GET /workers'              => (new WorkerSearchController($db))->search($_GET),
            'POST /requests'            => (new HiringController($db))->create($in),
            'GET /requests'             => (new HiringController($db))->index(),
            'GET /summary'              => (new HiringController($db))->summary(),
            'POST /reports'             => (new ReportController($db))->create($in),
            'GET /admin/verifications'  => (new AdminController($db))->queue($_GET),
            'GET /admin/hires'          => (new AdminController($db))->hires($_GET),
            'GET /admin/reports'        => (new AdminController($db))->reports($_GET),
            'GET /admin/stats'          => (new StatsController($db))->summary(),
            default                     => throw new ApiException('Not found.', 404),
        };
    }
    Http::send($result);
} catch (ApiException $e) {
    Http::fail($e->getMessage(), $e->status, $e->extra);
} catch (Throwable $e) {
    error_log('Unhandled: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    Http::fail('Something went wrong on our side. Please try again.', 500);
}
