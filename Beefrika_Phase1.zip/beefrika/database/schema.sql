-- Beefrika schema (MySQL 8 / MariaDB 10.4+, utf8mb4). Run once on an empty database.
-- All timestamps are UTC.
SET NAMES utf8mb4;

-- ---------- Identity & access ----------
CREATE TABLE users (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  beefrika_id        VARCHAR(12)  NOT NULL UNIQUE,            -- e.g. BF-7K3M9Q
  role               ENUM('worker','employer','admin') NOT NULL,
  phone              VARCHAR(16)  NOT NULL UNIQUE,            -- E.164
  phone_verified_at  DATETIME NULL,
  email              VARCHAR(190) NULL UNIQUE,
  email_verified_at  DATETIME NULL,
  password_hash      VARCHAR(255) NOT NULL,
  full_name          VARCHAR(80)  NOT NULL,
  status             ENUM('active','suspended') NOT NULL DEFAULT 'active',
  last_login_at      DATETIME NULL,
  created_at         DATETIME NOT NULL,
  updated_at         DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE sessions (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT UNSIGNED NOT NULL,
  token_hash  CHAR(64) NOT NULL UNIQUE,                       -- sha256 of the bearer token
  user_agent  VARCHAR(255) NULL,
  ip_hash     CHAR(64) NULL,
  expires_at  DATETIME NOT NULL,
  revoked_at  DATETIME NULL,
  created_at  DATETIME NOT NULL,
  KEY idx_sessions_user (user_id),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE otp_codes (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  channel     ENUM('sms','email') NOT NULL,
  destination VARCHAR(190) NOT NULL,
  purpose     VARCHAR(40)  NOT NULL,
  code_hash   CHAR(64) NOT NULL,                              -- HMAC, never the code itself
  attempts    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  expires_at  DATETIME NOT NULL,
  used_at     DATETIME NULL,
  ip_hash     CHAR(64) NULL,
  created_at  DATETIME NOT NULL,
  KEY idx_otp_dest (channel, destination, created_at),
  KEY idx_otp_ip (ip_hash, created_at)
) ENGINE=InnoDB;

CREATE TABLE rate_limits (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  k           VARCHAR(160) NOT NULL,
  created_at  DATETIME NOT NULL,
  KEY idx_rate (k, created_at)
) ENGINE=InnoDB;

CREATE TABLE audit_log (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id    BIGINT UNSIGNED NULL,
  action      VARCHAR(60) NOT NULL,
  entity      VARCHAR(40) NOT NULL,
  entity_id   BIGINT UNSIGNED NULL,
  meta        JSON NULL,
  ip_hash     CHAR(64) NULL,
  created_at  DATETIME NOT NULL,
  KEY idx_audit_entity (entity, entity_id)
) ENGINE=InnoDB;

-- ---------- Reference data ----------
CREATE TABLE trades (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name      VARCHAR(60) NOT NULL UNIQUE,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE lagos_areas (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name      VARCHAR(60) NOT NULL UNIQUE,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ---------- Profiles ----------
CREATE TABLE worker_profiles (
  user_id            BIGINT UNSIGNED PRIMARY KEY,
  headline           VARCHAR(100) NOT NULL DEFAULT '',
  bio                TEXT NULL,
  primary_trade_id   INT UNSIGNED NULL,
  area_id            INT UNSIGNED NULL,
  years_experience   TINYINT UNSIGNED NULL,
  availability       ENUM('available','busy','not_looking') NOT NULL DEFAULT 'available',
  is_discoverable    TINYINT(1) NOT NULL DEFAULT 0,
  profile_completion TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at         DATETIME NOT NULL,
  updated_at         DATETIME NOT NULL,
  KEY idx_worker_search (is_discoverable, primary_trade_id, area_id),
  CONSTRAINT fk_wp_user  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_wp_trade FOREIGN KEY (primary_trade_id) REFERENCES trades(id),
  CONSTRAINT fk_wp_area  FOREIGN KEY (area_id) REFERENCES lagos_areas(id)
) ENGINE=InnoDB;

CREATE TABLE employer_profiles (
  user_id        BIGINT UNSIGNED PRIMARY KEY,
  employer_type  ENUM('household','small_business','contractor','organisation') NULL,
  business_name  VARCHAR(120) NULL,
  area_id        INT UNSIGNED NULL,
  address_note   VARCHAR(255) NULL,
  description    TEXT NULL,
  created_at     DATETIME NOT NULL,
  updated_at     DATETIME NOT NULL,
  CONSTRAINT fk_ep_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ep_area FOREIGN KEY (area_id) REFERENCES lagos_areas(id)
) ENGINE=InnoDB;

CREATE TABLE worker_skills (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id          BIGINT UNSIGNED NOT NULL,
  trade_id         INT UNSIGNED NOT NULL,
  years_experience TINYINT UNSIGNED NULL,
  learned_via      ENUM('apprenticeship','training','self_taught','on_the_job') NULL,
  training_org     VARCHAR(120) NULL,
  UNIQUE KEY uq_worker_skill (user_id, trade_id),
  CONSTRAINT fk_ws_user  FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ws_trade FOREIGN KEY (trade_id) REFERENCES trades(id)
) ENGINE=InnoDB;

CREATE TABLE work_history (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       BIGINT UNSIGNED NOT NULL,
  title         VARCHAR(100) NOT NULL,
  employer_name VARCHAR(120) NULL,
  trade_id      INT UNSIGNED NULL,
  start_date    DATE NULL,
  end_date      DATE NULL,
  description   TEXT NULL,
  source        ENUM('self','employer_confirmed','beefrika_hire') NOT NULL DEFAULT 'self',
  created_at    DATETIME NOT NULL,
  CONSTRAINT fk_wh_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Verification (evidence levels) ----------
CREATE TABLE verification_records (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      BIGINT UNSIGNED NOT NULL,
  claim_type   ENUM('identity','skill','work_experience','business','training') NOT NULL,
  claim_ref_id BIGINT UNSIGNED NULL,                           -- e.g. worker_skills.id
  level        ENUM('self_reported','evidence_submitted','verified','rejected') NOT NULL DEFAULT 'self_reported',
  source       ENUM('self','admin','partner_org','employer_confirmation') NOT NULL DEFAULT 'self',
  source_name  VARCHAR(120) NULL,                              -- who verified; always shown with the label
  note         VARCHAR(500) NULL,
  reviewed_by  BIGINT UNSIGNED NULL,
  reviewed_at  DATETIME NULL,
  created_at   DATETIME NOT NULL,
  KEY idx_ver_user (user_id, claim_type),
  CONSTRAINT fk_ver_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE evidence_files (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  verification_id BIGINT UNSIGNED NOT NULL,
  storage_path    VARCHAR(255) NOT NULL,
  mime_type       VARCHAR(80) NOT NULL,
  size_bytes      INT UNSIGNED NOT NULL,
  created_at      DATETIME NOT NULL,
  CONSTRAINT fk_ev_ver FOREIGN KEY (verification_id) REFERENCES verification_records(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Hiring ----------
CREATE TABLE jobs (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employer_id     BIGINT UNSIGNED NOT NULL,
  title           VARCHAR(120) NOT NULL,
  description     TEXT NOT NULL,
  requirements    TEXT NULL,
  working_hours   VARCHAR(160) NULL,
  trade_id        INT UNSIGNED NULL,
  area_id         INT UNSIGNED NULL,
  engagement_type ENUM('short_gig','contract','permanent') NOT NULL,
  pay_min_ngn     INT UNSIGNED NULL,
  pay_max_ngn     INT UNSIGNED NULL,
  pay_period      ENUM('per_job','per_day','per_week','per_month') NULL,
  status          ENUM('draft','pending_review','open','filled','closed','rejected') NOT NULL DEFAULT 'pending_review',
  reviewed_by     BIGINT UNSIGNED NULL,
  created_at      DATETIME NOT NULL,
  updated_at      DATETIME NOT NULL,
  KEY idx_jobs_search (status, trade_id, area_id),
  CONSTRAINT fk_jobs_employer FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_jobs_trade FOREIGN KEY (trade_id) REFERENCES trades(id),
  CONSTRAINT fk_jobs_area  FOREIGN KEY (area_id) REFERENCES lagos_areas(id)
) ENGINE=InnoDB;

CREATE TABLE hiring_requests (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_id      BIGINT UNSIGNED NULL,
  employer_id BIGINT UNSIGNED NOT NULL,
  worker_id   BIGINT UNSIGNED NOT NULL,
  initiated_by ENUM('employer','worker') NOT NULL,
  message     VARCHAR(500) NULL,
  status      ENUM('sent','accepted','declined','withdrawn','hired','cancelled') NOT NULL DEFAULT 'sent',
  created_at  DATETIME NOT NULL,
  updated_at  DATETIME NOT NULL,
  KEY idx_hr_worker (worker_id, status),
  KEY idx_hr_employer (employer_id, status),
  CONSTRAINT fk_hr_job      FOREIGN KEY (job_id)      REFERENCES jobs(id) ON DELETE SET NULL,
  CONSTRAINT fk_hr_employer FOREIGN KEY (employer_id) REFERENCES users(id),
  CONSTRAINT fk_hr_worker   FOREIGN KEY (worker_id)   REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE conversations (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employer_id       BIGINT UNSIGNED NOT NULL,
  worker_id         BIGINT UNSIGNED NOT NULL,
  hiring_request_id BIGINT UNSIGNED NULL,
  created_at        DATETIME NOT NULL,
  UNIQUE KEY uq_conv (employer_id, worker_id),
  CONSTRAINT fk_cv_employer FOREIGN KEY (employer_id) REFERENCES users(id),
  CONSTRAINT fk_cv_worker   FOREIGN KEY (worker_id)   REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE messages (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT UNSIGNED NOT NULL,
  sender_id       BIGINT UNSIGNED NOT NULL,
  body            TEXT NOT NULL,
  read_at         DATETIME NULL,                               -- drives the "seen" (honey jar) indicator
  created_at      DATETIME NOT NULL,
  KEY idx_msg_conv (conversation_id, id),
  CONSTRAINT fk_msg_conv   FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_sender FOREIGN KEY (sender_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE hires (
  id                        BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  hiring_request_id         BIGINT UNSIGNED NOT NULL UNIQUE,
  employer_id               BIGINT UNSIGNED NOT NULL,
  worker_id                 BIGINT UNSIGNED NOT NULL,
  engagement_type           ENUM('short_gig','contract','permanent') NOT NULL,
  agreed_pay_ngn            INT UNSIGNED NULL,
  start_date                DATE NULL,
  confirmed_by_employer_at  DATETIME NULL,
  confirmed_by_worker_at    DATETIME NULL,                     -- both sides must confirm a hire
  status                    ENUM('pending_confirmation','confirmed','completed','disputed','cancelled') NOT NULL DEFAULT 'pending_confirmation',
  completed_at              DATETIME NULL,
  fee_multiplier            DECIMAL(4,2) NULL,                 -- snapshot of the rule used
  fee_amount_ngn            INT UNSIGNED NULL,                 -- tracked, not collected online in v1
  fee_status                ENUM('not_due','due','invoiced','paid','waived') NOT NULL DEFAULT 'not_due',
  created_at                DATETIME NOT NULL,
  updated_at                DATETIME NOT NULL,
  CONSTRAINT fk_hire_hr       FOREIGN KEY (hiring_request_id) REFERENCES hiring_requests(id),
  CONSTRAINT fk_hire_employer FOREIGN KEY (employer_id) REFERENCES users(id),
  CONSTRAINT fk_hire_worker   FOREIGN KEY (worker_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE hiring_fee_rules (
  engagement_type ENUM('short_gig','contract','permanent') PRIMARY KEY,
  multiplier      DECIMAL(4,2) NOT NULL,
  note            VARCHAR(160) NULL
) ENGINE=InnoDB;
-- Base fees by worker category/experience are deliberately NOT seeded: set after pricing validation.

-- ---------- Reputation & safety ----------
CREATE TABLE reviews (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  hire_id     BIGINT UNSIGNED NOT NULL,
  reviewer_id BIGINT UNSIGNED NOT NULL,
  reviewee_id BIGINT UNSIGNED NOT NULL,
  rating      TINYINT UNSIGNED NOT NULL,
  comment     VARCHAR(600) NULL,
  reply       VARCHAR(600) NULL,                               -- right of reply for the reviewed person
  replied_at  DATETIME NULL,
  created_at  DATETIME NOT NULL,
  UNIQUE KEY uq_review (hire_id, reviewer_id),
  CONSTRAINT fk_rev_hire FOREIGN KEY (hire_id) REFERENCES hires(id),
  CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

CREATE TABLE reports (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reporter_id  BIGINT UNSIGNED NOT NULL,
  target_type  ENUM('user','job','message','review') NOT NULL,
  target_id    BIGINT UNSIGNED NOT NULL,
  reason       VARCHAR(60) NOT NULL,
  details      VARCHAR(1000) NULL,
  status       ENUM('open','reviewing','resolved','dismissed') NOT NULL DEFAULT 'open',
  resolved_by  BIGINT UNSIGNED NULL,
  resolved_at  DATETIME NULL,
  created_at   DATETIME NOT NULL,
  KEY idx_reports_status (status, created_at)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    BIGINT UNSIGNED NOT NULL,
  type       VARCHAR(40) NOT NULL,
  title      VARCHAR(120) NOT NULL,
  body       VARCHAR(255) NULL,
  link       VARCHAR(120) NULL,
  read_at    DATETIME NULL,
  created_at DATETIME NOT NULL,
  KEY idx_notif_user (user_id, read_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Seed data ----------
INSERT INTO hiring_fee_rules (engagement_type, multiplier, note) VALUES
  ('short_gig', 0.30, 'working assumption'),
  ('contract',  1.00, 'working assumption'),
  ('permanent', 1.50, 'working assumption');

INSERT INTO trades (name) VALUES
  ('Electrician'),('Plumber'),('Carpenter'),('Tailor / Fashion designer'),('Auto mechanic'),('Welder'),
  ('Painter'),('Tiler / Bricklayer'),('Hairdresser / Barber'),('Driver'),('Dispatch rider'),('Cleaner'),
  ('Cook / Caterer'),('Domestic helper / Nanny'),('AC / Refrigeration technician'),('Phone / Electronics repair'),
  ('Sales / Marketing (informal)'),('Security guard'),('Generator technician'),('Other trade');

INSERT INTO lagos_areas (name) VALUES
  ('Agege'),('Ajah'),('Alimosho'),('Apapa'),('Badagry'),('Epe'),('Festac'),('Gbagada'),('Ibeju-Lekki'),('Ikeja'),
  ('Ikorodu'),('Ikoyi'),('Lekki'),('Magodo'),('Maryland'),('Mushin'),('Ojo'),('Oshodi'),('Surulere'),
  ('Victoria Island'),('Yaba'),('Other Lagos area');
