<?php
declare(strict_types=1);
/**
 * Run:  php tests/run.php
 * Needs PHP 8.1+ with pdo_sqlite. Uses an in-memory SQLite database and frozen time, so it sends no SMS
 * and touches no real data.
 */
require dirname(__DIR__) . '/src/bootstrap.php';

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Env;
use Beefrika\Otp;
use Beefrika\Phone;
use Beefrika\RateLimit;
use Beefrika\Security;

Env::set('OTP_HMAC_SECRET', str_repeat('test-secret-', 4));
Env::set('APP_ENV', 'development');
Clock::freeze(1_800_000_000);

$pass = 0; $fail = 0;
function check(string $name, bool $cond): void { global $pass, $fail; if ($cond) { $pass++; echo "  ok   $name\n"; } else { $fail++; echo "  FAIL $name\n"; } }
function throwsStatus(callable $fn, int $status): bool { try { $fn(); return false; } catch (ApiException $e) { return $e->status === $status; } }

function freshDb(): PDO {
    $db = new PDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $db->exec('CREATE TABLE otp_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT, destination TEXT, purpose TEXT, code_hash TEXT, attempts INTEGER DEFAULT 0, expires_at TEXT, used_at TEXT, ip_hash TEXT, created_at TEXT)');
    $db->exec('CREATE TABLE rate_limits (id INTEGER PRIMARY KEY AUTOINCREMENT, k TEXT, created_at TEXT)');
    $db->exec('CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, status TEXT, role TEXT)');
    $db->exec('CREATE TABLE sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, token_hash TEXT UNIQUE, user_agent TEXT, ip_hash TEXT, expires_at TEXT, revoked_at TEXT, created_at TEXT)');
    return $db;
}
/** Issue a code and return what the "SMS" would have contained. */
function issue(Otp $otp, string $dest = '+2348012345678', string $ip = '1.1.1.1', string $purpose = 'register'): string {
    $captured = '';
    $otp->issue('sms', $dest, $purpose, $ip, function (string $c) use (&$captured) { $captured = $c; });
    return $captured;
}

echo "Phone\n";
check('0801 234 5678', Phone::normalizeNg('0801 234 5678') === '+2348012345678');
check('+234 801 234 5678', Phone::normalizeNg('+234 801 234 5678') === '+2348012345678');
check('2348012345678', Phone::normalizeNg('2348012345678') === '+2348012345678');
check('8012345678', Phone::normalizeNg('8012345678') === '+2348012345678');
check('+234 0801 234 5678', Phone::normalizeNg('+234 0801 234 5678') === '+2348012345678');
check('rejects short', Phone::normalizeNg('0801234') === null);
check('rejects letters', Phone::normalizeNg('08012abc678') === null);
check('rejects foreign +1', Phone::normalizeNg('+14155552671') === null);
check('rejects landline-style 01', Phone::normalizeNg('01234567890') === null);
check('termii format has no plus', Phone::forTermii('+2348012345678') === '2348012345678');

echo "Passwords\n";
check('short rejected', Security::passwordProblem('abc123', '+2348012345678') !== null);
check('phone as password rejected', Security::passwordProblem('08012345678', '+2348012345678') !== null);
check('weak list rejected', Security::passwordProblem('password', '+2348012345678') !== null);
check('repeated chars rejected', Security::passwordProblem('aaaaaaaa', '+2348012345678') !== null);
check('good password accepted', Security::passwordProblem('Lagos-Plumber-77', '+2348012345678') === null);

echo "Beefrika ID\n";
$id = Security::newBeefrikaId();
check('format BF-XXXXXX', (bool)preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $id));

echo "OTP\n";
$db = freshDb(); $otp = new Otp($db);
$code = issue($otp);
check('code is 6 digits', (bool)preg_match('/^\d{6}$/', $code));
check('plain code is not stored', (int)$db->query("SELECT COUNT(*) FROM otp_codes WHERE code_hash = '$code'")->fetchColumn() === 0);
check('hash is stored', strlen((string)$db->query('SELECT code_hash FROM otp_codes')->fetchColumn()) === 64);
check('wrong code rejected', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', $code === '000000' ? '111111' : '000000'), 400));
$otp->verify('sms', '+2348012345678', 'register', $code);
check('correct code accepted', true);
check('code cannot be reused', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', $code), 400));
check('non-numeric code rejected', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', 'abcdef'), 400));

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
$code = issue($otp);
check('immediate resend blocked (cooldown)', throwsStatus(fn() => issue($otp), 429));
Clock::advance(61);
$code2 = issue($otp);
check('resend allowed after cooldown', (bool)preg_match('/^\d{6}$/', $code2));
if ($code !== $code2) {
    check('old code invalid after resend', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', $code), 400));
}
$otp->verify('sms', '+2348012345678', 'register', $code2);
check('new code works', true);

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
$code = issue($otp);
Clock::advance(301);
check('expired code rejected', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', $code), 400));

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
$code = issue($otp);
$bad = $code === '123456' ? '654321' : '123456';
for ($i = 0; $i < 5; $i++) { try { $otp->verify('sms', '+2348012345678', 'register', $bad); } catch (ApiException $e) {} }
check('code locked after 5 wrong tries (even the right code fails)', throwsStatus(fn() => $otp->verify('sms', '+2348012345678', 'register', $code), 400));

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
issue($otp); Clock::advance(61); issue($otp); Clock::advance(61); issue($otp); Clock::advance(61);
check('4th code within an hour blocked', throwsStatus(fn() => issue($otp), 429));
Clock::advance(3600);
check('allowed again after an hour', (bool)preg_match('/^\d{6}$/', issue($otp)));

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
$sent = 0;
for ($i = 0; $i < 25; $i++) {
    try { issue($otp, '+23480123' . str_pad((string)(10000 + $i), 5, '0', STR_PAD_LEFT), '9.9.9.9'); $sent++; } catch (ApiException $e) { if ($e->status !== 429) throw $e; }
}
check('per-IP limit stops SMS abuse (max 20/hour)', $sent === 20);

$db = freshDb(); $otp = new Otp($db); Clock::freeze(1_800_000_000);
$threw = false;
try { $otp->issue('sms', '+2348012345678', 'register', '1.1.1.1', function () { throw new RuntimeException('provider down'); }); }
catch (ApiException $e) { $threw = $e->status === 502; }
check('delivery failure gives friendly 502', $threw);
check('failed delivery leaves no usable code', (int)$db->query('SELECT COUNT(*) FROM otp_codes WHERE used_at IS NULL')->fetchColumn() === 0);

echo "Rate limiter\n";
$db = freshDb(); Clock::freeze(1_800_000_000); $rl = new RateLimit($db);
for ($i = 0; $i < 10; $i++) $rl->hit('login:x');
check('blocks at limit', $rl->tooMany('login:x', 10, 900));
Clock::advance(901);
check('window expires', !$rl->tooMany('login:x', 10, 900));

echo "Sessions\n";
$db = freshDb(); Clock::freeze(1_800_000_000);
$db->exec("INSERT INTO users (status, role) VALUES ('active','worker'), ('suspended','worker')");
$auth = new Auth($db);
$token = $auth->startSession(1, '1.1.1.1', 'test');
$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $token;
check('valid token finds user', ($auth->currentUser()['id'] ?? null) == 1);
check('token stored hashed, not plain', (int)$db->query("SELECT COUNT(*) FROM sessions WHERE token_hash = '$token'")->fetchColumn() === 0);
$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . str_repeat('a', 64);
check('unknown token rejected', $auth->currentUser() === null);
unset($_SERVER['HTTP_AUTHORIZATION']);
check('missing header rejected', throwsStatus(fn() => $auth->requireUser(), 401));
$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $token;
check('wrong role forbidden', throwsStatus(fn() => $auth->requireUser('employer'), 403));
$auth->revokeCurrent();
check('revoked token rejected', $auth->currentUser() === null);
$t2 = $auth->startSession(1, '1.1.1.1', 'test'); $_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $t2;
Clock::advance(31 * 86400);
check('expired session rejected', $auth->currentUser() === null);
Clock::freeze(1_800_000_000);
$t3 = $auth->startSession(2, '1.1.1.1', 'test'); $_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $t3;
check('suspended user cannot use a session', $auth->currentUser() === null);

echo "\n$pass passed, $fail failed\n";
exit($fail === 0 ? 0 : 1);
