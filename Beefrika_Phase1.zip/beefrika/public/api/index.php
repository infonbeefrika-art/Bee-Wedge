<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/src/bootstrap.php';

use Beefrika\ApiException;
use Beefrika\Controllers\AuthController;
use Beefrika\Controllers\MeController;
use Beefrika\Controllers\MetaController;
use Beefrika\Controllers\WorkerController;
use Beefrika\Db;
use Beefrika\Http;

Http::securityHeaders();
Http::cors();

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $path = '/' . trim(preg_replace('#^/api#', '', $path) ?? '', '/');

    if ($method === 'GET' && $path === '/health') {
        Http::send(['ok' => true]);
    }

    $db = Db::pdo();
    $in = in_array($method, ['POST', 'PUT'], true) ? Http::body() : [];

    $result = match ("$method $path") {
        'GET /meta'                 => (new MetaController($db))->show(),
        'POST /auth/otp/request'    => (new AuthController($db))->requestRegistrationOtp($in),
        'POST /auth/register'       => (new AuthController($db))->register($in),
        'POST /auth/login'          => (new AuthController($db))->login($in),
        'POST /auth/logout'         => (new AuthController($db))->logout(),
        'GET /me'                   => (new MeController($db))->show(),
        'POST /me/email/request'    => (new MeController($db))->requestEmailCode($in),
        'POST /me/email/verify'     => (new MeController($db))->verifyEmail($in),
        'GET /worker/profile'       => (new WorkerController($db))->show(),
        'PUT /worker/profile'       => (new WorkerController($db))->update($in),
        default                     => throw new ApiException('Not found.', 404),
    };
    Http::send($result);
} catch (ApiException $e) {
    Http::fail($e->getMessage(), $e->status, $e->extra);
} catch (Throwable $e) {
    error_log('Unhandled: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    Http::fail('Something went wrong on our side. Please try again.', 500);
}
