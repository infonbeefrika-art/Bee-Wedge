'use strict';
/* Beefrika - lean client. No frameworks, no third-party scripts. All user text is inserted with textContent. */

const T = { // all visible text lives here so it can be translated later (English first, then Pidgin, Yoruba, Hausa, Igbo)
  tagline: 'Your verified work record',
  sub: 'Prove who you are. Show what you can do. Get hired by people who trust you.',
  create: 'Create account', login: 'Log in', back: 'Back',
  roleQ: 'What do you want to do?', worker: 'Find work', employer: 'Hire workers',
  name: 'Your full name', phone: 'Phone number', phoneHint: 'Example: 0801 234 5678',
  sendCode: 'Send code', code: 'Code from SMS', password: 'Password', passwordHint: 'At least 8 characters',
  finish: 'Create my account', resend: 'Send a new code', resendIn: 'Send a new code in',
  logout: 'Log out', save: 'Save', saved: 'Saved.',
  yourId: 'Your Beefrika ID',
  trade: 'Your main trade', area: 'Where in Lagos do you work?', years: 'Years of experience',
  headline: 'Short headline', headlineHint: 'Example: Experienced electrician, 8 years',
  bio: 'About you', avail: 'Are you available for work?',
  availOpts: { available: 'Yes, available', busy: 'Busy right now', not_looking: 'Not looking' },
  discover: 'Let employers find me in search',
  choose: 'Choose...',
  checklist: { phone: 'Phone number confirmed', trade: 'Add your main trade', area: 'Add your area', years: 'Add years of experience', headline: 'Write a short headline', bio: 'Tell employers about yourself' },
  complete: 'Profile complete',
  trustTitle: 'Your trust labels',
  trust: { phone: { verified: 'Phone verified', unverified: 'Phone not verified' }, email: { verified: 'Email verified', not_added: 'Email not added' },
           identity: { not_started: 'ID not verified yet' }, skills: { self_reported: 'Trade: self-reported', not_started: 'Trade not added' } },
  trustNote: 'Only checks Beefrika has really done are marked verified. Everything else is shown as your own word.',
  emailTitle: 'Add your email (optional)', emailSend: 'Send email code', emailCode: 'Code from email', emailConfirm: 'Confirm email',
  empSoon: 'Employer tools are being built.',
  empBody: 'You are registered. Worker search, job posting and hiring requests are coming next. We will keep your account ready.',
  neterr: 'No connection. Please check your network and try again.',
  welcomeBack: 'Welcome',
};

const $app = document.getElementById('app');
const store = {
  get token() { try { return localStorage.getItem('bf_token'); } catch (e) { return null; } },
  set token(v) { try { v ? localStorage.setItem('bf_token', v) : localStorage.removeItem('bf_token'); } catch (e) { /* storage blocked */ } },
};
let meta = null;
let me = null;

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const c of kids.flat()) e.append(c instanceof Node ? c : document.createTextNode(c == null ? '' : String(c)));
  return e;
}

async function api(path, method = 'GET', body) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (store.token) headers.Authorization = 'Bearer ' + store.token;
  let res;
  try {
    res = await fetch('/api' + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (e) {
    throw new Error(T.neterr);
  }
  let data = {};
  try { data = await res.json(); } catch (e) { /* non-JSON */ }
  if (res.status === 401 && store.token && !path.startsWith('/auth/')) { store.token = null; me = null; render(); throw new Error(data.error || 'Please log in.'); }
  if (!res.ok) { const err = new Error(data.error || 'Something went wrong. Please try again.'); err.data = data; throw err; }
  return data;
}

function show(...nodes) { $app.replaceChildren(h('main', { class: 'screen' }, ...nodes)); window.scrollTo(0, 0); }
function brand() { return h('div', { class: 'brandbar' }, h('img', { src: 'icons/logo-96.png', alt: '', width: 40, height: 40 }), h('b', {}, 'Beefrika')); }
function note(kind, text) { return h('div', { class: 'msg ' + kind, role: kind === 'err' ? 'alert' : 'status' }, text); }
function field(label, input) { const id = 'f_' + Math.random().toString(36).slice(2, 8); input.id = id; return [h('label', { for: id }, label), input]; }
function setBusy(btn, busy) { btn.disabled = busy; }

/* ---------- screens ---------- */
function welcome() {
  show(brand(), h('h1', {}, T.tagline), h('p', { class: 'muted' }, T.sub),
    h('button', { class: 'btn', onclick: () => register1() }, T.create),
    h('button', { class: 'btn ghost', onclick: () => loginScreen() }, T.login));
}

function register1(prefill = {}) {
  let role = prefill.role || 'worker';
  const err = h('div');
  const name = h('input', { type: 'text', autocomplete: 'name', maxlength: 80, value: prefill.name || '' });
  const phone = h('input', { type: 'tel', inputmode: 'tel', autocomplete: 'tel', placeholder: T.phoneHint, value: prefill.phone || '' });
  const chips = h('div', { class: 'chips' });
  const drawChips = () => chips.replaceChildren(...['worker', 'employer'].map((r) =>
    h('button', { type: 'button', class: 'chip', 'aria-pressed': String(role === r), onclick: () => { role = r; drawChips(); } }, T[r])));
  drawChips();
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/otp/request', 'POST', { phone: phone.value });
      register2({ role, name: name.value, phone: phone.value }, r);
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.sendCode);
  show(brand(), h('h1', {}, T.create), h('p', {}, T.roleQ), chips, ...field(T.name, name), ...field(T.phone, phone), err, btn,
    h('button', { class: 'link', onclick: welcome }, T.back));
}

function register2(d, sent) {
  const err = h('div');
  const code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, pattern: '[0-9]*' });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const resendBtn = h('button', { class: 'link', disabled: true });
  let left = sent.resend_after || 60;
  const tick = () => {
    if (!resendBtn.isConnected) return;
    if (left > 0) { resendBtn.textContent = `${T.resendIn} ${left}s`; resendBtn.disabled = true; left--; setTimeout(tick, 1000); }
    else { resendBtn.textContent = T.resend; resendBtn.disabled = false; }
  };
  resendBtn.addEventListener('click', async () => {
    err.replaceChildren(); resendBtn.disabled = true;
    try { const r = await api('/auth/otp/request', 'POST', { phone: d.phone }); left = r.resend_after || 60; err.replaceChildren(note('ok', 'Code sent.')); }
    catch (e) { err.replaceChildren(note('err', e.message)); left = (e.data && e.data.retry_after) || 0; }
    tick();
  });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/register', 'POST', { phone: d.phone, code: code.value.trim(), password: pw.value, full_name: d.name, role: d.role });
      store.token = r.token; await loadMe(); render();
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.finish);
  show(brand(), h('h1', {}, T.create), h('p', {}, `We sent a 6-digit code to ${d.phone}.`),
    sent.dev_note ? note('info', sent.dev_note) : '',
    ...field(T.code, code), ...field(T.password, pw), h('p', { class: 'muted' }, T.passwordHint), err, btn, resendBtn,
    h('button', { class: 'link', onclick: () => register1(d) }, T.back));
  tick();
}

function loginScreen() {
  const err = h('div');
  const phone = h('input', { type: 'tel', inputmode: 'tel', autocomplete: 'tel', placeholder: T.phoneHint });
  const pw = h('input', { type: 'password', autocomplete: 'current-password', maxlength: 128 });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try { const r = await api('/auth/login', 'POST', { phone: phone.value, password: pw.value }); store.token = r.token; await loadMe(); render(); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.login);
  show(brand(), h('h1', {}, T.login), ...field(T.phone, phone), ...field(T.password, pw), err, btn, h('button', { class: 'link', onclick: welcome }, T.back));
}

function trustBadges(trust) {
  const items = [];
  for (const [key, val] of Object.entries(trust)) {
    const label = (T.trust[key] || {})[val];
    if (label) items.push(h('span', { class: 'badge ' + (val === 'verified' ? 'good' : 'warn') }, label));
  }
  return h('div', {}, h('div', { class: 'badges' }, items), h('p', { class: 'muted' }, T.trustNote));
}

function emailBox() {
  const box = h('div', { class: 'card' });
  const draw = (stage, email, msg) => {
    const out = [h('b', {}, T.emailTitle)];
    if (me.email && me.trust.email === 'verified') { box.replaceChildren(h('b', {}, T.trust.email.verified), h('p', { class: 'muted' }, me.email)); return; }
    const em = h('input', { type: 'email', autocomplete: 'email', value: email || '', maxlength: 190 });
    const code = h('input', { type: 'text', inputmode: 'numeric', maxlength: 6, autocomplete: 'one-time-code' });
    const err = h('div'); if (msg) err.append(msg);
    if (stage === 'enter') {
      const b = h('button', { class: 'btn ghost', onclick: async () => {
        setBusy(b, true);
        try { await api('/me/email/request', 'POST', { email: em.value }); draw('code', em.value.trim().toLowerCase(), note('ok', 'Code sent. Check your email.')); }
        catch (e) { err.replaceChildren(note('err', e.message)); setBusy(b, false); }
      } }, T.emailSend);
      out.push(...field('Email', em), err, b);
    } else {
      const b = h('button', { class: 'btn', onclick: async () => {
        setBusy(b, true);
        try { await api('/me/email/verify', 'POST', { email, code: code.value.trim() }); await loadMe(); render(); }
        catch (e) { err.replaceChildren(note('err', e.message)); setBusy(b, false); }
      } }, T.emailConfirm);
      out.push(h('p', { class: 'muted' }, email), ...field(T.emailCode, code), err, b, h('button', { class: 'link', onclick: () => draw('enter', email) }, T.back));
    }
    box.replaceChildren(...out);
  };
  draw('enter');
  return box;
}

async function workerHome() {
  const { profile } = await api('/worker/profile');
  const opts = (list, sel) => [h('option', { value: '' }, T.choose), ...list.map((i) => h('option', { value: i.id, selected: Number(sel) === Number(i.id) }, i.name))];
  const trade = h('select', {}, opts(meta.trades, profile.primary_trade_id));
  const area = h('select', {}, opts(meta.areas, profile.area_id));
  const years = h('input', { type: 'number', inputmode: 'numeric', min: 0, max: 60, value: profile.years_experience ?? '' });
  const headline = h('input', { type: 'text', maxlength: 100, placeholder: T.headlineHint, value: profile.headline });
  const bio = h('textarea', { maxlength: 600 }, profile.bio);
  const avail = h('select', {}, Object.entries(T.availOpts).map(([k, v]) => h('option', { value: k, selected: profile.availability === k }, v)));
  const disc = h('input', { type: 'checkbox', id: 'disc', checked: profile.is_discoverable });
  const err = h('div');
  const bar = h('div', { class: 'bar' }, h('i')); bar.firstChild.style.width = profile.completion + '%';
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      await api('/worker/profile', 'PUT', { primary_trade_id: trade.value, area_id: area.value, years_experience: years.value, headline: headline.value, bio: bio.value, availability: avail.value, is_discoverable: disc.checked });
      render(note('ok', T.saved));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.save);
  return [
    h('h2', {}, `${T.complete}: ${profile.completion}%`), bar,
    h('ul', { class: 'check' }, profile.checklist.map((c) => h('li', { class: c.done ? 'done' : '' }, T.checklist[c.key]))),
    ...field(T.trade, trade), ...field(T.area, area), ...field(T.years, years), ...field(T.headline, headline), ...field(T.bio, bio), ...field(T.avail, avail),
    h('div', { class: 'checkrow' }, disc, h('label', { for: 'disc' }, T.discover)), err, btn,
  ];
}

async function home(flash) {
  const body = me.role === 'worker' ? await workerHome()
    : [h('div', { class: 'card' }, h('b', {}, T.empSoon), h('p', {}, T.empBody))];
  show(
    h('div', { class: 'top' }, brand(), h('button', { class: 'link', onclick: async () => { try { await api('/auth/logout', 'POST'); } catch (e) {} store.token = null; me = null; welcome(); } }, T.logout)),
    flash || '',
    h('h1', {}, `${T.welcomeBack}, ${me.full_name.split(' ')[0]}`),
    h('div', { class: 'card' }, h('div', { class: 'muted' }, T.yourId), h('b', {}, me.beefrika_id)),
    h('h2', {}, T.trustTitle), trustBadges(me.trust),
    ...body, emailBox(),
  );
}

async function loadMe() { me = (await api('/me')).user; }
async function render(flash) {
  if (!store.token) return welcome();
  try {
    if (!meta) meta = await api('/meta');
    if (!me) await loadMe();
    await home(flash);
  } catch (e) { if (!store.token) return welcome(); show(brand(), note('err', e.message), h('button', { class: 'btn', onclick: () => render() }, 'Try again')); }
}

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
render();
