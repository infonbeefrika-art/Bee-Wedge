<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\Messaging;
use Beefrika\Otp;
use Beefrika\Trust;
use PDO;
use PDOException;

final class MeController
{
    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        $u = (new Auth($this->db))->requireUser();
        $profile = null;
        if ($u['role'] === 'worker') {
            $st = $this->db->prepare('SELECT * FROM worker_profiles WHERE user_id = ?');
            $st->execute([$u['id']]);
            $profile = $st->fetch() ?: null;
        }
        return ['user' => [
            'beefrika_id' => $u['beefrika_id'],
            'role'        => $u['role'],
            'full_name'   => $u['full_name'],
            'phone'       => $this->maskPhone($u['phone']),
            'email'       => $u['email'],
            'trust'       => Trust::forUser($u, $profile),
        ]];
    }

    /** POST /me/email/request {email} */
    public function requestEmailCode(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $email = Input::email($in);
        $this->assertEmailFree($email, (int)$u['id']);
        $sender = Messaging::email();
        $otp = new Otp($this->db);
        $otp->issue('email', $email, 'verify_email', Http::ip(), function (string $code) use ($sender, $email, $otp): void {
            $minutes = intdiv($otp->ttl(), 60);
            $sender->send($email, 'Your Beefrika verification code', "Your Beefrika code is $code. It expires in $minutes minutes. If you did not ask for this, ignore this email.");
        });
        return ['sent' => true, 'expires_in' => $otp->ttl(), 'resend_after' => $otp->cooldown()];
    }

    /** POST /me/email/verify {email, code} */
    public function verifyEmail(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $email = Input::email($in);
        $this->assertEmailFree($email, (int)$u['id']);
        (new Otp($this->db))->verify('email', $email, 'verify_email', (string)($in['code'] ?? ''));
        try {
            $this->db->prepare('UPDATE users SET email = ?, email_verified_at = ?, updated_at = ? WHERE id = ?')
                ->execute([$email, Clock::dt(), Clock::dt(), $u['id']]);
        } catch (PDOException $e) {
            throw new ApiException('This email is already used by another account.', 409);
        }
        return ['ok' => true];
    }

    private function assertEmailFree(string $email, int $userId): void
    {
        $st = $this->db->prepare('SELECT 1 FROM users WHERE email = ? AND id <> ?');
        $st->execute([$email, $userId]);
        if ($st->fetchColumn()) {
            throw new ApiException('This email is already used by another account.', 409);
        }
    }

    private function maskPhone(string $e164): string
    {
        return substr($e164, 0, 7) . '***' . substr($e164, -2);
    }
}
