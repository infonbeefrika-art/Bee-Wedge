<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;

final class Input
{
    public static function text(array $in, string $key, int $min, int $max, string $label): string
    {
        $v = $in[$key] ?? '';
        if (!is_string($v)) {
            throw new ApiException("$label is not valid.", 422);
        }
        $v = trim(preg_replace('/\s+/u', ' ', $v) ?? '');
        $len = mb_strlen($v);
        if ($len < $min || $len > $max) {
            throw new ApiException($min > 0 ? "$label must be $min to $max characters." : "$label can be at most $max characters.", 422);
        }
        return $v;
    }

    /** Keeps line breaks (for bios). */
    public static function multiline(array $in, string $key, int $max, string $label): string
    {
        $v = $in[$key] ?? '';
        if (!is_string($v)) {
            throw new ApiException("$label is not valid.", 422);
        }
        $v = trim(str_replace("\r", '', $v));
        if (mb_strlen($v) > $max) {
            throw new ApiException("$label can be at most $max characters.", 422);
        }
        return $v;
    }

    public static function email(array $in, string $key = 'email'): string
    {
        $v = strtolower(trim((string)($in[$key] ?? '')));
        if (strlen($v) > 190 || !filter_var($v, FILTER_VALIDATE_EMAIL)) {
            throw new ApiException('Enter a valid email address.', 422);
        }
        return $v;
    }
}
