<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use PDO;

final class MetaController
{
    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        return [
            'trades' => $this->db->query('SELECT id, name FROM trades WHERE is_active = 1 ORDER BY name')->fetchAll(),
            'areas'  => $this->db->query('SELECT id, name FROM lagos_areas WHERE is_active = 1 ORDER BY name')->fetchAll(),
        ];
    }
}
