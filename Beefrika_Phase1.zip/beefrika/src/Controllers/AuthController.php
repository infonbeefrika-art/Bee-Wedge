<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\Messaging;
use Beefrika\Otp;
use Beefrika\Phone;
use Beefrika\RateLimit;
use Beefrika\Security;
use PDO;
use PDOException;

final class AuthController
{
    // Valid bcrypt hash used to keep login timing similar when the phone number is unknown.
    private const DUMMY_HASH = '$2y$10$.vGA1O9wmRjrwAVXD98HNOgsNpDczlqm3Jq7KnEd1rVAGv3Fykk1a';

    public function __construct(private PDO $db)
    {
    }

    /** POST /auth/otp/request  {phone} - for sign-up */
    public function requestRegistrationOtp(array $in): array
    {
        $phone = $this->phoneFrom($in);
        $st = $this->db->prepare('SELECT 1 FROM users WHERE phone = ?');
        $st->execute([$phone]);
        if ($st->fetchColumn()) {
            throw new ApiException('This number already has an account. Please log in.', 409);
        }
        $otp = new Otp($this->db);
        $otp->issue('sms', $phone, 'register', Http::ip(), function (string $code) use ($phone, $otp): void {
            $minutes = intdiv($otp->ttl(), 60);
            Messaging::sms()->send($phone, "Your Beefrika code is $code. It expires in $minutes minutes. Never share this code.");
        });
        $out = ['sent' => true, 'expires_in' => $otp->ttl(), 'resend_after' => $otp->cooldown()];
        if (Messaging::smsMode() === 'mock' && !Messaging::isProduction()) {
            $out['dev_note'] = 'Mock mode: the code is in storage/logs/otp_mock.log';
        }
        return $out;
    }

    /** POST /auth/register {phone, code, password, full_name, role} */
    public function register(array $in): array
    {
        $phone = $this->phoneFrom($in);
        $name = Input::text($in, 'full_name', 2, 80, 'Name');
        $role = $in['role'] ?? '';
        if (!in_array($role, ['worker', 'employer'], true)) {
            throw new ApiException('Choose whether you are looking for work or want to hire.', 422);
        }
        $password = (string)($in['password'] ?? '');
        if ($problem = Security::passwordProblem($password, $phone)) {
            throw new ApiException($problem, 422);
        }

        $limit = new RateLimit($this->db);
        $ipKey = 'register:ip:' . Security::ipHash(Http::ip());
        if ($limit->tooMany($ipKey, 20, 3600)) {
            throw new ApiException('Too many attempts. Please try again later.', 429);
        }
        $limit->hit($ipKey);

        $st = $this->db->prepare('SELECT 1 FROM users WHERE phone = ?');
        $st->execute([$phone]);
        if ($st->fetchColumn()) {
            throw new ApiException('This number already has an account. Please log in.', 409);
        }

        (new Otp($this->db))->verify('sms', $phone, 'register', (string)($in['code'] ?? ''));

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $userId = 0;
        $beefrikaId = '';
        $this->db->beginTransaction();
        try {
            for ($attempt = 0; $attempt < 5; $attempt++) {
                $beefrikaId = Security::newBeefrikaId();
                try {
                    $this->db->prepare(
                        'INSERT INTO users (beefrika_id, role, phone, phone_verified_at, password_hash, full_name, status, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
                    )->execute([$beefrikaId, $role, $phone, Clock::dt(), $hash, $name, 'active', Clock::dt(), Clock::dt()]);
                    $userId = (int)$this->db->lastInsertId();
                    break;
                } catch (PDOException $e) {
                    if ($e->getCode() !== '23000' && $e->getCode() !== 23000) {
                        throw $e;
                    }
                    $chk = $this->db->prepare('SELECT 1 FROM users WHERE phone = ?');
                    $chk->execute([$phone]);
                    if ($chk->fetchColumn()) {
                        throw new ApiException('This number already has an account. Please log in.', 409);
                    }
                    // otherwise the Beefrika ID collided: try another
                }
            }
            if ($userId === 0) {
                throw new \RuntimeException('Could not allocate a Beefrika ID');
            }
            if ($role === 'worker') {
                $this->db->prepare('INSERT INTO worker_profiles (user_id, created_at, updated_at) VALUES (?, ?, ?)')
                    ->execute([$userId, Clock::dt(), Clock::dt()]);
            } else {
                $this->db->prepare('INSERT INTO employer_profiles (user_id, created_at, updated_at) VALUES (?, ?, ?)')
                    ->execute([$userId, Clock::dt(), Clock::dt()]);
            }
            $this->audit($userId, 'user.registered', 'user', $userId);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        $token = (new Auth($this->db))->startSession($userId, Http::ip(), $_SERVER['HTTP_USER_AGENT'] ?? '');
        return ['token' => $token, 'beefrika_id' => $beefrikaId];
    }

    /** POST /auth/login {phone, password} */
    public function login(array $in): array
    {
        $phone = Phone::normalizeNg((string)($in['phone'] ?? ''));
        $password = (string)($in['password'] ?? '');
        $generic = 'Phone number or password is incorrect.';
        if ($phone === null || $password === '' || strlen($password) > 1024) {
            throw new ApiException($generic, 401);
        }

        $limit = new RateLimit($this->db);
        $phoneKey = 'login:phone:' . $phone;
        $ipKey = 'login:ip:' . Security::ipHash(Http::ip());
        if ($limit->tooMany($phoneKey, 10, 900) || $limit->tooMany($ipKey, 40, 900)) {
            throw new ApiException('Too many attempts. Please wait 15 minutes and try again.', 429);
        }

        $st = $this->db->prepare('SELECT * FROM users WHERE phone = ? LIMIT 1');
        $st->execute([$phone]);
        $user = $st->fetch();
        $ok = password_verify($password, $user ? $user['password_hash'] : self::DUMMY_HASH);
        if (!$user || !$ok) {
            $limit->hit($phoneKey);
            $limit->hit($ipKey);
            throw new ApiException($generic, 401);
        }
        if ($user['status'] !== 'active') {
            throw new ApiException('This account is not available. Please contact support.', 403);
        }
        if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
            $this->db->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
        }
        $this->db->prepare('UPDATE users SET last_login_at = ? WHERE id = ?')->execute([Clock::dt(), $user['id']]);
        $token = (new Auth($this->db))->startSession((int)$user['id'], Http::ip(), $_SERVER['HTTP_USER_AGENT'] ?? '');
        return ['token' => $token, 'beefrika_id' => $user['beefrika_id']];
    }

    public function logout(): array
    {
        (new Auth($this->db))->revokeCurrent();
        return ['ok' => true];
    }

    private function phoneFrom(array $in): string
    {
        $phone = Phone::normalizeNg((string)($in['phone'] ?? ''));
        if ($phone === null) {
            throw new ApiException('Enter a valid Nigerian phone number, for example 0801 234 5678.', 422);
        }
        return $phone;
    }

    private function audit(int $actor, string $action, string $entity, int $entityId): void
    {
        $this->db->prepare(
            'INSERT INTO audit_log (actor_id, action, entity, entity_id, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$actor, $action, $entity, $entityId, Security::ipHash(Http::ip()), Clock::dt()]);
    }
}
