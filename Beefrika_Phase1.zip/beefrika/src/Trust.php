<?php
declare(strict_types=1);

namespace Beefrika;

/**
 * Trust labels. Rule: nothing is labelled "verified" unless a check was actually done and recorded.
 * Phase 1 knows only phone/email OTP checks and self-reported claims.
 */
final class Trust
{
    public static function forUser(array $user, ?array $workerProfile): array
    {
        $labels = [
            'phone'    => $user['phone_verified_at'] ? 'verified' : 'unverified',
            'email'    => $user['email_verified_at'] ? 'verified' : 'not_added',
            'identity' => 'not_started',
        ];
        if ($user['role'] === 'worker') {
            $labels['skills'] = ($workerProfile && !empty($workerProfile['primary_trade_id'])) ? 'self_reported' : 'not_started';
        }
        return $labels;
    }
}
