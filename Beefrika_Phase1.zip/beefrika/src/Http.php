<?php
declare(strict_types=1);

namespace Beefrika;

final class Http
{
    public static function securityHeaders(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: no-referrer');
        header('Cache-Control: no-store');
    }

    /** CORS is off unless ALLOWED_ORIGIN is set and matches the request. Never "*". */
    public static function cors(): void
    {
        $allowed = Env::get('ALLOWED_ORIGIN');
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($allowed !== null && $origin === $allowed) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Headers: Authorization, Content-Type');
            header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
        }
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }

    public static function body(): array
    {
        $raw = file_get_contents('php://input', false, null, 0, 65537);
        if ($raw === false || $raw === '') {
            return [];
        }
        if (strlen($raw) > 65536) {
            throw new ApiException('Request is too large.', 413);
        }
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw new ApiException('Invalid request.', 400);
        }
        return $data;
    }

    public static function ip(): string
    {
        if (Env::get('TRUST_FORWARDED_FOR') === '1' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $first = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
            if (filter_var($first, FILTER_VALIDATE_IP)) {
                return $first;
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public static function bearerToken(): ?string
    {
        $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/^Bearer\s+([a-f0-9]{64})$/i', $h, $m)) {
            return strtolower($m[1]);
        }
        return null;
    }

    public static function send(array $payload, int $status = 200): never
    {
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function fail(string $message, int $status, array $extra = []): never
    {
        self::send(['error' => $message] + $extra, $status);
    }
}
