# Beefrika (rebuild, Phase 1)

Verified work record for informal workers in Lagos. This is a clean rebuild; nothing here comes from the old
learning-community app except the logo and the PWA idea.

Stack: PHP 8.1+, MySQL/MariaDB, vanilla JS PWA. No third-party scripts, no frameworks.

## What Phase 1 contains
- Secure foundation: secrets only in `.env`, one auth layer (bearer tokens, hashed), no CORS wildcard, rate limits, audit log
- Phone sign-up with SMS OTP via Termii (mock mode for development)
- Optional email verification by code (mock only until an email provider is chosen)
- Worker profile with completion checklist and trust labels (phone verified / self-reported)
- Employer account (placeholder screen; employer tools are Phase 2)
- Full launch data model in `database/schema.sql` (jobs, hiring requests, messages, hires, reviews, reports, verification records), most of it not wired to screens yet

## Setup (local or server)
1. Create a MySQL database and import `database/schema.sql` (empty database only).
2. `cp .env.example .env` and fill in `DB_*`. Generate the secret:
   `php -r "echo bin2hex(random_bytes(32));"` and put it in `OTP_HMAC_SECRET`.
3. Point the web server's **document root at `public/`**. (If the host cannot do that, the root `.htaccess` is a fallback.)
4. Run the tests: `php tests/run.php`
5. Local try-out: use Apache/Nginx or XAMPP with the document root on `public/` (the API needs the `.htaccess` rewrites).

## OTP modes
| Mode | Behaviour |
|---|---|
| `OTP_MODE=mock` | No SMS sent. The code is written to `storage/logs/otp_mock.log`. Refused when `APP_ENV=production`. |
| `OTP_MODE=live` | Sends through Termii (`POST {TERMII_BASE_URL}/api/sms/send`, channel `dnd`). Needs `TERMII_API_KEY` and an approved `TERMII_SENDER_ID`. |

I did not add a "sandbox" mode: I could not confirm Termii offers one. Use mock for development and a small live test before launch.

Rules: 6 digits, stored as HMAC hash, expires in 5 min, 5 wrong tries then locked, resend cooldown 60 s,
max 3/hour and 10/day per phone, max 20/hour per IP. The code is never returned by the API.

## Before going live
- Rotate the old database password and old Resend key (they were exposed in the original zip)
- Use `APP_ENV=production`, `OTP_MODE=live`, HTTPS, and real hosting with backups
- Register the Termii sender ID and confirm delivery to MTN, Airtel, Glo and 9mobile
- Choose an email provider (Gmail SMTP is for testing only)
- Make an admin account directly in the database (admins cannot self-register)

## Status of testing
`tests/run.php` covers phone parsing, passwords, OTP rules, rate limiting and sessions on SQLite.
The code was written in an environment without PHP, so **it has not been executed yet**. Run the tests first and send me any failures.

## Next phases
2. Employer profile + proportionate business verification
3. Worker search and filters
4. Job details, hiring requests, messaging (text only)
5. Hire confirmation, fee record, reviews, reports and disputes
6. Admin dashboard, verification queue, fraud flags, analytics
