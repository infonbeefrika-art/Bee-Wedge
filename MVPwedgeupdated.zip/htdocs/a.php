<?php
declare(strict_types=1);

// Profile photo: /a/<24 hex chars>. See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

try {
    \Beefrika\Avatar::serve(\Beefrika\Db::pdo(), (string)($_GET['t'] ?? ''));
} catch (Throwable $e) {
    error_log('Avatar error: ' . get_class($e) . ': ' . $e->getMessage());
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Not found';
}
