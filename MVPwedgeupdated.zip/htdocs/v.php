<?php
declare(strict_types=1);

// Customer vouch page: /v/<24 hex chars>. See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

use Beefrika\ApiException;
use Beefrika\Db;
use Beefrika\Http;
use Beefrika\Vouch;
use Beefrika\VouchPage;

try {
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store');
    $db = Db::pdo();
    $token = (string)($_GET['t'] ?? '');
    $link = Vouch::findLink($db, $token);
    if ($link === null) {
        http_response_code(404);
        echo VouchPage::notFound();
        exit;
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        try {
            Vouch::submit($db, $link, $_POST, Http::ip());
            header('Location: /v/' . $token . '?done=1', true, 303);
            exit;
        } catch (ApiException $e) {
            http_response_code($e->status);
            echo VouchPage::form($db, $link, $_POST, $e->getMessage(), Vouch::formToken($token));
            exit;
        }
    }
    if (isset($_GET['done'])) {
        echo VouchPage::thanks($link);
        exit;
    }
    Vouch::recordOpen($db, (int)$link['link_id'], $_SERVER['HTTP_USER_AGENT'] ?? '');
    echo VouchPage::form($db, $link, [], null, Vouch::formToken($token));
} catch (Throwable $e) {
    error_log('Vouch page error: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Something went wrong. Please try again.';
}
