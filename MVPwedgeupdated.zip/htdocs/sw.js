// Caches only the static app shell. API calls are never cached (they carry private data).
const CACHE = 'beefrika-shell-v15';
const SHELL = ['/', '/index.html', '/style.css', '/app.js', '/offline.html', '/icons/logo-96.png', '/manifest.webmanifest',
  '/js/api.js', '/js/dom.js', '/js/format.js', '/js/honey.js', '/js/strings.js', '/js/ui.js',
  '/js/views/admin.js', '/js/views/auth.js', '/js/views/business.js', '/js/views/find.js', '/js/views/landing.js',
  '/js/views/profile.js', '/js/views/record.js', '/js/views/shared.js', '/js/qr.js', '/js/qrsvg.js', '/js/imaging.js', '/js/views/photos.js', '/js/views/share.js', '/js/views/card.js', '/js/views/hirebox.js', '/js/views/report.js', '/js/views/requests.js', '/js/views/thread.js', '/js/views/vouches.js', '/js/views/idcard.js', '/js/views/avatar.js', '/js/views/hero.js', '/js/views/feedbackbox.js', '/js/views/passport.js', '/js/views/scan.js', '/js/views/billing.js', '/js/views/mode.js', '/js/views/phonefield.js'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).catch(() => caches.match('/offline.html')));
    return;
  }
  e.respondWith(
    fetch(e.request)
      .then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); return res; })
      .catch(() => caches.match(e.request))
  );
});
