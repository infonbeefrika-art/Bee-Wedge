'use strict';
import { h } from './js/dom.js';
import { T } from './js/strings.js';
import { api, state, store, loadMe, loadMeta, entry } from './js/api.js';
import { parseHash, safeNext, safeRef } from './js/format.js';
import { go, loadingView, errorView, refreshSummary, paintBadge } from './js/ui.js';
import { landing } from './js/views/landing.js';
import { join, loginView, forgotView } from './js/views/auth.js';
import { recordView } from './js/views/record.js';
import { businessView } from './js/views/business.js';
import { findView } from './js/views/find.js';
import { workerProfileView } from './js/views/profile.js';
import { adminView } from './js/views/admin.js';
import { requestsView } from './js/views/requests.js';
import { threadView } from './js/views/thread.js';
import { cardView } from './js/views/card.js';
import { vouchesView } from './js/views/vouches.js';
import { passportView } from './js/views/passport.js';
import { scanView } from './js/views/scan.js';
import { creditsView, invoicesView, invoiceView } from './js/views/billing.js';

const $app = document.getElementById('app');
let adminOpts = { section: 'proof', status: undefined };
let seq = 0; // ignores slow responses from screens the user already left

function show(nodes) {
  $app.replaceChildren(h('main', { class: 'screen' }, nodes));
  window.scrollTo(0, 0);
}

const ALLOWED = {
  worker: ['record', 'requests', 'thread', 'card', 'vouches', 'passport', 'scan', 'credits', 'invoices', 'invoice'],
  employer: ['find', 'business', 'worker', 'requests', 'thread', 'card', 'scan', 'invoices', 'invoice'],
  admin: ['admin', 'worker'],
};

async function homeFor(role) {
  if (role === 'worker') return '/record';
  if (role === 'admin') return '/admin';
  const { profile } = await api('/employer/profile');
  return profile.complete ? '/find' : '/business';
}

async function route(flash) {
  const mine = ++seq;
  if (state.poll) { clearInterval(state.poll); state.poll = null; }
  const r = parseHash(location.hash);
  const draw = (nodes) => { if (mine === seq) { show(nodes); paintBadge(); } };
  try {
    if (!store.token) {
      if (['join', 'login', 'forgot'].includes(r.name)) { try { await loadMeta(); } catch (e) { /* offline: defaults apply */ } }
      if (r.name === 'join' || r.name === 'login') entry.remember({ next: safeNext(r.query.next), ref: safeRef(r.query.ref) });
      if (r.name === 'join') return draw(join(r.query.role, draw));
      if (r.name === 'login') return draw(loginView());
      if (r.name === 'forgot') return draw(forgotView(draw));
      return draw(landing());
    }
    draw(loadingView());
    await loadMeta();
    if (!state.me) await loadMe();
    const role = state.me.role;
    if (['home', 'join', 'login', 'notfound'].includes(r.name) || !(ALLOWED[role] || []).includes(r.name)) {
      const dest = await homeFor(role);
      const nx = role === 'employer' ? safeNext(entry.next) : null;
      if (nx && dest === '/find') { entry.clearNext(); return go(nx); }
      if (!nx) entry.clearNext();
      return go(dest);
    }
    const rerender = (f, opts) => { if (opts) adminOpts = opts; route(f); };
    await refreshSummary();
    switch (r.name) {
      case 'record': return draw(await recordView(flash, rerender));
      case 'business': return draw(await businessView(flash, rerender));
      case 'find': return draw(findView());
      case 'worker': return draw(await workerProfileView(r.params.id));
      case 'admin': return draw(await adminView(adminOpts, flash, rerender));
      case 'requests': return draw(await requestsView());
      case 'thread': return draw(await threadView(r.params.id, rerender));
      case 'card': return draw(await cardView(r.query.for));
      case 'vouches': return draw(await vouchesView(flash, rerender));
      case 'passport': return draw(await passportView(flash, rerender));
      case 'scan': return draw(await scanView());
      case 'credits': return draw(await creditsView(flash, rerender));
      case 'invoices': return draw(await invoicesView());
      case 'invoice': return draw(await invoiceView(r.params.id, flash, rerender));
    }
  } catch (e) {
    if (!store.token) return draw(landing());
    if (e.status === 404 && r.name === 'worker') return go('/find');
    if (e.data && e.data.code === 'business_profile_incomplete') return go('/business');
    draw(errorView(e.message, () => route()));
  }
}

state.onLogout = () => { state.summary = null; paintBadge(); go('/'); };
setInterval(() => { if (store.token && document.visibilityState === 'visible') refreshSummary(); }, 30000);
window.addEventListener('hashchange', () => route());
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
route();
