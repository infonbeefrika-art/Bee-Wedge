<?php
declare(strict_types=1);

// Public employer page: /e/BF-XXXXXX. See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

use Beefrika\Db;
use Beefrika\EmployerPage;

try {
    $db = Db::pdo();
    $data = EmployerPage::find($db, (string)($_GET['id'] ?? ''));
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-cache');
    if ($data === null) {
        http_response_code(404);
        echo EmployerPage::notFound();
        exit;
    }
    echo EmployerPage::render($data);
} catch (Throwable $e) {
    error_log('Employer page error: ' . get_class($e) . ': ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Something went wrong. Please try again.';
}
