<?php
declare(strict_types=1);

// Terms of Use and Privacy Notice: /terms and /privacy. See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

$html = \Beefrika\Legal::render((string)($_GET['page'] ?? ''));
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=3600');
if ($html === null) {
    http_response_code(404);
    echo 'Not found';
    exit;
}
echo $html;
