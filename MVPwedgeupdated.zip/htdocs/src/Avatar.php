<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Profile photos for workers and employers. One photo per person, stored outside the web folders and shown at /a/<token>.
 * The token is random and changes on every new upload, so an old link stops working when the photo is replaced or removed.
 */
final class Avatar
{
    private static ?string $dirOverride = null;

    public static function useStorageDir(?string $dir): void
    {
        self::$dirOverride = $dir;
    }

    public static function dir(): string
    {
        $d = self::$dirOverride ?? (BF_ROOT . '/storage/avatars');
        if (!is_dir($d)) {
            @mkdir($d, 0750, true);
        }
        return $d;
    }

    /** @param int[] $ids @return array<int,string> user id => token. Empty when the table is not created yet. */
    public static function tokens(PDO $db, array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if ($ids === []) {
            return [];
        }
        try {
            $st = $db->prepare('SELECT user_id, token FROM user_avatars WHERE user_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
            $st->execute($ids);
            $out = [];
            foreach ($st->fetchAll() as $r) {
                $out[(int)$r['user_id']] = (string)$r['token'];
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function urlOf(PDO $db, int $userId): ?string
    {
        $t = self::tokens($db, [$userId])[$userId] ?? null;
        return $t === null ? null : '/a/' . $t;
    }

    public static function url(?string $token): ?string
    {
        return $token === null ? null : '/a/' . $token;
    }

    /** GET /a/<token>. Sends the photo of an active account. Never lists or reveals anything else. */
    public static function serve(PDO $db, string $token): never
    {
        $file = null;
        if (preg_match('/^[a-f0-9]{24}$/', $token)) {
            $st = $db->prepare("SELECT a.file FROM user_avatars a JOIN users u ON u.id = a.user_id WHERE a.token = ? AND u.status = 'active'");
            $st->execute([$token]);
            $file = $st->fetchColumn() ?: null;
        }
        $path = $file === null ? '' : self::dir() . '/' . basename((string)$file);
        if ($file === null || !is_file($path)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Not found';
            exit;
        }
        header('Content-Type: image/jpeg');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: public, max-age=86400');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
}
