<?php
declare(strict_types=1);

namespace Beefrika;

/** Reads settings from a server-side .env file or real environment variables. Nothing is hardcoded. */
final class Env
{
    private static array $vars = [];

    public static function load(string $path): void
    {
        if (!is_readable($path)) {
            return;
        }
        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$k, $v] = explode('=', $line, 2);
            $v = trim($v);
            if ($v !== '' && $v[0] === '#') {
                $v = '';
            } elseif (strlen($v) >= 2 && ($v[0] === '"' || $v[0] === "'") && substr($v, -1) === $v[0]) {
                $v = substr($v, 1, -1);
            } else {
                // allow trailing "# comment" on unquoted values
                $v = trim(preg_replace('/\s+#.*$/', '', $v) ?? $v);
            }
            self::$vars[trim($k)] = $v;
        }
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        if (array_key_exists($key, self::$vars)) {
            return self::$vars[$key] === '' ? $default : self::$vars[$key];
        }
        $e = getenv($key);
        return ($e === false || $e === '') ? $default : $e;
    }

    public static function int(string $key, int $default): int
    {
        $v = self::get($key);
        return ($v !== null && ctype_digit($v)) ? (int)$v : $default;
    }

    public static function need(string $key): string
    {
        $v = self::get($key);
        if ($v === null) {
            throw new \RuntimeException("Missing required setting: $key");
        }
        return $v;
    }

    /** For tests only. */
    public static function set(string $key, string $value): void
    {
        self::$vars[$key] = $value;
    }
}
