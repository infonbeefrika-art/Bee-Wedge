<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Hiring fee = the worker category's base price x the type of hire. See Pricing for the amounts.
 * Types at launch: short_gig (0.5x) and contract (1x). Permanent hires (1.5x) are not offered yet.
 */
final class FeeCalculator
{
    public function __construct(private PDO $db)
    {
    }

    public static function round100(float $value): int
    {
        return (int)(round($value / 100) * 100);
    }

    /** @return array{base:int,fee:int,multiplier:float} */
    public static function compute(int $baseNgn, float $categoryFactor, float $multiplier): array
    {
        $base = self::round100($baseNgn * $categoryFactor);
        return ['base' => $base, 'fee' => self::round100($base * $multiplier), 'multiplier' => $multiplier];
    }

    /**
     * Quotes for each type of hire we offer, from the worker's experience (which sets their category).
     * The old trade factor and the database price tables are no longer used.
     * @return array<string,array{base:int,fee:int,multiplier:float,category:string,category_label:string}>|null null when the worker has not set their experience
     */
    public function quotesFor(?int $tradeId, ?string $experience): ?array
    {
        $out = [];
        foreach (['short_gig', 'contract'] as $type) {
            $q = Pricing::quote($experience, $type);
            if ($q !== null) {
                $out[$type] = $q;
            }
        }
        return $out ?: null;
    }
}
