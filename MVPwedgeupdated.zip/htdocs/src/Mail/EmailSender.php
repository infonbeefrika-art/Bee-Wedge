<?php
declare(strict_types=1);

namespace Beefrika\Mail;

interface EmailSender
{
    public function send(string $to, string $subject, string $text): void;
}
