<?php
declare(strict_types=1);

namespace Beefrika\Mail;

use Beefrika\Clock;

final class MockEmailSender implements EmailSender
{
    public function __construct(private string $logFile)
    {
    }

    public function send(string $to, string $subject, string $text): void
    {
        @file_put_contents($this->logFile, Clock::dt() . " MOCK-EMAIL to=$to subject=$subject :: $text\n", FILE_APPEND | LOCK_EX);
    }
}
