<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * One-time codes for SMS or email.
 * - 6 digits from random_int, stored only as an HMAC hash, single use
 * - expiry, wrong-attempt limit, resend cooldown, per-destination and per-IP send limits
 * The code is never returned to the caller. The sender delivers it.
 */
final class Otp
{
    private const GENERIC_BAD_CODE = 'That code is wrong or has expired. Please request a new one.';

    private int $ttl;
    private int $maxAttempts;
    private int $cooldown;
    private int $maxHour;
    private int $maxDay;
    private int $maxIpHour;

    public function __construct(private PDO $db)
    {
        $this->ttl = Env::int('OTP_TTL_SECONDS', 300);
        $this->maxAttempts = Env::int('OTP_MAX_ATTEMPTS', 5);
        $this->cooldown = Env::int('OTP_RESEND_COOLDOWN_SECONDS', 60);
        $this->maxHour = Env::int('OTP_MAX_PER_PHONE_HOUR', 3);
        $this->maxDay = Env::int('OTP_MAX_PER_PHONE_DAY', 10);
        $this->maxIpHour = Env::int('OTP_MAX_PER_IP_HOUR', 20);
    }

    public function ttl(): int
    {
        return $this->ttl;
    }

    public function cooldown(): int
    {
        return $this->cooldown;
    }

    /**
     * @param callable(string $code): void $deliver  sends the code to the user; throw on failure
     */
    public function issue(string $channel, string $destination, string $purpose, string $ip, callable $deliver): void
    {
        $now = Clock::now();
        $ipHash = Security::ipHash($ip);

        // Cooldown (across all purposes for this destination)
        $last = $this->scalar(
            'SELECT MAX(created_at) FROM otp_codes WHERE channel = ? AND destination = ?',
            [$channel, $destination]
        );
        if ($last !== null) {
            $wait = $this->cooldown - ($now - strtotime($last . ' UTC'));
            if ($wait > 0) {
                throw new ApiException("Please wait $wait seconds before asking for another code.", 429, ['retry_after' => $wait]);
            }
        }
        if ($this->sentSince($channel, $destination, $now - 3600) >= $this->maxHour) {
            throw new ApiException('Too many codes requested. Please try again in an hour.', 429);
        }
        if ($this->sentSince($channel, $destination, $now - 86400) >= $this->maxDay) {
            throw new ApiException('Daily code limit reached. Please try again tomorrow.', 429);
        }
        $ipCount = (int)$this->scalar(
            'SELECT COUNT(*) FROM otp_codes WHERE ip_hash = ? AND created_at >= ?',
            [$ipHash, Clock::dt($now - 3600)]
        );
        if ($ipCount >= $this->maxIpHour) {
            throw new ApiException('Too many requests from this network. Please try again later.', 429);
        }

        // Newest code replaces any older unused one.
        $this->db->prepare(
            'UPDATE otp_codes SET used_at = ? WHERE channel = ? AND destination = ? AND purpose = ? AND used_at IS NULL'
        )->execute([Clock::dt(), $channel, $destination, $purpose]);

        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $this->db->prepare(
            'INSERT INTO otp_codes (channel, destination, purpose, code_hash, attempts, expires_at, ip_hash, created_at)
             VALUES (?, ?, ?, ?, 0, ?, ?, ?)'
        )->execute([$channel, $destination, $purpose, $this->hash($channel, $destination, $purpose, $code), Clock::dt($now + $this->ttl), $ipHash, Clock::dt()]);
        $id = (int)$this->db->lastInsertId();

        try {
            $deliver($code);
        } catch (ApiException $e) {
            $this->burn($id);
            throw $e;
        } catch (\Throwable $e) {
            $this->burn($id);
            error_log('OTP delivery failed: ' . $e->getMessage());
            throw new ApiException('We could not send the code. Please try again shortly.', 502);
        }
    }

    /** Throws ApiException unless the code is correct. Marks it used on success. */
    public function verify(string $channel, string $destination, string $purpose, string $code): void
    {
        if (!preg_match('/^\d{6}$/', $code)) {
            throw new ApiException(self::GENERIC_BAD_CODE, 400);
        }
        $st = $this->db->prepare(
            'SELECT id, code_hash, attempts, expires_at FROM otp_codes
             WHERE channel = ? AND destination = ? AND purpose = ? AND used_at IS NULL
             ORDER BY id DESC LIMIT 1'
        );
        $st->execute([$channel, $destination, $purpose]);
        $row = $st->fetch();
        if (!$row || strtotime($row['expires_at'] . ' UTC') < Clock::now()) {
            throw new ApiException(self::GENERIC_BAD_CODE, 400);
        }
        if ((int)$row['attempts'] >= $this->maxAttempts) {
            $this->burn((int)$row['id']);
            throw new ApiException(self::GENERIC_BAD_CODE, 400);
        }
        if (!hash_equals($row['code_hash'], $this->hash($channel, $destination, $purpose, $code))) {
            $attempts = (int)$row['attempts'] + 1;
            $this->db->prepare('UPDATE otp_codes SET attempts = ? WHERE id = ?')->execute([$attempts, $row['id']]);
            if ($attempts >= $this->maxAttempts) {
                $this->burn((int)$row['id']);
            }
            throw new ApiException(self::GENERIC_BAD_CODE, 400);
        }
        $upd = $this->db->prepare('UPDATE otp_codes SET used_at = ? WHERE id = ? AND used_at IS NULL');
        $upd->execute([Clock::dt(), $row['id']]);
        if ($upd->rowCount() !== 1) { // lost a race with another request using the same code
            throw new ApiException(self::GENERIC_BAD_CODE, 400);
        }
    }

    private function hash(string $channel, string $destination, string $purpose, string $code): string
    {
        return Security::hmac("otp|$channel|$destination|$purpose|$code");
    }

    private function burn(int $id): void
    {
        $this->db->prepare('UPDATE otp_codes SET used_at = ? WHERE id = ? AND used_at IS NULL')->execute([Clock::dt(), $id]);
    }

    private function sentSince(string $channel, string $destination, int $ts): int
    {
        return (int)$this->scalar(
            'SELECT COUNT(*) FROM otp_codes WHERE channel = ? AND destination = ? AND created_at >= ?',
            [$channel, $destination, Clock::dt($ts)]
        );
    }

    private function scalar(string $sql, array $params): mixed
    {
        $st = $this->db->prepare($sql);
        $st->execute($params);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    }
}
