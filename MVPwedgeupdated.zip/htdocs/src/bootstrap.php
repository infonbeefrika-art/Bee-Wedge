<?php
declare(strict_types=1);

define('BF_ROOT', dirname(__DIR__));

spl_autoload_register(static function (string $class): void {
    $prefix = 'Beefrika\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $file = BF_ROOT . '/src/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

\Beefrika\Env::load(BF_ROOT . '/.env');
date_default_timezone_set('UTC');
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
$bfLogDir = BF_ROOT . '/storage/logs';
if (!is_dir($bfLogDir)) {
    @mkdir($bfLogDir, 0750, true);
}
ini_set('error_log', $bfLogDir . '/php_errors.log');
