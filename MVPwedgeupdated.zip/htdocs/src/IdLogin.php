<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Log in with a Beefrika ID instead of a phone number. OFF for everyone by default. A person can switch it on for their own
 * account (for example in case they lose their phone), but only with a very strong password, and at their own risk:
 * the ID is printed on public pages, so the password is then the only secret.
 */
final class IdLogin
{
    public static function enabled(PDO $db, int $userId): bool
    {
        try {
            $st = $db->prepare('SELECT id_login_enabled FROM user_security WHERE user_id = ?');
            $st->execute([$userId]);
            return (int)$st->fetchColumn() === 1;
        } catch (\Throwable $e) {
            return false; // table not created yet: off
        }
    }

    public static function set(PDO $db, int $userId, bool $on): void
    {
        try {
            $has = $db->prepare('SELECT 1 FROM user_security WHERE user_id = ?');
            $has->execute([$userId]);
            if ($has->fetchColumn()) {
                $db->prepare('UPDATE user_security SET id_login_enabled = ?, updated_at = ? WHERE user_id = ?')->execute([$on ? 1 : 0, Clock::dt(), $userId]);
            } elseif ($on) {
                $db->prepare('INSERT INTO user_security (user_id, id_login_enabled, updated_at) VALUES (?, 1, ?)')->execute([$userId, Clock::dt()]);
            }
        } catch (\Throwable $e) {
            if ($on) {
                throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
            }
        }
    }
}
