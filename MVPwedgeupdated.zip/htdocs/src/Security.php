<?php
declare(strict_types=1);

namespace Beefrika;

final class Security
{
    private const ID_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no I, L, O, 0, 1

    public static function secret(): string
    {
        $s = Env::need('OTP_HMAC_SECRET');
        if (strlen($s) < 32) {
            throw new \RuntimeException('OTP_HMAC_SECRET must be at least 32 characters');
        }
        return $s;
    }

    public static function hmac(string $data): string
    {
        return hash_hmac('sha256', $data, self::secret());
    }

    /** Raw IPs are not stored; only a keyed hash. */
    public static function ipHash(string $ip): string
    {
        return self::hmac('ip|' . $ip);
    }

    public static function newToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    public static function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }

    public static function newBeefrikaId(): string
    {
        $out = '';
        $max = strlen(self::ID_ALPHABET) - 1;
        for ($i = 0; $i < 6; $i++) {
            $out .= self::ID_ALPHABET[random_int(0, $max)];
        }
        return 'BF-' . $out;
    }

    /** Returns an error message, or null if the password is acceptable. */
    public static function passwordProblem(string $password, string $phone): ?string
    {
        $len = mb_strlen($password);
        if ($len < 8) {
            return 'Password must be at least 8 characters.';
        }
        if ($len > 128) {
            return 'Password is too long.';
        }
        $digits = preg_replace('/\D/', '', $phone) ?? '';
        $last10 = substr($digits, -10);
        if (in_array($password, [$digits, $last10, '0' . $last10], true)) {
            return 'Do not use your phone number as your password.';
        }
        if (count(array_unique(mb_str_split($password))) < 3) {
            return 'Choose a password that is harder to guess.';
        }
        $weak = ['password', '12345678', '123456789', '1234567890', 'qwertyui', 'password1', 'beefrika', 'abcd1234', '11111111', '00000000'];
        if (in_array(strtolower($password), $weak, true)) {
            return 'Choose a password that is harder to guess.';
        }
        return null;
    }

    /**
     * Rules for accounts that allow log-in with a Beefrika ID. The ID is public, so the password has to hold on its own:
     * at least 12 characters, with three kinds of characters (or 20+ characters as a passphrase), and nothing personal in it.
     */
    public static function veryStrongPasswordProblem(string $password, string $phone, string $beefrikaId, string $fullName): ?string
    {
        if ($problem = self::passwordProblem($password, $phone)) {
            return $problem;
        }
        $len = mb_strlen($password);
        if ($len < 12) {
            return 'For log-in with your Beefrika ID the password must be at least 12 characters.';
        }
        $kinds = (preg_match('/[a-z]/', $password) ? 1 : 0) + (preg_match('/[A-Z]/', $password) ? 1 : 0)
            + (preg_match('/\d/', $password) ? 1 : 0) + (preg_match('/[^a-zA-Z\d]/', $password) ? 1 : 0);
        if ($len < 20 && $kinds < 3) {
            return 'Use at least three of: small letters, capital letters, numbers, symbols. Or make it 20 characters or longer.';
        }
        if (count(array_unique(mb_str_split(mb_strtolower($password)))) < 7) {
            return 'Choose a password with more different characters.';
        }
        $lower = mb_strtolower($password);
        $digits = substr(preg_replace('/\D/', '', $phone) ?? '', -10);
        if (str_contains($lower, mb_strtolower($beefrikaId)) || str_contains($lower, mb_strtolower(substr($beefrikaId, 3)))
            || ($digits !== '' && strlen($digits) >= 7 && str_contains($lower, $digits))) {
            return 'Do not put your Beefrika ID or phone number inside your password.';
        }
        foreach (preg_split('/\s+/', mb_strtolower($fullName)) ?: [] as $part) {
            if (mb_strlen($part) >= 3 && str_contains($lower, $part)) {
                return 'Do not put your name inside your password.';
            }
        }
        return null;
    }
}
