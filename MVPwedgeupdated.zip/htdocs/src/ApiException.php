<?php
declare(strict_types=1);

namespace Beefrika;

/** An error that is safe to show to the user. */
final class ApiException extends \RuntimeException
{
    public function __construct(string $message, public readonly int $status = 400, public readonly array $extra = [])
    {
        parent::__construct($message, $status);
    }
}
