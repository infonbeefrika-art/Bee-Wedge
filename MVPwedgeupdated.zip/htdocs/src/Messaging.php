<?php
declare(strict_types=1);

namespace Beefrika;

use Beefrika\Mail\EmailSender;
use Beefrika\Mail\MockEmailSender;
use Beefrika\Sms\MockSmsSender;
use Beefrika\Sms\SmsSender;
use Beefrika\Sms\TermiiSmsSender;

/** Chooses the SMS/email sender from settings. Fails closed in production. */
final class Messaging
{
    public static function isProduction(): bool
    {
        return Env::get('APP_ENV', 'production') === 'production';
    }

    public static function smsMode(): string
    {
        return Env::get('OTP_MODE', 'live') === 'mock' ? 'mock' : 'live';
    }

    public static function sms(): SmsSender
    {
        if (self::smsMode() === 'mock') {
            if (self::isProduction()) {
                throw new \RuntimeException('OTP_MODE=mock is not allowed when APP_ENV=production');
            }
            return new MockSmsSender(BF_ROOT . '/storage/logs/otp_mock.log');
        }
        return new TermiiSmsSender(
            Env::need('TERMII_API_KEY'),
            Env::need('TERMII_SENDER_ID'),
            Env::get('TERMII_BASE_URL', 'https://api.ng.termii.com'),
            Env::get('TERMII_CHANNEL', 'dnd'),
        );
    }

    public static function email(): EmailSender
    {
        if (Env::get('EMAIL_MODE', 'live') === 'mock' && !self::isProduction()) {
            return new MockEmailSender(BF_ROOT . '/storage/logs/otp_mock.log');
        }
        throw new ApiException('Email verification is not available yet.', 503);
    }
}
