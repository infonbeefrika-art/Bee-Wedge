<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Who a worker is, in their own words: worker type, years of experience and economic role.
 * These replace the old skill levels (beginner ... expert). Stored in worker_traits, one row per person.
 * The experience value is also what the hiring fee base is looked up by.
 */
final class WorkerTraits
{
    public const TYPES = ['apprentice', 'worker', 'freelancer', 'artisan_professional', 'business_owner'];
    public const EXPERIENCE = ['y0_1', 'y1_3', 'y3_5', 'y5_10', 'y10_plus'];
    public const ROLES = ['job_seeker', 'service_provider', 'employer', 'entrepreneur'];
    public const LABELS = [
        'apprentice' => 'Apprentice', 'worker' => 'Worker', 'freelancer' => 'Freelancer', 'artisan_professional' => 'Artisan / Professional', 'business_owner' => 'Business owner',
        'y0_1' => '0-1 years', 'y1_3' => '1-3 years', 'y3_5' => '3-5 years', 'y5_10' => '5-10 years', 'y10_plus' => '10+ years',
        'job_seeker' => 'Job seeker', 'service_provider' => 'Service provider', 'employer' => 'Employer', 'entrepreneur' => 'Entrepreneur',
    ];

    /** False until the database update that creates worker_traits has been run. */
    public static function ready(PDO $db): bool
    {
        try {
            $db->query('SELECT user_id FROM worker_traits LIMIT 1');
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** @return array{worker_type:?string,experience:?string,economic_role:?string} */
    public static function get(PDO $db, int $userId): array
    {
        return self::many($db, [$userId])[$userId] ?? self::empty();
    }

    /** @param int[] $ids @return array<int,array{worker_type:?string,experience:?string,economic_role:?string}> */
    public static function many(PDO $db, array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        $out = [];
        foreach ($ids as $id) {
            $out[$id] = self::empty();
        }
        if ($ids === []) {
            return $out;
        }
        try {
            $st = $db->prepare('SELECT user_id, worker_type, experience, economic_role FROM worker_traits WHERE user_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
            $st->execute($ids);
            foreach ($st->fetchAll() as $r) {
                $out[(int)$r['user_id']] = ['worker_type' => $r['worker_type'], 'experience' => $r['experience'], 'economic_role' => $r['economic_role']];
            }
        } catch (\Throwable $e) {
            // table not created yet: everyone shows as "not given"
        }
        return $out;
    }

    public static function save(PDO $db, int $userId, ?string $type, ?string $experience, ?string $role): void
    {
        $has = $db->prepare('SELECT 1 FROM worker_traits WHERE user_id = ?');
        $has->execute([$userId]);
        if ($has->fetchColumn()) {
            $db->prepare('UPDATE worker_traits SET worker_type = ?, experience = ?, economic_role = ?, updated_at = ? WHERE user_id = ?')
                ->execute([$type, $experience, $role, Clock::dt(), $userId]);
        } else {
            $db->prepare('INSERT INTO worker_traits (user_id, worker_type, experience, economic_role, updated_at) VALUES (?, ?, ?, ?, ?)')
                ->execute([$userId, $type, $experience, $role, Clock::dt()]);
        }
    }

    private static function empty(): array
    {
        return ['worker_type' => null, 'experience' => null, 'economic_role' => null];
    }
}
