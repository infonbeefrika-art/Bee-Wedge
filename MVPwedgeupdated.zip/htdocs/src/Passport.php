<?php
declare(strict_types=1);

namespace Beefrika;

use Beefrika\Controllers\Input;
use PDO;

/**
 * Work Passport: a private link a worker makes for one person or organisation (a bank, an employer, a landlord).
 * It shows the worker's Beefrika record, checked live every time it is opened, so it cannot be out of date.
 * The worker chooses what it includes and how long it works, and can switch it off at any time.
 * Every opening is counted, so the worker can see who looked.
 */
final class Passport
{
    public const EXPIRY_DAYS = [7, 30, 90, 0]; // 0 = until the worker switches it off
    public const MAX_ACTIVE = 20;

    /** @return array{items:array} */
    public static function listFor(PDO $db, int $workerId): array
    {
        $st = $db->prepare('SELECT id, token, label, include_jobs, include_vouches, include_feedback, expires_at, revoked_at, views, last_viewed_at, created_at FROM passports WHERE worker_id = ? ORDER BY id DESC LIMIT 50');
        $st->execute([$workerId]);
        $now = Clock::now();
        return ['items' => array_map(function ($r) use ($now) {
            $exp = $r['expires_at'] === null ? null : (strtotime($r['expires_at'] . ' UTC') ?: 0);
            $state = $r['revoked_at'] !== null ? 'off' : ($exp !== null && $exp <= $now ? 'expired' : 'on');
            return ['id' => (int)$r['id'], 'label' => $r['label'], 'url' => PublicProfile::baseUrl() . '/pass/' . $r['token'], 'state' => $state,
                'expires' => $exp === null ? null : gmdate('j M Y', $exp), 'views' => (int)$r['views'],
                'last_viewed' => $r['last_viewed_at'] === null ? null : gmdate('j M Y', strtotime($r['last_viewed_at'] . ' UTC') ?: 0),
                'jobs' => (bool)$r['include_jobs'], 'vouches' => (bool)$r['include_vouches'], 'feedback' => (bool)$r['include_feedback']];
        }, $st->fetchAll())];
    }

    public static function create(PDO $db, int $workerId, array $in): void
    {
        $label = Input::text($in, 'label', 2, 60, 'Who is it for');
        $days = (int)($in['days'] ?? 30);
        if (!in_array($days, self::EXPIRY_DAYS, true)) {
            throw new ApiException('Choose how long the passport should work.', 422);
        }
        $active = $db->prepare('SELECT COUNT(*) FROM passports WHERE worker_id = ? AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)');
        $active->execute([$workerId, Clock::dt()]);
        if ((int)$active->fetchColumn() >= self::MAX_ACTIVE) {
            throw new ApiException('You have many passports switched on. Switch some off first.', 422);
        }
        $db->prepare('INSERT INTO passports (worker_id, token, label, include_jobs, include_vouches, include_feedback, expires_at, views, created_at) VALUES (?,?,?,?,?,?,?,0,?)')
            ->execute([$workerId, bin2hex(random_bytes(12)), $label, !empty($in['jobs']) ? 1 : 0, !empty($in['vouches']) ? 1 : 0, !empty($in['feedback']) ? 1 : 0,
                $days === 0 ? null : Clock::dt(Clock::now() + $days * 86400), Clock::dt()]);
    }

    public static function revoke(PDO $db, int $workerId, int $id): void
    {
        $st = $db->prepare('UPDATE passports SET revoked_at = ? WHERE id = ? AND worker_id = ? AND revoked_at IS NULL');
        $st->execute([Clock::dt(), $id, $workerId]);
        if ($st->rowCount() !== 1) {
            throw new ApiException('Passport not found, or it is already off.', 404);
        }
    }

    /** The passport if its link works right now: not off, not expired, worker account active. */
    public static function find(PDO $db, string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{24}$/', $token)) {
            return null;
        }
        $st = $db->prepare(
            "SELECT p.id, p.worker_id, p.label, p.include_jobs, p.include_vouches, p.include_feedback, p.expires_at FROM passports p
             JOIN users u ON u.id = p.worker_id WHERE p.token = ? AND p.revoked_at IS NULL AND u.role = 'worker' AND u.status = 'active'"
        );
        $st->execute([$token]);
        $p = $st->fetch();
        if (!$p) {
            return null;
        }
        if ($p['expires_at'] !== null && (strtotime($p['expires_at'] . ' UTC') ?: 0) <= Clock::now()) {
            return null;
        }
        return $p;
    }

    public static function recordView(PDO $db, int $id, string $userAgent): void
    {
        if ($userAgent === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|whatsapp|telegram|preview|curl|wget|python|http-client|go-http/i', $userAgent)) {
            return;
        }
        $db->prepare('UPDATE passports SET views = views + 1, last_viewed_at = ? WHERE id = ?')->execute([Clock::dt(), $id]);
    }

    public static function notFound(): string
    {
        return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">'
            . '<title>Passport not available | Beefrika</title><link rel="stylesheet" href="/style.css"></head><body><main class="screen center"><img src="/icons/logo-96.png" width="72" height="72" alt="">'
            . '<h1>This passport is not available</h1><p>The worker may have switched it off, or it has expired. Ask the worker for a new one.</p><a class="btn" href="/">Go to Beefrika</a></main></body></html>';
    }

    public static function render(array $p, PDO $db, string $url): string
    {
        $e = [PublicProfile::class, 'e'];
        $uid = (int)$p['worker_id'];
        $st = $db->prepare(
            "SELECT u.beefrika_id, u.full_name, u.phone_verified_at, wp.headline, t.name AS trade_name, a.name AS area_name
             FROM users u JOIN worker_profiles wp ON wp.user_id = u.id LEFT JOIN trades t ON t.id = wp.primary_trade_id LEFT JOIN lagos_areas a ON a.id = wp.area_id WHERE u.id = ?"
        );
        $st->execute([$uid]);
        $w = $st->fetch() ?: ['beefrika_id' => '', 'full_name' => '', 'phone_verified_at' => null, 'headline' => '', 'trade_name' => null, 'area_name' => null];
        $traits = WorkerTraits::get($db, $uid);
        $proof = ProofLevel::forUser($db, $uid);
        $ev = $db->prepare(
            "SELECT label, level, source_name FROM verification_records WHERE user_id = ? AND level IN ('verified','evidence_submitted')
             AND claim_type IN ('skill','training','work_experience') ORDER BY (level = 'verified') DESC, id DESC LIMIT 30"
        );
        $ev->execute([$uid]);
        $claims = '';
        foreach ($ev->fetchAll() as $r) {
            $claims .= '<li class="claim"><div class="evhead">' . PublicProfile::badge(Trust::apiLevel($r['level'])) . '<b>' . $e($r['label']) . '</b></div>'
                . ($r['source_name'] ? '<div class="muted">Checked by: ' . $e($r['source_name']) . '</div>' : '') . '</li>';
        }
        $now = gmdate('j M Y, H:i') . ' UTC';
        $until = $p['expires_at'] === null ? 'until the worker switches it off' : 'until ' . gmdate('j M Y', strtotime($p['expires_at'] . ' UTC') ?: 0);
        $out = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
            . '<title>' . $e('Work Passport: ' . $w['full_name'] . ' | Beefrika') . '</title><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#F0A500"><link rel="icon" href="/icons/logo-96.png">'
            . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"><link rel="stylesheet" href="/style.css"></head><body><main class="screen passport">'
            . '<div class="brandbar"><img src="/icons/logo-96.png" alt="" width="40" height="40"><b>Beefrika</b>' . Pilot::pill() . '</div>'
            . '<p class="eyebrow">Work Passport</p>'
            . '<div class="msg ok" role="status"><b>Valid.</b> Checked live on ' . $e($now) . '. Shared for: ' . $e($p['label']) . '. Works ' . $e($until) . '.</div>'
            . '<section class="phero"><div class="phero-cover" aria-hidden="true"></div><div class="phero-body">' . PublicProfile::avatarHtml(Avatar::urlOf($db, $uid), $w['full_name'], 96)
            . '<div class="phero-text"><h1>' . $e($w['full_name']) . '</h1><p class="muted">' . $e(implode(' · ', array_filter([$w['trade_name'], $w['area_name'],
                WorkerTraits::LABELS[$traits['worker_type'] ?? ''] ?? null, WorkerTraits::LABELS[$traits['experience'] ?? ''] ?? null]))) . '</p>'
            . '<div class="phero-tags">' . PublicProfile::proofBadge($proof) . '</div>' . ($w['headline'] ? '<p class="lead">' . $e($w['headline']) . '</p>' : '')
            . '</div></div><div class="phero-stats"><div class="stat"><b>' . $e((string)$w['beefrika_id']) . '</b><span>Beefrika ID</span></div>'
            . '<div class="stat"><b>' . ($w['phone_verified_at'] ? 'Yes' : 'No') . '</b><span>Phone confirmed</span></div></div></section>'
            . '<h2>Proof</h2>' . ($claims !== '' ? '<ul class="claims">' . $claims . '</ul>' : '<p class="muted">No proof added yet.</p>')
            . '<p class="hint">Verified means a named source confirmed it. It is not a government check. Evidence means proof was added and Beefrika has not confirmed it.</p>';
        if (!empty($p['include_jobs'])) {
            $jobs = $db->prepare("SELECT title, employer_name, description, created_at FROM work_history WHERE user_id = ? AND source = 'beefrika_hire' ORDER BY id DESC LIMIT 20");
            $jobs->execute([$uid]);
            $rows = $jobs->fetchAll();
            $out .= '<h2>Jobs recorded on Beefrika</h2>';
            if (!$rows) {
                $out .= '<p class="muted">No jobs recorded on Beefrika yet.</p>';
            }
            else {
                $out .= '<p class="muted"><b>' . count($rows) . '</b> job' . (count($rows) === 1 ? '' : 's') . ' confirmed by both the employer and the worker.</p><ul class="claims">';
                foreach ($rows as $j) {
                    $out .= '<li class="claim"><b>' . $e($j['title']) . '</b><div class="muted">' . $e(implode(' · ', array_filter([$j['employer_name'], substr((string)$j['created_at'], 0, 4)]))) . '</div></li>';
                }
                $out .= '</ul>';
            }
        }
        if (!empty($p['include_vouches'])) {
            $out .= VouchPage::publicSection(Vouch::publicList($db, $uid));
        }
        if (!empty($p['include_feedback'])) {
            $out .= Feedback::section(Feedback::publicFor($db, $uid, 'worker'), 'Employer feedback', 'Employers rate a worker once a job is complete. Feedback shows when both sides have rated, or after 7 days.');
        }
        return $out . '<h2>Check this passport</h2><div class="card center"><div id="passportqr" data-url="' . $e($url) . '"></div><p class="hint">Scan to open this passport again. If it says "not available", the worker has switched it off or it has expired.</p></div>'
            . '<button class="btn noprint" id="printpassport" type="button">Print or save as PDF</button>'
            . '<p class="hint">Beefrika records evidence. It does not guarantee how anyone behaves, and it is not a credit score. The worker chose what is shown here.</p>'
            . Legal::footer() . '<script type="module" src="/js/passport.js"></script></main></body></html>';
    }
}
