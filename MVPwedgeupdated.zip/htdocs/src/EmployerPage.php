<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Public "check this employer" page at /e/BF-XXXXXX, opened by scanning the employer's QR card.
 * It is off until the employer switches it on, and it shows only what a worker needs to judge them: who they say they are,
 * what Beefrika has checked, and what has happened on Beefrika. Contact details never appear.
 * Reports against an employer are NOT shown here: anyone could file a false one. Admins act on reports, and a suspended account's page disappears.
 */
final class EmployerPage
{
    private const TYPES = ['household' => 'A household', 'small_business' => 'A small business', 'contractor' => 'A contractor', 'organisation' => 'An organisation'];
    private const LEVELS = [
        'self_reported' => 'Self-reported. The employer said this. Nobody has checked it.',
        'evidence' => 'Evidence added. Beefrika has not confirmed it.',
        'verified' => 'Verified. A named source confirmed it. Not a government check.',
    ];

    public static function isPublic(PDO $db, int $userId): bool
    {
        try {
            $st = $db->prepare('SELECT is_public FROM employer_pages WHERE user_id = ?');
            $st->execute([$userId]);
            return (int)$st->fetchColumn() === 1;
        } catch (\Throwable $e) {
            return false; // table not created yet
        }
    }

    public static function setPublic(PDO $db, int $userId, bool $on): void
    {
        try {
            $has = $db->prepare('SELECT 1 FROM employer_pages WHERE user_id = ?');
            $has->execute([$userId]);
            if ($has->fetchColumn()) {
                $db->prepare('UPDATE employer_pages SET is_public = ?, updated_at = ? WHERE user_id = ?')->execute([$on ? 1 : 0, Clock::dt(), $userId]);
            } elseif ($on) {
                $db->prepare('INSERT INTO employer_pages (user_id, is_public, updated_at) VALUES (?, 1, ?)')->execute([$userId, Clock::dt()]);
            }
        } catch (\Throwable $e) {
            if ($on) {
                throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
            }
        }
    }

    /** Path of the employer's public page, or null when it is off. */
    public static function pathFor(PDO $db, int $userId): ?string
    {
        if (!self::isPublic($db, $userId)) {
            return null;
        }
        $st = $db->prepare('SELECT beefrika_id FROM users WHERE id = ?');
        $st->execute([$userId]);
        $id = $st->fetchColumn();
        return $id ? '/e/' . $id : null;
    }

    public static function find(PDO $db, string $bfId): ?array
    {
        if (!preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $bfId)) {
            return null;
        }
        $st = $db->prepare(
            "SELECT u.id, u.beefrika_id, u.full_name, u.phone_verified_at, u.created_at, ep.employer_type, ep.business_name, ep.hires_for,
                    ep.association_name, ep.cac_number, a.name AS area_name
             FROM users u JOIN employer_profiles ep ON ep.user_id = u.id LEFT JOIN lagos_areas a ON a.id = ep.area_id
             WHERE u.beefrika_id = ? AND u.status = 'active'
               AND ep.employer_type IS NOT NULL AND ep.business_name IS NOT NULL AND ep.business_name <> '' AND ep.area_id IS NOT NULL"
        );
        $st->execute([$bfId]);
        $e = $st->fetch();
        if (!$e || !self::isPublic($db, (int)$e['id'])) {
            return null;
        }
        $uid = (int)$e['id'];
        $h = $db->prepare(
            "SELECT COUNT(*) AS jobs, COUNT(DISTINCT r.worker_id) AS workers FROM hires h JOIN hiring_requests r ON r.id = h.hiring_request_id
             WHERE r.employer_id = ? AND h.status IN ('confirmed','completed')"
        );
        $h->execute([$uid]);
        $hires = $h->fetch() ?: ['jobs' => 0, 'workers' => 0];
        return [
            'id' => $uid, 'beefrika_id' => $e['beefrika_id'], 'name' => $e['business_name'], 'owner' => $e['full_name'],
            'type' => $e['employer_type'], 'area' => $e['area_name'], 'hires_for' => $e['hires_for'], 'association' => $e['association_name'],
            'cac' => $e['cac_number'], 'phone_checked' => (bool)$e['phone_verified_at'], 'since' => Vouch::month((string)$e['created_at']),
            'trust' => Trust::bestLevel($db, $uid, 'business'), 'jobs' => (int)$hires['jobs'], 'workers' => (int)$hires['workers'],
            'avatar' => Avatar::urlOf($db, $uid), 'feedback' => Feedback::publicFor($db, $uid, 'employer'),
        ];
    }

    public static function notFound(): string
    {
        return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">'
            . '<title>Not available | Beefrika</title><link rel="stylesheet" href="/style.css"></head><body><main class="screen center"><img src="/icons/logo-96.png" width="72" height="72" alt="">'
            . '<h1>This page is not available</h1><p>The employer may have switched their page off, or the account is not active. If someone asked you to pay before work, do not pay.</p>'
            . '<a class="btn" href="/">Go to Beefrika</a></main></body></html>';
    }

    public static function render(array $d): string
    {
        $e = [PublicProfile::class, 'e'];
        $level = isset(self::LEVELS[$d['trust']]) ? $d['trust'] : 'self_reported';
        $row = static fn(string $label, string $value, string $state) => '<li class="check-row ' . $state . '"><b>' . $label . '</b><span>' . $value . '</span></li>';
        $rows = $row('Phone number', $d['phone_checked'] ? 'Confirmed with an SMS code.' : 'Not confirmed yet.', $d['phone_checked'] ? 'ok' : 'no')
            . $row('Business proof', $e(self::LEVELS[$level]), $level === 'verified' ? 'ok' : 'no')
            . ($d['cac'] ? $row('CAC number', $e($d['cac']) . ' (given by the employer, not checked by Beefrika). You can look it up yourself on the CAC public search.', 'no')
                : $row('CAC number', 'None given. Many households and small businesses are not registered, so ask your own questions.', 'no'))
            . ($d['association'] ? $row('Association', $e($d['association']) . ' (said by the employer).', 'no') : '')
            . $row('On Beefrika since', $e($d['since']), 'ok');
        $title = $d['name'] . ' | Check this employer | Beefrika';
        $first = explode(' ', trim((string)$d['owner']))[0];
        return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
            . '<title>' . $e($title) . '</title><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#F0A500"><link rel="icon" href="/icons/logo-96.png">'
            . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"><link rel="stylesheet" href="/style.css"></head><body><main class="screen">'
            . '<div class="brandbar"><img src="/icons/logo-96.png" alt="" width="40" height="40"><b>Beefrika</b>' . Pilot::pill() . '</div>'
            . '<p class="eyebrow">Check this employer</p>'
            . '<section class="phero"><div class="phero-cover" aria-hidden="true"></div><div class="phero-body">' . PublicProfile::avatarHtml($d['avatar'], $d['name'], 96)
            . '<div class="phero-text"><h1>' . $e($d['name']) . '</h1><p class="muted">' . $e(implode(' · ', array_filter([self::TYPES[$d['type']] ?? null, $d['area']]))) . '</p>'
            . '<div class="phero-tags">' . PublicProfile::badge($level) . '</div>'
            . ($d['hires_for'] ? '<p class="lead">Hires for: ' . $e($d['hires_for']) . '</p>' : '')
            . '</div></div><div class="phero-stats"><div class="stat"><b>' . $d['jobs'] . '</b><span>Jobs confirmed</span></div><div class="stat"><b>' . $d['workers']
            . '</b><span>Different workers</span></div></div></section>'
            . '<h2>What Beefrika knows</h2><ul class="check-list">' . $rows . '</ul>'
            . '<p class="hint">A confirmed job means the employer and the worker both confirmed it on Beefrika. It does not guarantee how anyone behaves.</p>'
            . Feedback::section($d['feedback'], 'Feedback from workers', 'Workers can rate an employer once a job is complete. Feedback shows when both sides have rated, or after 7 days.')
            . '<h2>Stay safe</h2><ul class="plain safety"><li>A real employer never asks you to pay to get a job or to start work.</li>'
            . '<li>Agree the job and the pay in the Beefrika chat first, so there is a record.</li>'
            . '<li>For a first job, meet in a known place and tell someone where you are going.</li>'
            . '<li>If something feels wrong, stop and report it in the app.</li></ul>'
            . '<a class="btn" href="/#/join?role=worker">I am a worker: make my free profile</a>'
            . '<a class="btn ghost" href="/#/login">I have an account: log in to report</a>'
            . '<p class="hint">This page shows what ' . $e($first !== '' ? $first : 'the employer') . ' told Beefrika and what happened on Beefrika. Contact details stay inside the app.</p>'
            . Legal::footer() . '</main></body></html>';
    }
}
