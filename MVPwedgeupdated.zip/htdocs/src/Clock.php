<?php
declare(strict_types=1);

namespace Beefrika;

/** All timestamps are UTC and produced in PHP so SQL stays portable. Time can be frozen in tests. */
final class Clock
{
    private static ?int $fixed = null;

    public static function now(): int
    {
        return self::$fixed ?? time();
    }

    public static function dt(?int $ts = null): string
    {
        return gmdate('Y-m-d H:i:s', $ts ?? self::now());
    }

    public static function freeze(?int $ts): void
    {
        self::$fixed = $ts;
    }

    public static function advance(int $seconds): void
    {
        self::$fixed = (self::$fixed ?? time()) + $seconds;
    }
}
