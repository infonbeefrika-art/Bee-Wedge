<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Invoices. Payment happens outside the app (bank transfer) and the Beefrika team marks an invoice paid.
 *  hire_fee: made for the employer when a hire is confirmed, so they can see it before paying. Refundable for a short window.
 *  credits:  made for a worker who wants more hiring credits. Credits are added when it is marked paid. Not refundable.
 */
final class Invoices
{
    public static function ready(PDO $db): bool
    {
        try {
            $db->query('SELECT id FROM invoices LIMIT 1');
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function idForHire(PDO $db, int $hireId): ?int
    {
        try {
            $st = $db->prepare('SELECT id FROM invoices WHERE hire_id = ?');
            $st->execute([$hireId]);
            $id = $st->fetchColumn();
            return $id === false ? null : (int)$id;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private static function insert(PDO $db, string $kind, int $payerId, ?int $hireId, ?string $pack, string $description, array $lines, int $amount): int
    {
        $db->prepare('INSERT INTO invoices (kind, payer_id, hire_id, pack, description, lines_json, amount_ngn, status, issued_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute([$kind, $payerId, $hireId, $pack, mb_substr($description, 0, 160), json_encode($lines, JSON_UNESCAPED_UNICODE), $amount, 'unpaid', Clock::dt()]);
        $id = (int)$db->lastInsertId();
        $db->prepare('UPDATE invoices SET number = ? WHERE id = ?')->execute(['INV-' . gmdate('Ymd') . '-' . sprintf('%05d', $id), $id]);
        return $id;
    }

    /** The employer's invoice for a confirmed hire. One per hire. */
    public static function createHireFee(PDO $db, int $hireId, int $employerId, string $jobTitle, string $workerName, array $quote): int
    {
        $existing = self::idForHire($db, $hireId);
        if ($existing !== null) {
            return $existing;
        }
        $types = ['short_gig' => 'Short gig', 'contract' => 'Contract', 'permanent' => 'Permanent'];
        $lines = [
            ['label' => 'Worker category: ' . $quote['category_label'], 'value' => Pricing::naira($quote['base'])],
            ['label' => 'Type of hire: ' . ($types[$quote['engagement_type']] ?? $quote['engagement_type']), 'value' => number_format($quote['multiplier'], 1) . ' x'],
            ['label' => 'Hiring fee', 'value' => Pricing::naira($quote['fee'])],
        ];
        return self::insert($db, 'hire_fee', $employerId, $hireId, null, 'Hiring fee: ' . $jobTitle . ' (' . $workerName . ')', $lines, $quote['fee']);
    }

    /** A worker's invoice for a pack of hiring credits. */
    public static function createCredits(PDO $db, int $userId, string $tier): int
    {
        if (!isset(Pricing::PACKS[$tier])) {
            throw new ApiException('Choose one of the packs.', 422);
        }
        [$hires, $price] = Pricing::PACKS[$tier];
        $open = $db->prepare("SELECT COUNT(*) FROM invoices WHERE payer_id = ? AND kind = 'credits' AND status = 'unpaid'");
        $open->execute([$userId]);
        if ((int)$open->fetchColumn() >= 5) {
            throw new ApiException('You already have several unpaid invoices. Pay or cancel those first.', 422);
        }
        $lines = [
            ['label' => $hires . ' hiring credits', 'value' => Pricing::naira($price)],
            ['label' => 'Per hire', 'value' => Pricing::naira((int)round($price / $hires))],
        ];
        return self::insert($db, 'credits', $userId, null, $tier, $hires . ' hiring credits', $lines, $price);
    }

    /** @return array<string,mixed> one invoice, shaped for the app, only if it belongs to $userId */
    public static function get(PDO $db, int $id, int $userId): array
    {
        $st = $db->prepare('SELECT * FROM invoices WHERE id = ? AND payer_id = ?');
        $st->execute([$id, $userId]);
        $r = $st->fetch();
        if (!$r) {
            throw new ApiException('Invoice not found.', 404);
        }
        $out = self::present($r);
        try {
            $p = $db->prepare("SELECT reference, method, created_at FROM payments WHERE invoice_id = ? AND status = 'success' ORDER BY id DESC LIMIT 1");
            $p->execute([$id]);
            $rec = $p->fetch();
            $out['receipt'] = $rec ? ['reference' => $rec['reference'], 'method' => $rec['method'], 'date' => gmdate('j M Y, H:i', strtotime($rec['created_at'] . ' UTC') ?: 0) . ' UTC'] : null;
        } catch (\Throwable $e) {
            $out['receipt'] = null;
        }
        return $out;
    }

    /** @return array<int,array<string,mixed>> */
    public static function listFor(PDO $db, int $userId): array
    {
        $st = $db->prepare('SELECT * FROM invoices WHERE payer_id = ? ORDER BY id DESC LIMIT 50');
        $st->execute([$userId]);
        return array_map([self::class, 'present'], $st->fetchAll());
    }

    public static function present(array $r): array
    {
        $until = $r['refund_until'] === null ? null : (strtotime($r['refund_until'] . ' UTC') ?: 0);
        $fee = $r['kind'] === 'hire_fee';
        return [
            'id' => (int)$r['id'], 'number' => $r['number'], 'kind' => $r['kind'], 'description' => $r['description'],
            'lines' => json_decode((string)$r['lines_json'], true) ?: [], 'amount' => (int)$r['amount_ngn'], 'status' => $r['status'],
            'issued' => gmdate('j M Y', strtotime($r['issued_at'] . ' UTC') ?: 0), 'paid' => $r['paid_at'] === null ? null : gmdate('j M Y', strtotime($r['paid_at'] . ' UTC') ?: 0),
            'refund_until' => $until === null ? null : gmdate('j M Y', $until),
            'can_refund' => $fee && $r['status'] === 'paid' && $until !== null && $until > Clock::now(),
            'refund_days' => $fee ? Pricing::refundDays() : null,
            'refund_reason' => $r['refund_reason'], 'admin_note' => $r['admin_note'],
            'payment' => Pricing::paymentInstructions(), 'payments_mode' => Pilot::paymentsMode(),
        ];
    }

    /**
     * Pilot checkout. No card details are asked for, stored or sent. "Pay" pretends to succeed, "fail" pretends to be declined.
     * A successful test payment marks the invoice paid exactly as a real one would: credits are added, the refund window starts.
     */
    public static function payTest(PDO $db, int $id, int $userId, string $method, bool $succeed): void
    {
        if (Pilot::paymentsMode() !== 'test') {
            throw new ApiException('Test payments are switched off.', 403);
        }
        if (!in_array($method, ['card', 'transfer', 'ussd'], true)) {
            throw new ApiException('Choose how you want to pay.', 422);
        }
        $st = $db->prepare('SELECT amount_ngn, status FROM invoices WHERE id = ? AND payer_id = ?');
        $st->execute([$id, $userId]);
        $inv = $st->fetch();
        if (!$inv) {
            throw new ApiException('Invoice not found.', 404);
        }
        if ($inv['status'] !== 'unpaid') {
            throw new ApiException('This invoice is not waiting for payment.', 409);
        }
        $ref = 'TEST-' . strtoupper(bin2hex(random_bytes(4)));
        try {
            $db->prepare('INSERT INTO payments (invoice_id, payer_id, method, status, amount_ngn, reference, mode, created_at) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([$id, $userId, $method, $succeed ? 'success' : 'failed', (int)$inv['amount_ngn'], $ref, 'test', Clock::dt()]);
        } catch (\PDOException $e) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
        if (!$succeed) {
            throw new ApiException('The test payment was declined. This is a pretend failure so you can see what it looks like. Nothing was charged.', 422);
        }
        self::markPaid($db, $id, 0, 'Test payment ' . $ref);
    }

    // ------------------------------------------------------------------ the Beefrika team

    /** Marks an invoice paid. A credits invoice adds the credits. A hire-fee invoice starts the refund window. */
    public static function markPaid(PDO $db, int $id, int $adminId, string $note): void
    {
        $st = $db->prepare('SELECT * FROM invoices WHERE id = ?');
        $st->execute([$id]);
        $inv = $st->fetch();
        if (!$inv) {
            throw new ApiException('Invoice not found.', 404);
        }
        $now = Clock::dt();
        $refund = $inv['kind'] === 'hire_fee' ? Clock::dt(Clock::now() + Pricing::refundDays() * 86400) : null;
        $upd = $db->prepare("UPDATE invoices SET status = 'paid', paid_at = ?, refund_until = ?, admin_note = ? WHERE id = ? AND status = 'unpaid'");
        $upd->execute([$now, $refund, mb_substr($note, 0, 500), $id]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This invoice is not waiting for payment.', 409);
        }
        if ($inv['kind'] === 'credits' && isset(Pricing::PACKS[$inv['pack'] ?? ''])) {
            Credits::grant($db, (int)$inv['payer_id'], Pricing::PACKS[$inv['pack']][0], 'purchase', $id);
        }
        if ($inv['kind'] === 'hire_fee' && $inv['hire_id'] !== null) {
            $db->prepare("UPDATE hires SET fee_status = 'paid', updated_at = ? WHERE id = ?")->execute([$now, (int)$inv['hire_id']]);
        }
    }

    /** The employer asks for a refund inside the window. */
    public static function requestRefund(PDO $db, int $id, int $userId, string $reason): void
    {
        $upd = $db->prepare(
            "UPDATE invoices SET status = 'refund_requested', refund_requested_at = ?, refund_reason = ?
             WHERE id = ? AND payer_id = ? AND kind = 'hire_fee' AND status = 'paid' AND refund_until > ?"
        );
        $upd->execute([Clock::dt(), mb_substr($reason, 0, 300), $id, $userId, Clock::dt()]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('A refund can no longer be requested for this invoice.', 409);
        }
    }

    public static function decideRefund(PDO $db, int $id, bool $approve, string $note): void
    {
        $st = $db->prepare("SELECT hire_id FROM invoices WHERE id = ? AND status = 'refund_requested'");
        $st->execute([$id]);
        $inv = $st->fetch();
        if (!$inv) {
            throw new ApiException('This invoice has no refund request waiting.', 409);
        }
        $db->prepare('UPDATE invoices SET status = ?, admin_note = ? WHERE id = ?')->execute([$approve ? 'refunded' : 'paid', mb_substr($note, 0, 500), $id]);
        if ($approve && $inv['hire_id'] !== null) {
            $db->prepare("UPDATE hires SET fee_status = 'waived', fee_note = ?, updated_at = ? WHERE id = ?")->execute(['Fee refunded to the employer.', Clock::dt(), (int)$inv['hire_id']]);
        }
    }
}
