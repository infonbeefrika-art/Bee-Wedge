<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Trust labels. Rule: nothing is labelled "verified" unless a check was actually done and recorded.
 * Levels shown to people: self_reported, evidence (proof added, not confirmed), verified (a named source confirmed it).
 * A phone/email code check proves control of a contact method only; it is reported separately and never counted as skill verification.
 */
final class Trust
{
    public static function apiLevel(string $dbLevel): string
    {
        return match ($dbLevel) {
            'verified' => 'verified',
            'evidence_submitted' => 'evidence',
            'rejected' => 'rejected',
            default => 'self_reported',
        };
    }

    /** @return array{verified:int,evidence:int,headline:string} counts of non-rejected records for a user */
    public static function counts(PDO $db, int $userId): array
    {
        $st = $db->prepare('SELECT level, COUNT(*) AS n FROM verification_records WHERE user_id = ? AND level IN (?, ?) GROUP BY level');
        $st->execute([$userId, 'verified', 'evidence_submitted']);
        $v = 0;
        $e = 0;
        foreach ($st->fetchAll() as $r) {
            if ($r['level'] === 'verified') {
                $v = (int)$r['n'];
            } else {
                $e = (int)$r['n'];
            }
        }
        return ['verified' => $v, 'evidence' => $e, 'headline' => $v > 0 ? 'verified' : ($e > 0 ? 'evidence' : 'self_reported')];
    }

    /** Highest level among a user's records for one claim type (e.g. business). */
    public static function bestLevel(PDO $db, int $userId, string $claimType): string
    {
        $st = $db->prepare('SELECT level FROM verification_records WHERE user_id = ? AND claim_type = ? AND level <> ?');
        $st->execute([$userId, $claimType, 'rejected']);
        $best = 'self_reported';
        foreach ($st->fetchAll() as $r) {
            if ($r['level'] === 'verified') {
                return 'verified';
            }
            $best = 'evidence';
        }
        return $best;
    }

    public static function forUser(array $user, ?array $workerProfile): array
    {
        $labels = [
            'phone'    => $user['phone_verified_at'] ? 'verified' : 'unverified',
            'email'    => $user['email_verified_at'] ? 'verified' : 'not_added',
            'identity' => 'not_started',
        ];
        if ($user['role'] === 'worker') {
            $labels['skills'] = ($workerProfile && !empty($workerProfile['primary_trade_id'])) ? 'self_reported' : 'not_started';
        }
        return $labels;
    }
}
