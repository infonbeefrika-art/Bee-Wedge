<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/** A worker's hiring credits. Each confirmed hire uses one. The first is free; more come in packs the worker pays for. Workers only: employers never see this. */
final class Credits
{
    public static function ready(PDO $db): bool
    {
        try {
            $db->query('SELECT id FROM credit_ledger LIMIT 1');
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Current balance. A worker who has never had credits gets the free opening credit here. */
    public static function balance(PDO $db, int $userId): int
    {
        $has = $db->prepare("SELECT COUNT(*) FROM credit_ledger WHERE user_id = ? AND reason = 'opening'");
        $has->execute([$userId]);
        if ((int)$has->fetchColumn() === 0) {
            $db->prepare('INSERT INTO credit_ledger (user_id, delta, reason, created_at) VALUES (?, ?, ?, ?)')
                ->execute([$userId, Pricing::OPENING_CREDITS, 'opening', Clock::dt()]);
        }
        $st = $db->prepare('SELECT COALESCE(SUM(delta), 0) FROM credit_ledger WHERE user_id = ?');
        $st->execute([$userId]);
        return (int)$st->fetchColumn();
    }

    public static function requireOne(PDO $db, int $userId): void
    {
        if (self::balance($db, $userId) < 1) {
            throw new ApiException('You need a hiring credit to confirm this hire. Buy a pack under Hiring credits, then confirm again.', 409, ['code' => 'no_credits']);
        }
    }

    public static function consume(PDO $db, int $userId, int $hireId): void
    {
        $has = $db->prepare("SELECT 1 FROM credit_ledger WHERE user_id = ? AND reason = 'hire' AND hire_id = ?");
        $has->execute([$userId, $hireId]);
        if (!$has->fetchColumn()) {
            $db->prepare('INSERT INTO credit_ledger (user_id, delta, reason, hire_id, created_at) VALUES (?, -1, ?, ?, ?)')->execute([$userId, 'hire', $hireId, Clock::dt()]);
        }
    }

    public static function grant(PDO $db, int $userId, int $hires, string $reason, ?int $invoiceId): void
    {
        $db->prepare('INSERT INTO credit_ledger (user_id, delta, reason, invoice_id, created_at) VALUES (?, ?, ?, ?, ?)')->execute([$userId, $hires, $reason, $invoiceId, Clock::dt()]);
    }

    /** @return array<int,array{delta:int,reason:string,date:string}> */
    public static function recent(PDO $db, int $userId, int $limit = 15): array
    {
        $st = $db->prepare('SELECT delta, reason, created_at FROM credit_ledger WHERE user_id = ? ORDER BY id DESC LIMIT ' . (int)$limit);
        $st->execute([$userId]);
        return array_map(fn($r) => ['delta' => (int)$r['delta'], 'reason' => $r['reason'], 'date' => gmdate('j M Y', strtotime($r['created_at'] . ' UTC') ?: 0)], $st->fetchAll());
    }
}
