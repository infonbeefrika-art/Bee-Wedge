<?php
declare(strict_types=1);

namespace Beefrika;

final class Phone
{
    /**
     * African countries: iso => [name, dial code, drops a leading 0 when dialled from abroad].
     * Numbers are saved in international form, for example +233241234567.
     */
    public const COUNTRIES = [
        'DZ' => ['Algeria', '213', true], 'AO' => ['Angola', '244', false], 'BJ' => ['Benin', '229', false], 'BW' => ['Botswana', '267', false],
        'BF' => ['Burkina Faso', '226', false], 'BI' => ['Burundi', '257', false], 'CV' => ['Cabo Verde', '238', false], 'CM' => ['Cameroon', '237', false],
        'CF' => ['Central African Republic', '236', false], 'TD' => ['Chad', '235', false], 'KM' => ['Comoros', '269', false], 'CG' => ['Congo', '242', false],
        'CD' => ['DR Congo', '243', true], 'CI' => ["Côte d'Ivoire", '225', false], 'DJ' => ['Djibouti', '253', false], 'EG' => ['Egypt', '20', true],
        'GQ' => ['Equatorial Guinea', '240', false], 'ER' => ['Eritrea', '291', false], 'SZ' => ['Eswatini', '268', false], 'ET' => ['Ethiopia', '251', true],
        'GA' => ['Gabon', '241', false], 'GM' => ['Gambia', '220', false], 'GH' => ['Ghana', '233', true], 'GN' => ['Guinea', '224', false],
        'GW' => ['Guinea-Bissau', '245', false], 'KE' => ['Kenya', '254', true], 'LS' => ['Lesotho', '266', false], 'LR' => ['Liberia', '231', true],
        'LY' => ['Libya', '218', true], 'MG' => ['Madagascar', '261', true], 'MW' => ['Malawi', '265', true], 'ML' => ['Mali', '223', false],
        'MR' => ['Mauritania', '222', false], 'MU' => ['Mauritius', '230', false], 'MA' => ['Morocco', '212', true], 'MZ' => ['Mozambique', '258', false],
        'NA' => ['Namibia', '264', true], 'NE' => ['Niger', '227', false], 'NG' => ['Nigeria', '234', true], 'RW' => ['Rwanda', '250', true],
        'ST' => ['São Tomé and Príncipe', '239', false], 'SN' => ['Senegal', '221', false], 'SC' => ['Seychelles', '248', false], 'SL' => ['Sierra Leone', '232', true],
        'SO' => ['Somalia', '252', false], 'ZA' => ['South Africa', '27', true], 'SS' => ['South Sudan', '211', true], 'SD' => ['Sudan', '249', true],
        'TZ' => ['Tanzania', '255', true], 'TG' => ['Togo', '228', false], 'TN' => ['Tunisia', '216', false], 'UG' => ['Uganda', '256', true],
        'ZM' => ['Zambia', '260', true], 'ZW' => ['Zimbabwe', '263', true],
    ];

    /** For the country list in the app. Nigeria first, then A to Z. @return array<int,array{iso:string,name:string,dial:string}> */
    public static function list(): array
    {
        $out = [];
        foreach (self::COUNTRIES as $iso => [$name, $dial]) {
            $out[] = ['iso' => $iso, 'name' => $name, 'dial' => $dial];
        }
        usort($out, fn($a, $b) => ($a['iso'] === 'NG' ? -1 : ($b['iso'] === 'NG' ? 1 : strcmp($a['name'], $b['name']))));
        return $out;
    }

    /**
     * Returns the number in international form (+233241234567) or null when it is not a valid number.
     * Typed with + or 00 in front, the country code is read from the number itself. Otherwise $country says where it is from.
     */
    public static function normalize(string $raw, string $country = 'NG'): ?string
    {
        $d = preg_replace('/[\s\-().]/', '', trim($raw));
        if ($d === null || $d === '') {
            return null;
        }
        $intl = false;
        if ($d[0] === '+') {
            $d = substr($d, 1);
            $intl = true;
        } elseif (str_starts_with($d, '00')) {
            $d = substr($d, 2);
            $intl = true;
        }
        if ($d === '' || !ctype_digit($d)) {
            return null;
        }
        $iso = isset(self::COUNTRIES[strtoupper($country)]) ? strtoupper($country) : 'NG';
        if ($intl) {
            $iso = null;
            foreach (self::COUNTRIES as $k => [, $dial]) {
                if (str_starts_with($d, $dial)) {
                    $iso = $k;
                    break;
                }
            }
            if ($iso === null) {
                return null;
            }
            $national = substr($d, strlen(self::COUNTRIES[$iso][1]));
        } else {
            $dial = self::COUNTRIES[$iso][1];
            $national = (str_starts_with($d, $dial) && strlen($d) - strlen($dial) >= 8) ? substr($d, strlen($dial)) : $d; // typed with the code but no plus
        }
        if (self::COUNTRIES[$iso][2] && $national !== '' && $national[0] === '0') {
            $national = substr($national, 1);
        }
        if ($iso === 'NG') {
            if (!preg_match('/^[789][01]\d{8}$/', $national)) {
                return null;
            }
        } elseif (!preg_match('/^\d{6,12}$/', $national)) {
            return null;
        }
        return '+' . self::COUNTRIES[$iso][1] . $national;
    }

    /** Kept for older callers: a Nigerian number. */
    public static function normalizeNg(string $raw): ?string
    {
        return self::normalize($raw, 'NG');
    }

    /** Termii expects the number without the leading plus. */
    public static function forTermii(string $e164): string
    {
        return ltrim($e164, '+');
    }
}
