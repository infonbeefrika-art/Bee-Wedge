<?php
declare(strict_types=1);

namespace Beefrika;

use Beefrika\Controllers\Input;
use PDO;
use PDOException;

/**
 * Feedback after a completed job. The employer and the worker can each leave 1 to 5 honey drops and one line, once.
 * To stop revenge ratings, what one side wrote stays hidden from the public (and from the other side) until both have
 * written, or until REVEAL_DAYS have passed.
 */
final class Feedback
{
    public const REVEAL_DAYS = 7;

    /** @return array{count:int,average:?float,items:array} Empty when the table is not created yet. */
    public static function publicFor(PDO $db, int $userId, string $about): array
    {
        $empty = ['count' => 0, 'average' => null, 'items' => []];
        $cut = Clock::dt(Clock::now() - self::REVEAL_DAYS * 86400);
        $visible = "f.to_user = ? AND f.status = 'published' AND (f.created_at <= ? OR EXISTS (SELECT 1 FROM job_feedback g WHERE g.hire_id = f.hire_id AND g.from_user = f.to_user))";
        try {
            $agg = $db->prepare("SELECT COUNT(*) AS n, AVG(f.rating) AS a FROM job_feedback f WHERE $visible");
            $agg->execute([$userId, $cut]);
            $a = $agg->fetch() ?: ['n' => 0, 'a' => null];
            $from = $about === 'worker'
                ? "COALESCE(NULLIF(ep.business_name, ''), 'An employer') AS who FROM job_feedback f LEFT JOIN employer_profiles ep ON ep.user_id = f.from_user"
                : "u.full_name AS who FROM job_feedback f JOIN users u ON u.id = f.from_user";
            $st = $db->prepare("SELECT f.rating, f.comment, f.created_at, $from WHERE $visible ORDER BY f.id DESC LIMIT 10");
            $st->execute([$userId, $cut]);
        } catch (\Throwable $e) {
            return $empty;
        }
        $n = (int)$a['n'];
        return [
            'count' => $n,
            'average' => $n >= Vouch::AVG_MIN_VOUCHES ? round((float)$a['a'], 1) : null,
            'items' => array_map(fn($r) => [
                'from' => $about === 'worker' ? (string)$r['who'] : explode(' ', trim((string)$r['who']))[0],
                'rating' => (int)$r['rating'], 'comment' => $r['comment'], 'month' => Vouch::month((string)$r['created_at']),
            ], $st->fetchAll()),
        ];
    }

    /** What this person sees on a completed job: whether they can leave feedback, what they wrote, and what the other side wrote. */
    public static function forThread(PDO $db, array $hire, int $userId, int $employerId, int $workerId): array
    {
        $other = $userId === $employerId ? $workerId : $employerId;
        $mine = null;
        $theirs = null;
        $waiting = false;
        try {
            $st = $db->prepare('SELECT from_user, rating, comment, created_at FROM job_feedback WHERE hire_id = ? AND status = ?');
            $st->execute([(int)$hire['id'], 'published']);
            foreach ($st->fetchAll() as $r) {
                $row = ['rating' => (int)$r['rating'], 'comment' => $r['comment']];
                if ((int)$r['from_user'] === $userId) {
                    $mine = $row;
                } elseif ((int)$r['from_user'] === $other) {
                    $theirs = ['row' => $row, 'at' => strtotime((string)$r['created_at'] . ' UTC') ?: 0];
                }
            }
            $ready = true;
        } catch (\Throwable $e) {
            $ready = false;
        }
        if ($theirs !== null) {
            $open = $mine !== null || $theirs['at'] <= Clock::now() - self::REVEAL_DAYS * 86400;
            $waiting = !$open;
            $theirs = $open ? $theirs['row'] : null;
        }
        return ['can' => $ready && $mine === null && $hire['status'] === 'completed', 'mine' => $mine, 'theirs' => $theirs, 'theirs_waiting' => $waiting, 'reveal_days' => self::REVEAL_DAYS];
    }

    /** Saves one person's feedback on a completed hire. */
    public static function give(PDO $db, array $req, array $hire, array $u, array $in): void
    {
        if ($hire['status'] !== 'completed') {
            throw new ApiException('You can leave feedback once the job is marked complete.', 409);
        }
        $isEmployer = (int)$u['id'] === (int)$req['employer_id'];
        $to = $isEmployer ? (int)$req['worker_id'] : (int)$req['employer_id'];
        $rating = $in['rating'] ?? null;
        if (!is_int($rating) && !(is_string($rating) && ctype_digit($rating))) {
            throw new ApiException('Choose 1 to 5 honey drops.', 422);
        }
        $rating = (int)$rating;
        if ($rating < 1 || $rating > 5) {
            throw new ApiException('Choose 1 to 5 honey drops.', 422);
        }
        $comment = Input::optionalText($in, 'comment', 160, 'Your comment');
        if ($problem = Vouch::commentProblem($comment)) {
            throw new ApiException($problem, 422);
        }
        $limit = new RateLimit($db);
        $key = 'feedback:user:' . $u['id'];
        if ($limit->tooMany($key, 20, 86400)) {
            throw new ApiException('Too many feedback messages today. Please try again tomorrow.', 429);
        }
        try {
            $db->prepare('INSERT INTO job_feedback (hire_id, from_user, to_user, rating, comment, status, created_at) VALUES (?,?,?,?,?,?,?)')
                ->execute([(int)$hire['id'], (int)$u['id'], $to, $rating, $comment, 'published', Clock::dt()]);
        } catch (PDOException $e) {
            if ((string)$e->getCode() === '23000') {
                throw new ApiException('You already left feedback for this job.', 409);
            }
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
        $limit->hit($key);
    }

    /** HTML block for public pages (worker page, employer page, passport). */
    public static function section(array $f, string $heading, string $note): string
    {
        $out = '<h2>' . PublicProfile::e($heading) . '</h2>';
        if ($f['count'] === 0) {
            return $out . '<p class="muted">No feedback yet.</p>';
        }
        $out .= '<div class="card"><div class="evhead"><b>' . (int)$f['count'] . '</b><span>' . ($f['count'] === 1 ? 'job' : 'jobs') . ' rated'
            . ($f['average'] !== null ? ' &middot; ' . PublicProfile::e(number_format($f['average'], 1)) . ' out of 5' : '') . '</span></div></div><ul class="claims">';
        foreach ($f['items'] as $i) {
            $out .= '<li class="vouch">' . VouchPage::drops($i['rating']) . '<div><b>' . PublicProfile::e($i['from'] . ($i['month'] ? ' · ' . $i['month'] : '')) . '</b></div>'
                . ($i['comment'] ? '<p class="prewrap">' . PublicProfile::e($i['comment']) . '</p>' : '') . '</li>';
        }
        return $out . '</ul><p class="hint">' . PublicProfile::e($note) . '</p>';
    }
}
