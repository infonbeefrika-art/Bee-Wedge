<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

final class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', Env::need('DB_HOST'), Env::need('DB_NAME'));
            self::$pdo = new PDO($dsn, Env::need('DB_USER'), Env::get('DB_PASS', ''), [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }
        return self::$pdo;
    }

    /** For tests. */
    public static function use(PDO $pdo): void
    {
        self::$pdo = $pdo;
    }
}
