<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * The shareable public page of a worker (opt-in). Rendered on the server so WhatsApp and other apps can read a preview.
 * Shows: name, trade, area, headline, trust labels, proof titles and photos, jobs recorded on Beefrika.
 * Never shows: phone number, email, private proof details, who the employers are beyond the business name on recorded jobs.
 * Pages ask search engines not to index them (noindex).
 */
final class PublicProfile
{
    public const WORKER_CLAIMS = ['skill', 'training', 'work_experience'];
    private const PROOF = [
        'unverified' => ['Unverified', 'Nothing has been verified yet.'],
        'identity' => ['Identity verified', 'A named source verified who this person is.'],
        'skill' => ['Skill verified', 'A named source verified a skill or training.'],
        'work' => ['Work verified', 'A named source verified work, or a job was confirmed by both sides on Beefrika.'],
    ];
    private const LEVELS = [
        'self_reported' => ['Self-reported', 'The person said this. Nobody has checked it.'],
        'evidence' => ['Evidence', 'Proof was added. Beefrika has not confirmed it.'],
        'verified' => ['Verified', 'A named source confirmed it. Not a government check.'],
    ];
    private static int $svgId = 0;

    public static function find(PDO $db, string $bfId): ?array
    {
        if (!preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $bfId)) {
            return null;
        }
        $st = $db->prepare(
            "SELECT u.id, u.beefrika_id, u.full_name, u.phone_verified_at, wp.headline, wp.availability,
                    t.name AS trade_name, a.name AS area_name
             FROM users u JOIN worker_profiles wp ON wp.user_id = u.id
             LEFT JOIN trades t ON t.id = wp.primary_trade_id LEFT JOIN lagos_areas a ON a.id = wp.area_id
             WHERE u.beefrika_id = ? AND u.role = 'worker' AND u.status = 'active' AND wp.is_public = 1"
        );
        $st->execute([$bfId]);
        $w = $st->fetch();
        if (!$w) {
            return null;
        }
        $uid = (int)$w['id'];
        $ev = $db->prepare(
            "SELECT id, label, level, source_name FROM verification_records
             WHERE user_id = ? AND level IN ('verified','evidence_submitted') AND claim_type IN ('skill','training','work_experience')
             ORDER BY (level = 'verified') DESC, id DESC"
        );
        $ev->execute([$uid]);
        $claims = [];
        foreach ($ev->fetchAll() as $r) {
            $ph = $db->prepare('SELECT id FROM evidence_files WHERE verification_id = ? ORDER BY id');
            $ph->execute([$r['id']]);
            $claims[] = ['label' => $r['label'], 'level' => Trust::apiLevel($r['level']), 'source' => $r['source_name'],
                         'photos' => array_map('intval', $ph->fetchAll(PDO::FETCH_COLUMN))];
        }
        $jobs = $db->prepare("SELECT title, employer_name, description, created_at FROM work_history WHERE user_id = ? AND source = 'beefrika_hire' ORDER BY id DESC LIMIT 10");
        $jobs->execute([$uid]);
        $counts = Trust::counts($db, $uid);
        return [
            'id' => $uid, 'beefrika_id' => $w['beefrika_id'], 'name' => $w['full_name'], 'trade' => $w['trade_name'], 'area' => $w['area_name'],
            'headline' => $w['headline'], 'traits' => WorkerTraits::get($db, $uid), 'proof' => ProofLevel::forUser($db, $uid),
            'avatar' => Avatar::urlOf($db, $uid), 'also_employer' => Modes::employerLine($db, $uid), 'availability' => $w['availability'], 'phone_checked' => (bool)$w['phone_verified_at'],
            'trust' => $counts, 'claims' => $claims, 'vouches' => Vouch::publicList($db, $uid), 'feedback' => Feedback::publicFor($db, $uid, 'worker'),
            'jobs' => array_map(fn($j) => ['title' => $j['title'], 'employer' => $j['employer_name'], 'type' => $j['description'], 'year' => (int)substr((string)$j['created_at'], 0, 4)], $jobs->fetchAll()),
        ];
    }

    /** Counts a visit per worker per day. Crawlers and link-preview bots are not counted. No visitor data is stored. */
    public static function recordView(PDO $db, int $workerId, string $userAgent): void
    {
        if ($userAgent === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|whatsapp|telegram|preview|curl|wget|python|http-client|go-http/i', $userAgent)) {
            return;
        }
        $day = gmdate('Y-m-d', Clock::now());
        $upd = $db->prepare('UPDATE page_views SET views = views + 1 WHERE day = ? AND worker_id = ?');
        $upd->execute([$day, $workerId]);
        if ($upd->rowCount() === 0) {
            try {
                $db->prepare('INSERT INTO page_views (day, worker_id, views) VALUES (?, ?, 1)')->execute([$day, $workerId]);
            } catch (\PDOException $e) { // another visitor created the row a moment ago
                $upd->execute([$day, $workerId]);
            }
        }
    }

    public static function baseUrl(): string
    {
        $url = Env::get('APP_URL');
        $url = $url === null ? null : rtrim($url, '/');
        if ($url !== null && preg_match('#^https?://[A-Za-z0-9.\-]+(:\d+)?/?$#', $url)) {
            return rtrim($url, '/');
        }
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $host = preg_match('/^[A-Za-z0-9.\-]+(:\d+)?$/', $host) ? $host : 'localhost';
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
        return ($https ? 'https://' : 'http://') . $host;
    }

    public static function e(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function describe(array $d): string
    {
        $bits = array_filter([$d['trade'], $d['area'] ? 'in ' . $d['area'] : null]);
        $line = trim(implode(' ', $bits));
        $trust = $d['trust']['verified'] > 0 ? $d['trust']['verified'] . ' verified proof' . ($d['trust']['verified'] > 1 ? 's' : '')
            : ($d['trust']['evidence'] > 0 ? 'Proof added, not yet verified' : 'Self-reported profile');
        $jobs = count($d['jobs']) > 0 ? ', ' . count($d['jobs']) . ' job' . (count($d['jobs']) > 1 ? 's' : '') . ' recorded on Beefrika' : '';
        $vc = $d['vouches']['count'] ?? 0;
        $jobs .= $vc > 0 ? ', ' . $vc . ' customer vouch' . ($vc > 1 ? 'es' : '') : '';
        return ($line !== '' ? $line . '. ' : '') . $trust . $jobs . '.';
    }

    public static function render(array $d, string $baseUrl): string
    {
        $e = [self::class, 'e'];
        $url = $baseUrl . '/p/' . $d['beefrika_id'];
        $title = $d['name'] . ($d['trade'] ? ' - ' . $d['trade'] : '') . ' | Beefrika';
        $desc = self::describe($d);
        $first = explode(' ', trim($d['name']))[0];
        $proof = self::PROOF[$d['proof']] ?? self::PROOF['unverified'];
        $hireHref = '/#/join?role=employer&next=' . rawurlencode('/w/' . $d['beefrika_id']) . '&ref=' . rawurlencode($d['beefrika_id']);
        $loginHref = '/#/login?next=' . rawurlencode('/w/' . $d['beefrika_id']);

        $claims = '';
        $self = [
            ['Name', 'Entered by the worker. Not a government identity check.', 'self_reported', []],
            ['Worker type and experience', (WorkerTraits::LABELS[$d['traits']['worker_type'] ?? ''] ?? 'Type not given') . ', ' . (WorkerTraits::LABELS[$d['traits']['experience'] ?? ''] ?? 'experience not given') . '. The worker\'s own description.', 'self_reported', []],
            ['Work area', ($d['area'] ?? 'Not given') . '. Entered by the worker.', 'self_reported', []],
        ];
        foreach ($self as [$label, $text, $level]) {
            $claims .= '<li class="claim"><div class="evhead">' . self::badge($level) . '<b>' . $e($label) . '</b></div><p class="muted">' . $e($text) . '</p></li>';
        }
        foreach ($d['claims'] as $c) {
            $text = $c['level'] === 'verified' ? 'Confirmed by ' . ($c['source'] ?: 'Beefrika team') . '.' : 'Proof was added. Beefrika has not confirmed it.';
            $photos = '';
            foreach ($c['photos'] as $pid) {
                $photos .= '<img class="proofphoto" loading="lazy" width="120" height="120" alt="Photo: ' . $e($c['label']) . '" src="/p/' . $e($d['beefrika_id']) . '/photo/' . (int)$pid . '">';
            }
            $claims .= '<li class="claim"><div class="evhead">' . self::badge($c['level']) . '<b>' . $e($c['label']) . '</b></div><p class="muted">' . $e($text) . '</p>'
                . ($photos !== '' ? '<div class="photos">' . $photos . '</div>' : '') . '</li>';
        }
        $jobs = '';
        foreach ($d['jobs'] as $j) {
            $jobs .= '<li>' . $e($j['title'] . ($j['employer'] ? ' for ' . $j['employer'] : '') . ', ' . $j['year']) . ($j['type'] === 'short_gig' ? ' (short gig)' : ($j['type'] === 'contract' ? ' (contract)' : '')) . '</li>';
        }

        $meta = '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
            . '<title>' . $e($title) . '</title><meta name="robots" content="noindex,nofollow"><meta name="description" content="' . $e($desc) . '">'
            . '<link rel="canonical" href="' . $e($url) . '"><meta property="og:type" content="profile"><meta property="og:site_name" content="Beefrika">'
            . '<meta property="og:title" content="' . $e($d['name'] . ($d['trade'] ? ', ' . $d['trade'] : '')) . '"><meta property="og:description" content="' . $e($desc) . '">'
            . '<meta property="og:url" content="' . $e($url) . '"><meta property="og:image" content="' . $e($baseUrl . '/icons/icon-512.png') . '">'
            . '<meta name="twitter:card" content="summary"><meta name="theme-color" content="#F0A500"><link rel="icon" href="/icons/logo-96.png">'
            . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"><link rel="stylesheet" href="/style.css">';

        return '<!doctype html><html lang="en"><head>' . $meta . '</head><body><main class="screen">'
            . '<div class="brandbar"><img src="/icons/logo-96.png" alt="" width="40" height="40"><b>Beefrika</b>' . Pilot::pill() . '</div>'
            . '<section class="phero"><div class="phero-cover" aria-hidden="true"></div><div class="phero-body">'
            . self::avatarHtml($d['avatar'], $d['name'], 96)
            . '<div class="phero-text"><h1>' . $e($d['name']) . '</h1>'
            . '<p class="muted">' . $e(implode(' · ', array_filter([$d['trade'], $d['area'], WorkerTraits::LABELS[$d['traits']['worker_type'] ?? ''] ?? null, WorkerTraits::LABELS[$d['traits']['experience'] ?? ''] ?? null]))) . '</p>'
            . '<div class="phero-tags">' . self::proofBadge($d['proof']) . '</div><p class="hint">' . $e($proof[1]) . '</p>'
            . ($d['headline'] ? '<p class="lead">' . $e($d['headline']) . '</p>' : '')
            . ($d['also_employer'] ? '<p class="hint">Also hires on Beefrika as ' . $e($d['also_employer']['name']) . '. <a href="' . $e($d['also_employer']['path']) . '">Check this employer</a></p>' : '')
            . '</div></div><div class="phero-stats"><div class="stat"><b>' . (int)$d['vouches']['count'] . '</b><span>Customer vouches</span></div>'
            . '<div class="stat"><b>' . ($d['vouches']['average'] !== null ? $e(number_format($d['vouches']['average'], 1)) : '–') . '</b><span>Average drops</span></div></div></section>'
            . '<a class="btn" href="' . $e($hireHref) . '">Hire ' . $e($first) . '</a>'
            . '<a class="btn ghost" href="' . $e($loginHref) . '">I already have a Beefrika account</a>'
            . '<h2>Work record</h2><ul class="claims">' . $claims . '</ul>'
            . '<h2>Jobs recorded on Beefrika</h2>'
            . ($jobs !== '' ? '<ul class="plain">' . $jobs . '</ul><p class="hint">Recorded on Beefrika means both sides confirmed the job here. It is not the same as verified.</p>' : '<p class="muted">No jobs recorded on Beefrika yet.</p>')
            . VouchPage::publicSection($d['vouches'])
            . Feedback::section($d['feedback'], 'Employer feedback', 'Employers can rate a worker once a job is complete. Feedback shows when both sides have rated, or after 7 days.')
            . '<h2>Contact</h2><p class="muted">' . ($d['phone_checked'] ? 'Phone number confirmed by SMS code. ' : '') . 'To protect everyone, all contact goes through Beefrika after you create an employer account. Phone numbers are never shown here.</p>'
            . '<p class="hint">Beefrika labels every claim as Self-reported, Evidence or Verified. Do not send money before you meet. Beefrika does not hold payments.</p>'
            . Legal::footer() . '</main></body></html>';
    }

    public static function notFound(): string
    {
        return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">'
            . '<title>Not found | Beefrika</title><link rel="stylesheet" href="/style.css"></head><body><main class="screen center"><img src="/icons/logo-96.png" width="72" height="72" alt="">'
            . '<h1>This page is not available</h1><p>The worker may have switched their public page off.</p><a class="btn" href="/">Go to Beefrika</a></main></body></html>';
    }

    /** Round photo, or the person's initials when there is no photo. */
    public static function avatarHtml(?string $url, string $name, int $size = 72): string
    {
        $px = ' width="' . $size . '" height="' . $size . '"';
        if ($url !== null && preg_match('#^/a/[a-f0-9]{24}$#', $url)) {
            return '<img class="avatar" src="' . self::e($url) . '"' . $px . ' alt="">';
        }
        $parts = preg_split('/\s+/', trim($name)) ?: [''];
        $initials = mb_strtoupper(mb_substr($parts[0], 0, 1) . (count($parts) > 1 ? mb_substr(end($parts), 0, 1) : ''));
        return '<div class="avatar ph" role="img" aria-label="' . self::e($name) . '">' . self::e($initials) . '</div>';
    }

    /** The four-step proof level: unverified, identity, skill, work. */
    public static function proofBadge(string $level): string
    {
        $level = isset(self::PROOF[$level]) ? $level : 'unverified';
        $hex = '12,1.5 21.5,6.8 21.5,17.2 12,22.5 2.5,17.2 2.5,6.8';
        $check = static fn(string $c) => '<path d="M7.5 12.4l3 3 6-6.4" fill="none" stroke="' . $c . '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>';
        $svg = match ($level) {
            'work' => '<polygon points="' . $hex . '" fill="#121212" stroke="#121212" stroke-width="1.5"/>' . $check('#F0A500'),
            'skill' => '<polygon points="' . $hex . '" fill="#F0A500" stroke="#121212" stroke-width="1.5"/>' . $check('#121212'),
            'identity' => '<defs><clipPath id="px"><rect x="0" y="12" width="24" height="12"/></clipPath></defs><polygon points="' . $hex . '" fill="#fff" stroke="#121212" stroke-width="1.5"/><polygon points="' . $hex . '" fill="#F0A500" clip-path="url(#px)"/><polygon points="' . $hex . '" fill="none" stroke="#121212" stroke-width="1.5"/>',
            default => '<polygon points="' . $hex . '" fill="#fff" stroke="#121212" stroke-width="1.5" stroke-dasharray="3 2"/>',
        };
        return '<span class="level level-proof-' . $level . '"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">' . $svg . '</svg><span>' . self::e(self::PROOF[$level][0]) . '</span></span>';
    }

    public static function badge(string $level): string
    {
        $level = isset(self::LEVELS[$level]) ? $level : 'self_reported';
        $hex = '12,1.5 21.5,6.8 21.5,17.2 12,22.5 2.5,17.2 2.5,6.8';
        if ($level === 'verified') {
            $svg = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><polygon points="' . $hex . '" fill="#F0A500" stroke="#121212" stroke-width="1.5"/><path d="M7.5 12.4l3 3 6-6.4" fill="none" stroke="#121212" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        } elseif ($level === 'evidence') {
            $id = 'hx' . (++self::$svgId);
            $svg = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><defs><clipPath id="' . $id . '"><rect x="0" y="12" width="24" height="12"/></clipPath></defs><polygon points="' . $hex . '" fill="#fff" stroke="#121212" stroke-width="1.5"/><polygon points="' . $hex . '" fill="#F0A500" clip-path="url(#' . $id . ')"/><polygon points="' . $hex . '" fill="none" stroke="#121212" stroke-width="1.5"/></svg>';
        } else {
            $svg = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><polygon points="' . $hex . '" fill="#fff" stroke="#121212" stroke-width="1.5" stroke-dasharray="3 2"/></svg>';
        }
        return '<span class="level level-' . $level . '">' . $svg . '<span>' . self::LEVELS[$level][0] . '</span></span>';
    }
}
