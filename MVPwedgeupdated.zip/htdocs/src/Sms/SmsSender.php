<?php
declare(strict_types=1);

namespace Beefrika\Sms;

interface SmsSender
{
    /** @param string $toE164 e.g. +2348012345678 */
    public function send(string $toE164, string $message): void;
}
