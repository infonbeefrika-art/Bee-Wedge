<?php
declare(strict_types=1);

namespace Beefrika\Sms;

use Beefrika\Phone;

/**
 * Sends SMS through Termii's Messaging API (POST {base}/api/sms/send).
 * Termii recommends the "dnd" channel for transactional messages such as OTPs;
 * "generic" is promotional and can fail or get the sender ID blocked.
 * Credentials come from environment variables only.
 */
final class TermiiSmsSender implements SmsSender
{
    public function __construct(
        private string $apiKey,
        private string $senderId,
        private string $baseUrl = 'https://api.ng.termii.com',
        private string $channel = 'dnd',
    ) {
    }

    public function send(string $toE164, string $message): void
    {
        $payload = json_encode([
            'api_key' => $this->apiKey,
            'to'      => Phone::forTermii($toE164),
            'from'    => $this->senderId,
            'sms'     => $message,
            'type'    => 'plain',
            'channel' => $this->channel,
        ]);

        $ch = curl_init(rtrim($this->baseUrl, '/') . '/api/sms/send');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($body === false) {
            throw new \RuntimeException('Termii request failed: ' . $err);
        }
        $json = json_decode((string)$body, true);
        $ok = $code >= 200 && $code < 300 && is_array($json)
            && (isset($json['message_id']) || stripos((string)($json['message'] ?? ''), 'success') !== false);
        if (!$ok) {
            // Never log the API key or the OTP text.
            $detail = is_array($json) ? (string)($json['message'] ?? 'unknown') : 'non-JSON response';
            throw new \RuntimeException("Termii rejected the message (HTTP $code): $detail");
        }
    }
}
