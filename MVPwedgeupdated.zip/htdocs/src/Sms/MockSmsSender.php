<?php
declare(strict_types=1);

namespace Beefrika\Sms;

use Beefrika\Clock;

/** Development only. Writes the message to a private log file instead of sending an SMS. */
final class MockSmsSender implements SmsSender
{
    public function __construct(private string $logFile)
    {
    }

    public function send(string $toE164, string $message): void
    {
        $line = Clock::dt() . " MOCK-SMS to=$toE164 :: $message\n";
        @file_put_contents($this->logFile, $line, FILE_APPEND | LOCK_EX);
    }
}
