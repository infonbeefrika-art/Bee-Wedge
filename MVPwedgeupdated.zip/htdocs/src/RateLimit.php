<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/** Simple sliding-window limiter backed by the rate_limits table. */
final class RateLimit
{
    public function __construct(private PDO $db)
    {
    }

    public function count(string $key, int $windowSeconds): int
    {
        $st = $this->db->prepare('SELECT COUNT(*) FROM rate_limits WHERE k = ? AND created_at >= ?');
        $st->execute([$key, Clock::dt(Clock::now() - $windowSeconds)]);
        return (int)$st->fetchColumn();
    }

    public function hit(string $key): void
    {
        $this->db->prepare('INSERT INTO rate_limits (k, created_at) VALUES (?, ?)')->execute([$key, Clock::dt()]);
        if (random_int(1, 100) === 1) { // occasional housekeeping
            $this->db->prepare('DELETE FROM rate_limits WHERE created_at < ?')->execute([Clock::dt(Clock::now() - 86400)]);
        }
    }

    public function tooMany(string $key, int $max, int $windowSeconds): bool
    {
        return $this->count($key, $windowSeconds) >= $max;
    }
}
