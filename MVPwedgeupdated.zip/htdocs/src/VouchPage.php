<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/** Server-rendered customer vouch page. Plain HTML form, no JavaScript, so it works on any phone and under the site's strict CSP. */
final class VouchPage
{
    private const DROP = 'M12 2.5C12 2.5 5.5 10 5.5 15a6.5 6.5 0 0 0 13 0C18.5 10 12 2.5 12 2.5z';

    public static function e(?string $s): string
    {
        return PublicProfile::e($s);
    }

    public static function drop(bool $filled, int $size = 18): string
    {
        return '<svg class="drop" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" aria-hidden="true"><path d="' . self::DROP . '" fill="'
            . ($filled ? '#F0A500' : '#fff') . '" stroke="#121212" stroke-width="1.5"/></svg>';
    }

    public static function drops(int $rating): string
    {
        $out = '';
        for ($i = 1; $i <= 5; $i++) {
            $out .= self::drop($i <= $rating);
        }
        return '<span class="drops" role="img" aria-label="' . $rating . ' out of 5 honey drops">' . $out . '</span>';
    }

    /** "Customer vouches" block for the worker's public page. */
    public static function publicSection(array $v): string
    {
        $head = '<h2>Customer vouches</h2>';
        if ($v['count'] === 0) {
            return $head . '<p class="muted">No customer vouches yet.</p>';
        }
        $summary = '<div class="card"><div class="evhead"><span class="level level-vouch">' . self::drop(true) . '<span>Customer-vouched</span></span>'
            . '<span><b>' . (int)$v['count'] . '</b> customer' . ($v['count'] === 1 ? '' : 's')
            . ($v['average'] !== null ? ' &middot; ' . self::e(number_format($v['average'], 1)) . ' out of 5' : '') . '</span></div></div>';
        $list = '';
        foreach ($v['items'] as $i) {
            $who = self::e($i['name'] . ($i['area'] ? ', ' . $i['area'] : '') . ($i['month'] ? ' · ' . $i['month'] : ''));
            $list .= '<li class="vouch">' . self::drops($i['rating']) . '<div><b>' . $who . '</b></div><div class="muted">'
                . self::e(Vouch::JOB_TYPES[$i['job_type']] ?? '') . '</div>'
                . ($i['comment'] ? '<p class="prewrap">' . self::e($i['comment']) . '</p>' : '') . '</li>';
        }
        return $head . $summary . '<ul class="claims">' . $list . '</ul>'
            . '<p class="hint">Customer vouches are what past customers told Beefrika through this worker\'s link. Beefrika has not checked them. They are not the same as Verified or Recorded on Beefrika.</p>';
    }

    private static function head(string $title): string
    {
        return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
            . '<title>' . self::e($title) . '</title><meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#F0A500">'
            . '<link rel="icon" href="/icons/logo-96.png"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"><link rel="stylesheet" href="/style.css"></head><body><main class="screen">'
            . '<div class="brandbar"><img src="/icons/logo-96.png" alt="" width="40" height="40"><b>Beefrika</b>' . Pilot::pill() . '</div>';
    }

    public static function notFound(): string
    {
        return self::head('Link not available | Beefrika') . '<h1>This link is not available</h1>'
            . '<p>The link may be old. Ask the worker to send you their new vouch link.</p><a class="btn" href="/">Go to Beefrika</a></main></body></html>';
    }

    public static function thanks(array $link): string
    {
        $first = self::e(explode(' ', (string)$link['full_name'])[0]);
        $hire = '/#/join?role=employer&ref=' . rawurlencode((string)$link['beefrika_id']);
        return self::head('Thank you | Beefrika') . '<h1>Thank you</h1>'
            . '<div class="msg ok" role="status">Your vouch for ' . $first . ' was sent.</div>'
            . '<p class="muted">It helps ' . $first . ' show other people that their work can be trusted.</p>'
            . '<h2>Need someone for a job?</h2><p>Beefrika helps you find workers with a work record. Looking is free.</p>'
            . '<a class="btn ghost" href="' . self::e($hire) . '">Find workers on Beefrika</a></main></body></html>';
    }

    /** @param array<string,mixed> $old values to keep after a mistake */
    public static function form(PDO $db, array $link, array $old, ?string $error, string $formToken): string
    {
        $first = self::e(explode(' ', (string)$link['full_name'])[0]);
        $where = self::e(implode(' · ', array_filter([$link['trade_name'], $link['area_name']])));
        $val = fn(string $k): string => self::e(is_string($old[$k] ?? null) ? $old[$k] : '');

        $drops = '';
        for ($i = 5; $i >= 1; $i--) { // reversed in the DOM, shown 1 to 5 by CSS, so a chosen drop fills the ones before it
            $label = [1 => 'Poor', 2 => 'Fair', 3 => 'Good', 4 => 'Very good', 5 => 'Excellent'][$i];
            $drops .= '<input type="radio" name="rating" id="r' . $i . '" value="' . $i . '"' . (($old['rating'] ?? '') === (string)$i ? ' checked' : '') . '>'
                . '<label for="r' . $i . '">' . self::drop(false, 40) . '<span class="sr">' . $i . ' - ' . $label . '</span></label>';
        }
        $jobs = '<option value="">Choose</option>';
        foreach (Vouch::JOB_TYPES as $k => $label) {
            $jobs .= '<option value="' . $k . '"' . (($old['job_type'] ?? '') === $k ? ' selected' : '') . '>' . self::e($label) . '</option>';
        }
        $areas = '<option value="">Choose (optional)</option>';
        foreach ($db->query('SELECT id, name FROM lagos_areas ORDER BY name')->fetchAll() as $a) {
            $areas .= '<option value="' . (int)$a['id'] . '"' . (($old['area_id'] ?? '') === (string)$a['id'] ? ' selected' : '') . '>' . self::e($a['name']) . '</option>';
        }

        $countries = '';
        foreach (Phone::list() as $c) {
            $countries .= '<option value="' . $c['iso'] . '"' . (($old['country'] ?? 'NG') === $c['iso'] ? ' selected' : '') . '>' . self::e($c['name'] . ' (+' . $c['dial'] . ')') . '</option>';
        }

        return self::head('Vouch for ' . $link['full_name'] . ' | Beefrika')
            . PublicProfile::avatarHtml(Avatar::urlOf($db, (int)$link['worker_id']), (string)$link['full_name'], 88)
            . '<h1>Vouch for ' . self::e($link['full_name']) . '</h1><p class="muted">' . $where . '</p>'
            . '<p class="lead">Did ' . $first . ' do work for you? Tell other people how it went. It takes about 10 seconds. No account needed.</p>'
            . ($error !== null ? '<div class="msg err" role="alert">' . self::e($error) . '</div>' : '')
            . '<form method="post" action="/v/' . self::e((string)$link['token']) . '" autocomplete="off">'
            . '<input type="hidden" name="ft" value="' . self::e($formToken) . '">'
            . '<div class="hp" aria-hidden="true"><label for="website">Leave this empty</label><input type="text" name="website" id="website" tabindex="-1" autocomplete="off"></div>'
            . '<div class="checkrow"><input type="checkbox" name="did_work" id="did_work" value="1"' . (($old['did_work'] ?? '') === '1' ? ' checked' : '') . ' required>'
            . '<label for="did_work">Yes, ' . $first . ' did work for me</label></div>'
            . '<fieldset class="rate"><legend>How was the work?</legend><div class="ratewrap">' . $drops . '</div>'
            . '<div class="ratecap"><span>Poor</span><span>Excellent</span></div></fieldset>'
            . '<label for="job_type">What did ' . $first . ' do for you?</label><select name="job_type" id="job_type" required>' . $jobs . '</select>'
            . '<label for="comment">One line about the work (optional)</label><input type="text" name="comment" id="comment" maxlength="160" value="' . $val('comment') . '">'
            . '<p class="hint">Please do not write phone numbers or links.</p>'
            . '<label for="name">Your first name</label><input type="text" name="name" id="name" maxlength="40" value="' . $val('name') . '" autocomplete="given-name" required>'
            . '<label for="area_id">Your area (optional)</label><select name="area_id" id="area_id">' . $areas . '</select>'
            . '<label for="country">Your country</label><select name="country" id="country">' . $countries . '</select>'
            . '<label for="phone">Your phone number</label><input type="tel" name="phone" id="phone" inputmode="tel" value="' . $val('phone') . '" autocomplete="tel" required>'
            . '<p class="hint">Only used to stop fake vouches. Nobody sees it, and Beefrika keeps it only in scrambled form.</p>'
            . '<button class="btn" type="submit">Send my vouch</button></form>'
            . '<p class="hint">Beefrika shows your first name, area, drops and comment on ' . $first . '\'s page. A vouch is your own opinion. Beefrika has not checked it.</p>'
            . Legal::footer() . '</main></body></html>';
    }
}
