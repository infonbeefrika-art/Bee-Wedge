<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * Invite codes: how the team opens sign-up without SMS. A code works for a limited number of people and expires.
 * Someone who joins with a code has NOT had their phone number confirmed, and is labelled that way everywhere.
 */
final class Invites
{
    private const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    public const BAD = 'That invite code is not valid. Check it, or ask the Beefrika team for a new one.';

    public static function newCode(): string
    {
        $out = '';
        for ($i = 0; $i < 8; $i++) {
            $out .= self::ALPHABET[random_int(0, strlen(self::ALPHABET) - 1)];
        }
        return $out;
    }

    public static function normalize(string $raw): string
    {
        return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $raw) ?? '');
    }

    public static function pretty(string $code): string
    {
        return substr($code, 0, 4) . '-' . substr($code, 4);
    }

    /** @return string[] the new codes */
    public static function create(PDO $db, int $adminId, string $role, int $maxUses, ?int $expiresDays, ?string $note, int $count): array
    {
        $expires = $expiresDays === null ? null : Clock::dt(Clock::now() + $expiresDays * 86400);
        $out = [];
        for ($i = 0; $i < $count; $i++) {
            for ($try = 0; $try < 5; $try++) {
                $code = self::newCode();
                try {
                    $db->prepare('INSERT INTO invite_codes (code, role, note, max_uses, uses, expires_at, is_active, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
                        ->execute([$code, $role, $note, $maxUses, 0, $expires, 1, $adminId, Clock::dt()]);
                    $out[] = $code;
                    break;
                } catch (\PDOException $e) {
                    if ($e->getCode() !== '23000') {
                        throw $e; // anything but a duplicate code
                    }
                }
            }
        }
        return $out;
    }

    /** Uses up one place on the code. Call inside the sign-up transaction. Returns the invite id. */
    public static function consume(PDO $db, string $raw, string $role): int
    {
        $code = self::normalize($raw);
        if (strlen($code) !== 8) {
            throw new ApiException(self::BAD, 422);
        }
        $st = $db->prepare('SELECT id, role FROM invite_codes WHERE code = ?');
        $st->execute([$code]);
        $inv = $st->fetch();
        if (!$inv || ($inv['role'] !== 'any' && $inv['role'] !== $role)) {
            throw new ApiException(self::BAD, 422);
        }
        $upd = $db->prepare(
            'UPDATE invite_codes SET uses = uses + 1 WHERE id = ? AND is_active = 1 AND uses < max_uses AND (expires_at IS NULL OR expires_at > ?)'
        );
        $upd->execute([$inv['id'], Clock::dt()]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException(self::BAD, 422);
        }
        return (int)$inv['id'];
    }

    public static function status(array $row): string
    {
        if (!(int)$row['is_active']) {
            return 'off';
        }
        if ($row['expires_at'] !== null && strtotime($row['expires_at'] . ' UTC') <= Clock::now()) {
            return 'expired';
        }
        return (int)$row['uses'] >= (int)$row['max_uses'] ? 'used_up' : 'active';
    }
}
