<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

final class Referral
{
    /** The worker whose public page brought someone in. Only workers with a public page can be credited. */
    public static function resolve(PDO $db, mixed $ref): ?int
    {
        if (!is_string($ref) || !preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $ref)) {
            return null;
        }
        $st = $db->prepare(
            "SELECT u.id FROM users u JOIN worker_profiles wp ON wp.user_id = u.id
             WHERE u.beefrika_id = ? AND u.role = 'worker' AND u.status = 'active' AND wp.is_public = 1"
        );
        $st->execute([$ref]);
        $id = $st->fetchColumn();
        return $id ? (int)$id : null;
    }
}
