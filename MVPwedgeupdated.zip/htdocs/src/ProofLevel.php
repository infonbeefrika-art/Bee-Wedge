<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * The proof level shown next to a worker: unverified, identity, skill, work. The highest one reached is shown.
 *  identity: a named source verified who the person is (needs a NIN/BVN check or the Beefrika team: not available yet)
 *  skill:    a named source verified a skill or training
 *  work:     a named source verified work experience, or a job was confirmed by both sides on Beefrika
 * Nothing here is earned by typing something in. A phone code never counts.
 */
final class ProofLevel
{
    public const LEVELS = ['unverified', 'identity', 'skill', 'work'];

    /** @param int[] $ids @return array<int,string> */
    public static function forUsers(PDO $db, array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        $out = array_fill_keys($ids, 'unverified');
        if ($ids === []) {
            return $out;
        }
        $in = implode(',', array_fill(0, count($ids), '?'));
        $rank = ['unverified' => 0, 'identity' => 1, 'skill' => 2, 'work' => 3];
        $bump = function (int $id, string $level) use (&$out, $rank): void {
            if ($rank[$level] > $rank[$out[$id]]) {
                $out[$id] = $level;
            }
        };
        $st = $db->prepare("SELECT user_id, claim_type FROM verification_records WHERE level = 'verified' AND user_id IN ($in) GROUP BY user_id, claim_type");
        $st->execute($ids);
        foreach ($st->fetchAll() as $r) {
            $level = match ($r['claim_type']) {
                'identity' => 'identity',
                'skill', 'training' => 'skill',
                'work_experience' => 'work',
                default => null,
            };
            if ($level !== null) {
                $bump((int)$r['user_id'], $level);
            }
        }
        $jobs = $db->prepare("SELECT user_id FROM work_history WHERE source = 'beefrika_hire' AND user_id IN ($in) GROUP BY user_id");
        $jobs->execute($ids);
        foreach ($jobs->fetchAll() as $r) {
            $bump((int)$r['user_id'], 'work');
        }
        return $out;
    }

    public static function forUser(PDO $db, int $userId): string
    {
        return self::forUsers($db, [$userId])[$userId] ?? 'unverified';
    }
}
