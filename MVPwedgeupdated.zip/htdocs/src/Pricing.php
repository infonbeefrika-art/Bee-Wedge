<?php
declare(strict_types=1);

namespace Beefrika;

/**
 * Prices. The worker category comes from the worker's experience, so nobody picks a "skill level" for themselves.
 *   Hiring fee (employer) = category base price x type of hire.
 *   Hiring credits (worker) = one credit is used each time the worker confirms a hire. The first one is free.
 */
final class Pricing
{
    /** experience value => [category name, base price in naira] */
    public const CATEGORIES = [
        'y0_1' => ['Beginner', 1500], 'y1_3' => ['Developing', 2500], 'y3_5' => ['Skilled', 3500], 'y5_10' => ['Experienced', 5000], 'y10_plus' => ['Expert', 7500],
    ];
    /** type of hire => multiplier. Permanent hires are ready here but not offered yet. */
    public const MULTIPLIERS = ['short_gig' => 0.5, 'contract' => 1.0, 'permanent' => 1.5];
    /** pack => [hires, price in naira] */
    public const PACKS = ['tier1' => [3, 1500], 'tier2' => [10, 4000], 'tier3' => [25, 8000], 'tier4' => [50, 12500]];
    public const OPENING_CREDITS = 1;

    /** @return array{category:string,category_label:string,base:int,multiplier:float,fee:int}|null */
    public static function quote(?string $experience, string $engagementType): ?array
    {
        if ($experience === null || !isset(self::CATEGORIES[$experience]) || !isset(self::MULTIPLIERS[$engagementType])) {
            return null;
        }
        [$label, $base] = self::CATEGORIES[$experience];
        $m = self::MULTIPLIERS[$engagementType];
        return ['category' => $experience, 'category_label' => $label, 'base' => $base, 'multiplier' => $m, 'fee' => (int)round($base * $m)];
    }

    public static function naira(int $amount): string
    {
        return '₦' . number_format($amount);
    }

    /** How many days an employer can ask for a refund after paying. */
    public static function refundDays(): int
    {
        $d = (int)(Env::get('REFUND_DAYS', '7') ?? '7');
        return max(1, min(60, $d ?: 7));
    }

    public static function paymentInstructions(): string
    {
        $t = trim((string)Env::get('PAYMENT_INSTRUCTIONS', ''));
        return $t !== '' ? mb_substr($t, 0, 600) : 'The Beefrika team will send you the payment details on WhatsApp. Always write the invoice number as your payment reference.';
    }
}
