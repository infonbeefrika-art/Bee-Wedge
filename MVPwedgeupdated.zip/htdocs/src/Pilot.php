<?php
declare(strict_types=1);

namespace Beefrika;

/**
 * Beefrika is a test pilot. This switches the "test pilot" labels on or off, and says how invoices are paid:
 *   PAYMENTS_MODE=test    (default) a pretend checkout. No real money moves. The invoice is marked paid straight away.
 *   PAYMENTS_MODE=manual  bank transfer: the Beefrika team marks the invoice paid.
 * No real payment provider is connected yet, so any other value behaves like "manual".
 */
final class Pilot
{
    public static function on(): bool
    {
        return Env::get('PILOT_MODE', '1') !== '0';
    }

    public static function paymentsMode(): string
    {
        return Env::get('PAYMENTS_MODE', 'test') === 'test' ? 'test' : 'manual';
    }

    /** Small label for the header of the public pages. */
    public static function pill(): string
    {
        return self::on() ? '<span class="testpill">Test pilot</span>' : '';
    }
}
