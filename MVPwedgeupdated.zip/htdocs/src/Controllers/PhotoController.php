<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\PublicProfile;
use Beefrika\RateLimit;
use PDO;

/**
 * Photos attached to a proof (evidence). The phone shrinks the photo first; the server checks it is a real JPEG,
 * re-encodes it when GD is available (this removes GPS and other hidden data) and stores it outside the web folders
 * under a random name. Photos are served only through this controller.
 * Who can see a worker's proof photo: the worker, the Beefrika team, signed-in employers with a complete business profile
 * (while the worker is discoverable), and anyone on the worker's public page (only if the worker made it public).
 * Employer (business) proof photos are visible only to the owner and the Beefrika team.
 */
final class PhotoController
{
    public const MAX_PER_RECORD = 3;
    public const MAX_PER_USER = 20;
    public const MAX_BYTES = 1500000;
    public const MAX_SIDE = 4000;
    private const SHRINK_TO = 1600;

    private static ?string $dirOverride = null;

    public function __construct(private PDO $db, private bool $allowNonUploads = false)
    {
    }

    public static function useStorageDir(?string $dir): void
    {
        self::$dirOverride = $dir;
    }

    public static function storageDir(): string
    {
        $d = self::$dirOverride ?? (BF_ROOT . '/storage/evidence');
        if (!is_dir($d)) {
            @mkdir($d, 0750, true);
        }
        return $d;
    }

    /** POST /me/evidence/{id}/photos (multipart field "photo") */
    public function add(int $evidenceId, array $file): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['worker', 'employer'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        $st = $this->db->prepare('SELECT id, level FROM verification_records WHERE id = ? AND user_id = ?');
        $st->execute([$evidenceId, $u['id']]);
        $rec = $st->fetch();
        if (!$rec) {
            throw new ApiException('Proof not found.', 404);
        }
        if ($rec['level'] === 'verified') {
            throw new ApiException('Verified proof cannot be changed. Add a new proof instead.', 409);
        }
        $n = $this->db->prepare('SELECT COUNT(*) FROM evidence_files WHERE verification_id = ?');
        $n->execute([$evidenceId]);
        if ((int)$n->fetchColumn() >= self::MAX_PER_RECORD) {
            throw new ApiException('You can add up to ' . self::MAX_PER_RECORD . ' photos to one proof.', 422);
        }
        $all = $this->db->prepare('SELECT COUNT(*) FROM evidence_files f JOIN verification_records v ON v.id = f.verification_id WHERE v.user_id = ?');
        $all->execute([$u['id']]);
        if ((int)$all->fetchColumn() >= self::MAX_PER_USER) {
            throw new ApiException('You have reached the photo limit. Remove an old photo first.', 422);
        }
        $limit = new RateLimit($this->db);
        $key = 'photo:user:' . $u['id'];
        if ($limit->tooMany($key, 30, 3600)) {
            throw new ApiException('You are uploading too quickly. Please try again later.', 429);
        }

        $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
            throw new ApiException('That photo is too large. Please choose a smaller one.', 413);
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        if ($err !== UPLOAD_ERR_OK || $tmp === '' || (!$this->allowNonUploads && !is_uploaded_file($tmp))) {
            throw new ApiException('The photo could not be uploaded. Please try again.', 422);
        }
        $size = (int)filesize($tmp);
        if ($size < 100 || $size > self::MAX_BYTES) {
            throw new ApiException('That photo is too large. Please choose a smaller one.', 413);
        }
        $info = @getimagesize($tmp);
        if (!$info || $info[2] !== IMAGETYPE_JPEG) {
            throw new ApiException('Only JPEG photos are accepted. Pick a photo from your gallery.', 422);
        }
        if ($info[0] > self::MAX_SIDE || $info[1] > self::MAX_SIDE || $info[0] < 1 || $info[1] < 1) {
            throw new ApiException('That photo is too large. Please choose a smaller one.', 422);
        }
        $bytes = (string)file_get_contents($tmp);
        if (function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
            $im = @imagecreatefromstring($bytes);
            if ($im === false) {
                throw new ApiException('That photo could not be read. Please try another.', 422);
            }
            $w = imagesx($im);
            $h = imagesy($im);
            if (max($w, $h) > self::SHRINK_TO && function_exists('imagescale')) {
                $scaled = imagescale($im, $w >= $h ? self::SHRINK_TO : (int)round($w * self::SHRINK_TO / $h));
                if ($scaled !== false) {
                    $im = $scaled;
                }
            }
            ob_start();
            imagejpeg($im, null, 82);
            $bytes = (string)ob_get_clean(); // fresh encode: location and camera data are gone
        }
        $name = bin2hex(random_bytes(16)) . '.jpg';
        $path = self::storageDir() . '/' . $name;
        if (file_put_contents($path, $bytes, LOCK_EX) === false) {
            throw new ApiException('We could not save the photo. Please try again.', 500);
        }
        @chmod($path, 0640);
        $this->db->prepare('INSERT INTO evidence_files (verification_id, storage_path, mime_type, size_bytes, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([$evidenceId, $name, 'image/jpeg', strlen($bytes), Clock::dt()]);
        $id = (int)$this->db->lastInsertId();
        $limit->hit($key);
        return ['photo' => ['id' => $id]];
    }

    /** DELETE /me/evidence/photos/{id} */
    public function remove(int $fileId): array
    {
        $u = (new Auth($this->db))->requireUser();
        $st = $this->db->prepare(
            'SELECT f.id, f.storage_path, v.level FROM evidence_files f JOIN verification_records v ON v.id = f.verification_id WHERE f.id = ? AND v.user_id = ?'
        );
        $st->execute([$fileId, $u['id']]);
        $f = $st->fetch();
        if (!$f) {
            throw new ApiException('Photo not found.', 404);
        }
        if ($f['level'] === 'verified') {
            throw new ApiException('Photos on verified proof stay on your record.', 409);
        }
        $this->db->prepare('DELETE FROM evidence_files WHERE id = ?')->execute([$fileId]);
        self::deleteFiles([$f['storage_path']]);
        return ['ok' => true];
    }

    /** Decides whether this signed-in person may see the photo. Returns the file name. Not-allowed looks like not-found. */
    public function authorizeView(int $fileId, array $viewer): string
    {
        $st = $this->db->prepare(
            'SELECT f.storage_path, v.user_id AS owner_id, v.claim_type, v.level, u.status, wp.is_discoverable
             FROM evidence_files f JOIN verification_records v ON v.id = f.verification_id JOIN users u ON u.id = v.user_id
             LEFT JOIN worker_profiles wp ON wp.user_id = u.id WHERE f.id = ?'
        );
        $st->execute([$fileId]);
        $f = $st->fetch();
        if (!$f) {
            throw new ApiException('Photo not found.', 404);
        }
        $ok = (int)$f['owner_id'] === (int)$viewer['id'] || $viewer['role'] === 'admin';
        if (!$ok && $viewer['role'] === 'employer' && EmployerController::isComplete($this->db, (int)$viewer['id'])) {
            $ok = in_array($f['claim_type'], PublicProfile::WORKER_CLAIMS, true) && in_array($f['level'], ['evidence_submitted', 'verified'], true)
                && (int)($f['is_discoverable'] ?? 0) === 1 && $f['status'] === 'active';
        }
        if (!$ok) {
            throw new ApiException('Photo not found.', 404);
        }
        return $f['storage_path'];
    }

    /** GET /photos/{id}: streams the image (sent with the Authorization header, so the app loads it as a blob). */
    public function stream(int $fileId): never
    {
        $u = (new Auth($this->db))->requireUser();
        self::send($this->authorizeView($fileId, $u), 'private');
    }

    /** GET /p/BF-ID/photo/{id}: a photo on a worker's PUBLIC page. */
    public static function servePublic(PDO $db, string $bfId, int $fileId): never
    {
        $st = $db->prepare(
            "SELECT f.storage_path FROM evidence_files f JOIN verification_records v ON v.id = f.verification_id
             JOIN users u ON u.id = v.user_id JOIN worker_profiles wp ON wp.user_id = u.id
             WHERE f.id = ? AND u.beefrika_id = ? AND u.role = 'worker' AND u.status = 'active' AND wp.is_public = 1
               AND v.level IN ('evidence_submitted','verified') AND v.claim_type IN ('skill','training','work_experience')"
        );
        $st->execute([$fileId, $bfId]);
        $name = $st->fetchColumn();
        if (!$name) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Not found';
            exit;
        }
        self::send((string)$name, 'public');
    }

    /** Removes photo files from disk (names only; never trusts a path). */
    public static function deleteFiles(array $names): void
    {
        foreach ($names as $n) {
            $n = basename((string)$n);
            $full = self::storageDir() . '/' . $n;
            if ($n !== '' && is_file($full)) {
                @unlink($full);
            }
        }
    }

    private static function send(string $name, string $cache): never
    {
        $full = self::storageDir() . '/' . basename($name);
        if (!is_file($full)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Not found';
            exit;
        }
        header('Content-Type: image/jpeg');
        header('Content-Length: ' . filesize($full));
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: inline');
        header('Cache-Control: ' . $cache . ', max-age=3600');
        readfile($full);
        exit;
    }
}
