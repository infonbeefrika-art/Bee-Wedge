<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\Invites;
use Beefrika\Phone;
use Beefrika\Security;
use Beefrika\Trust;
use PDO;

/** Beefrika team tools. Admin accounts are created from the command line only (bin/create-admin.php). */
final class AdminController
{
    public function __construct(private PDO $db)
    {
    }

    /** GET /admin/verifications?status=evidence_submitted|verified|rejected */
    public function queue(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $status = in_array($q['status'] ?? '', ['evidence_submitted', 'verified', 'rejected'], true) ? $q['status'] : 'evidence_submitted';
        $st = $this->db->prepare(
            'SELECT v.id, v.claim_type, v.label, v.detail, v.level, v.source, v.source_name, v.review_note, v.created_at,
                    u.beefrika_id, u.full_name, u.role
             FROM verification_records v JOIN users u ON u.id = v.user_id
             WHERE v.level = ? ORDER BY v.created_at ASC LIMIT 50'
        );
        $st->execute([$status]);
        $rows = $st->fetchAll();
        $photoStmt = $this->db->prepare('SELECT id FROM evidence_files WHERE verification_id = ? ORDER BY id');
        return ['status' => $status, 'items' => array_map(function ($r) use ($photoStmt) {
            $photoStmt->execute([$r['id']]);
            return [
            'photos' => array_map('intval', $photoStmt->fetchAll(PDO::FETCH_COLUMN)),
            'id' => (int)$r['id'], 'claim_type' => $r['claim_type'], 'label' => $r['label'], 'detail' => $r['detail'] ?? '',
            'level' => Trust::apiLevel($r['level']), 'source_name' => $r['source_name'], 'review_note' => $r['review_note'],
            'created_at' => $r['created_at'],
            'person' => ['beefrika_id' => $r['beefrika_id'], 'name' => $r['full_name'], 'role' => $r['role']],
            ];
        }, $rows)];
    }

    /** POST /admin/verifications/{id}/decide {decision: verify|reject, source: admin|partner_org, source_name?, review_note?} */
    public function decide(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $decision = Input::enum($in, 'decision', ['verify', 'reject'], 'Choose verify or reject.');
        $note = Input::optionalText($in, 'review_note', 500, 'Note');

        $st = $this->db->prepare('SELECT user_id, level FROM verification_records WHERE id = ?');
        $st->execute([$id]);
        $rec = $st->fetch();
        if (!$rec) {
            throw new ApiException('Record not found.', 404);
        }
        if ((int)$rec['user_id'] === (int)$admin['id']) {
            throw new ApiException('You cannot review your own proof.', 403);
        }
        if ($rec['level'] !== 'evidence_submitted') {
            throw new ApiException('This record was already reviewed.', 409);
        }

        if ($decision === 'verify') {
            $source = Input::enum($in, 'source', ['admin', 'partner_org', 'employer_confirmation'], 'Choose who confirmed this.');
            $sourceName = Input::optionalText($in, 'source_name', 120, 'Source name');
            if ($source !== 'admin' && ($sourceName === null || mb_strlen($sourceName) < 3)) {
                throw new ApiException('Name the organisation or employer that confirmed this.', 422);
            }
            $sourceName = $sourceName ?? 'Beefrika team';
            $upd = $this->db->prepare(
                'UPDATE verification_records SET level = ?, source = ?, source_name = ?, review_note = ?, reviewed_by = ?, reviewed_at = ?
                 WHERE id = ? AND level = ?'
            );
            $upd->execute(['verified', $source, $sourceName, $note, $admin['id'], Clock::dt(), $id, 'evidence_submitted']);
        } else {
            if ($note === null) {
                throw new ApiException('Say briefly why this was not accepted, so the person can fix it.', 422);
            }
            $upd = $this->db->prepare(
                'UPDATE verification_records SET level = ?, review_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND level = ?'
            );
            $upd->execute(['rejected', $note, $admin['id'], Clock::dt(), $id, 'evidence_submitted']);
        }
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This record was already reviewed.', 409);
        }
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$admin['id'], 'verification.' . $decision, 'verification_record', $id, Security::ipHash(Http::ip()), Clock::dt()]);
        return ['ok' => true];
    }

    // ---------------------------------------------------------------- fees ledger (tracked, not collected online)

    /** GET /admin/hires?fee_status=due|invoiced|paid|waived|not_due */
    public function hires(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $where = "h.status IN ('confirmed','completed','cancelled')";
        $params = [];
        if (in_array($q['fee_status'] ?? '', ['not_due', 'due', 'invoiced', 'paid', 'waived'], true)) {
            $where .= ' AND h.fee_status = ?';
            $params[] = $q['fee_status'];
        }
        $st = $this->db->prepare(
            "SELECT h.id, h.status, h.engagement_type, h.agreed_pay_ngn, h.fee_multiplier, h.fee_amount_ngn, h.fee_status, h.fee_note, h.created_at, h.completed_at,
                    ep.business_name, e.full_name AS employer_name, w.full_name AS worker_name, w.beefrika_id AS worker_bfid
             FROM hires h JOIN users e ON e.id = h.employer_id JOIN employer_profiles ep ON ep.user_id = e.id JOIN users w ON w.id = h.worker_id
             WHERE $where ORDER BY h.id DESC LIMIT 100"
        );
        $st->execute($params);
        return ['items' => array_map(fn($r) => [
            'id' => (int)$r['id'], 'status' => $r['status'], 'engagement_type' => $r['engagement_type'],
            'agreed_pay_ngn' => $r['agreed_pay_ngn'] === null ? null : (int)$r['agreed_pay_ngn'],
            'fee_multiplier' => $r['fee_multiplier'] === null ? null : (float)$r['fee_multiplier'],
            'fee_amount_ngn' => $r['fee_amount_ngn'] === null ? null : (int)$r['fee_amount_ngn'],
            'fee_status' => $r['fee_status'], 'fee_note' => $r['fee_note'],
            'employer' => $r['business_name'] ?: $r['employer_name'], 'worker' => $r['worker_name'], 'worker_bfid' => $r['worker_bfid'],
            'created_at' => $r['created_at'], 'completed_at' => $r['completed_at'],
        ], $st->fetchAll())];
    }

    /** POST /admin/hires/{id}/fee {fee_status, fee_amount_ngn?, fee_note?} */
    public function setFee(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $status = Input::enum($in, 'fee_status', ['not_due', 'due', 'invoiced', 'paid', 'waived'], 'Choose a fee status.');
        $note = Input::optionalText($in, 'fee_note', 255, 'Note');
        $amount = $in['fee_amount_ngn'] ?? null;
        if ($amount !== null && $amount !== '') {
            if (!is_numeric($amount) || (int)$amount < 0 || (int)$amount > 100000000) {
                throw new ApiException('Fee must be a number in naira.', 422);
            }
            $amount = (int)$amount;
        } else {
            $amount = null;
        }
        $st = $this->db->prepare('SELECT fee_amount_ngn, status FROM hires WHERE id = ?');
        $st->execute([$id]);
        $h = $st->fetch();
        if (!$h || $h['status'] === 'pending_confirmation') {
            throw new ApiException('Hire not found.', 404);
        }
        $final = $amount ?? ($h['fee_amount_ngn'] === null ? null : (int)$h['fee_amount_ngn']);
        if (in_array($status, ['due', 'invoiced', 'paid'], true) && $final === null) {
            throw new ApiException('Enter the fee amount first.', 422);
        }
        $this->db->prepare('UPDATE hires SET fee_status = ?, fee_amount_ngn = ?, fee_note = ?, updated_at = ? WHERE id = ?')
            ->execute([$status, $final, $note, Clock::dt(), $id]);
        $this->audit((int)$admin['id'], 'fee.' . $status, 'hire', $id);
        return ['ok' => true];
    }

    // ---------------------------------------------------------------- reports and safety

    /** GET /admin/reports?status=open|reviewing|resolved|dismissed */
    public function reports(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $status = in_array($q['status'] ?? '', ['open', 'reviewing', 'resolved', 'dismissed'], true) ? $q['status'] : 'open';
        $st = $this->db->prepare(
            'SELECT r.id, r.target_type, r.target_id, r.reason, r.details, r.status, r.resolution_note, r.created_at,
                    rep.full_name AS reporter_name, rep.beefrika_id AS reporter_bfid
             FROM reports r JOIN users rep ON rep.id = r.reporter_id WHERE r.status = ? ORDER BY r.created_at ASC LIMIT 50'
        );
        $st->execute([$status]);
        $items = [];
        foreach ($st->fetchAll() as $r) {
            $target = ['type' => $r['target_type']];
            if ($r['target_type'] === 'user') {
                $t = $this->db->prepare('SELECT beefrika_id, full_name, role, status FROM users WHERE id = ?');
                $t->execute([$r['target_id']]);
                $row = $t->fetch() ?: [];
                $target += ['beefrika_id' => $row['beefrika_id'] ?? '', 'name' => $row['full_name'] ?? '', 'role' => $row['role'] ?? '', 'account_status' => $row['status'] ?? ''];
            } else { // only the one reported message is shown, never the rest of the chat
                $t = $this->db->prepare(
                    'SELECT m.body, u.beefrika_id, u.full_name, u.status FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?'
                );
                $t->execute([$r['target_id']]);
                $row = $t->fetch() ?: [];
                $target += ['body' => $row['body'] ?? '', 'beefrika_id' => $row['beefrika_id'] ?? '', 'name' => $row['full_name'] ?? '', 'account_status' => $row['status'] ?? ''];
            }
            $items[] = ['id' => (int)$r['id'], 'reason' => $r['reason'], 'details' => $r['details'] ?? '', 'status' => $r['status'],
                        'resolution_note' => $r['resolution_note'], 'created_at' => $r['created_at'],
                        'reporter' => ['name' => $r['reporter_name'], 'beefrika_id' => $r['reporter_bfid']], 'target' => $target];
        }
        return ['status' => $status, 'items' => $items];
    }

    /** POST /admin/reports/{id}/resolve {status: resolved|dismissed, resolution_note} */
    public function resolveReport(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $status = Input::enum($in, 'status', ['resolved', 'dismissed'], 'Choose resolved or dismissed.');
        $note = Input::text($in, 'resolution_note', 3, 500, 'Note');
        $upd = $this->db->prepare(
            "UPDATE reports SET status = ?, resolution_note = ?, resolved_by = ?, resolved_at = ? WHERE id = ? AND status IN ('open','reviewing')"
        );
        $upd->execute([$status, $note, $admin['id'], Clock::dt(), $id]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This report was already handled or does not exist.', 409);
        }
        $this->audit((int)$admin['id'], 'report.' . $status, 'report', $id);
        return ['ok' => true];
    }

    /** POST /admin/users/{BF-ID}/status {status: active|suspended, note} */
    public function setUserStatus(string $beefrikaId, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $status = Input::enum($in, 'status', ['active', 'suspended'], 'Choose active or suspended.');
        $note = Input::text($in, 'note', 3, 300, 'Reason');
        $st = $this->db->prepare('SELECT id, role FROM users WHERE beefrika_id = ?');
        $st->execute([$beefrikaId]);
        $u = $st->fetch();
        if (!$u) {
            throw new ApiException('Person not found.', 404);
        }
        if ($u['role'] === 'admin' || (int)$u['id'] === (int)$admin['id']) {
            throw new ApiException('Admin accounts cannot be changed here.', 403);
        }
        $this->db->prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ?')->execute([$status, Clock::dt(), $u['id']]);
        if ($status === 'suspended') {
            $this->db->prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL')->execute([Clock::dt(), $u['id']]);
        }
        $this->audit((int)$admin['id'], 'user.' . $status, 'user', (int)$u['id'], ['note' => $note]);
        return ['ok' => true];
    }

    private function audit(int $actor, string $action, string $entity, int $entityId, array $meta = []): void
    {
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$actor, $action, $entity, $entityId, $meta ? json_encode($meta) : null, Security::ipHash(Http::ip()), Clock::dt()]);
    }

    // ---------------------------------------------------------------- invite codes (sign-up without SMS)

    /** POST /admin/invites {role, max_uses, expires_days, note, count} */
    public function createInvites(array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $role = Input::enum($in, 'role', ['any', 'worker', 'employer'], 'Choose who the code is for.');
        $max = $in['max_uses'] ?? 1;
        $days = $in['expires_days'] ?? 14;
        $count = $in['count'] ?? 1;
        foreach ([[$max, 1, 200, 'Uses'], [$days, 0, 90, 'Days'], [$count, 1, 20, 'Number of codes']] as [$v, $lo, $hi, $label]) {
            if (!is_numeric($v) || (int)$v < $lo || (int)$v > $hi) {
                throw new ApiException("$label must be a number from $lo to $hi.", 422);
            }
        }
        $note = Input::optionalText($in, 'note', 120, 'Note');
        $codes = Invites::create($this->db, (int)$admin['id'], $role, (int)$max, (int)$days === 0 ? null : (int)$days, $note, (int)$count);
        $this->audit((int)$admin['id'], 'invite.created', 'invite', 0, ['count' => count($codes), 'role' => $role]);
        return ['codes' => array_map([Invites::class, 'pretty'], $codes)];
    }

    /** GET /admin/invites */
    public function invites(): array
    {
        (new Auth($this->db))->requireUser('admin');
        $rows = $this->db->query('SELECT id, code, role, note, max_uses, uses, expires_at, is_active, created_at FROM invite_codes ORDER BY id DESC LIMIT 100')->fetchAll();
        return ['items' => array_map(fn($r) => [
            'id' => (int)$r['id'], 'code' => Invites::pretty($r['code']), 'role' => $r['role'], 'note' => $r['note'],
            'uses' => (int)$r['uses'], 'max_uses' => (int)$r['max_uses'], 'expires_at' => $r['expires_at'],
            'status' => Invites::status($r), 'created_at' => $r['created_at'],
        ], $rows)];
    }

    /** POST /admin/invites/{id}/deactivate */
    public function deactivateInvite(int $id): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $upd = $this->db->prepare('UPDATE invite_codes SET is_active = 0 WHERE id = ? AND is_active = 1');
        $upd->execute([$id]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('Invite code not found or already switched off.', 404);
        }
        $this->audit((int)$admin['id'], 'invite.off', 'invite', $id);
        return ['ok' => true];
    }

    // ---------------------------------------------------------------- people lookup and password help

    /** GET /admin/people?q=BF-ID | phone | name */
    public function people(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $text = trim((string)($q['q'] ?? ''));
        if (mb_strlen($text) < 2) {
            return ['items' => []];
        }
        $where = 'u.full_name LIKE ? ESCAPE \'!\'';
        $params = ['%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $text) . '%'];
        if (preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/i', $text)) {
            $where = 'u.beefrika_id = ?';
            $params = [strtoupper($text)];
        } elseif (($phone = Phone::normalize($text)) !== null) {
            $where = 'u.phone = ?';
            $params = [$phone];
        }
        $st = $this->db->prepare(
            "SELECT u.beefrika_id, u.full_name, u.role, u.status, u.phone, u.phone_verified_at, u.signup_via, u.created_at
             FROM users u WHERE $where ORDER BY u.id DESC LIMIT 10"
        );
        $st->execute($params);
        return ['items' => array_map(fn($r) => [
            'beefrika_id' => $r['beefrika_id'], 'name' => $r['full_name'], 'role' => $r['role'], 'status' => $r['status'], 'phone' => $r['phone'],
            'phone_confirmed' => $r['phone_verified_at'] !== null, 'signup_via' => $r['signup_via'], 'created_at' => $r['created_at'],
        ], $st->fetchAll())];
    }

    /** POST /admin/people/{BF-ID}/reset-password: a temporary password, shown once, for people who cannot use SMS */
    public function resetPassword(string $beefrikaId): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $st = $this->db->prepare('SELECT id, role, phone FROM users WHERE beefrika_id = ?');
        $st->execute([$beefrikaId]);
        $u = $st->fetch();
        if (!$u) {
            throw new ApiException('Person not found.', 404);
        }
        if ($u['role'] === 'admin') {
            throw new ApiException('Admin passwords cannot be reset here.', 403);
        }
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        do {
            $temp = '';
            for ($i = 0; $i < 10; $i++) {
                $temp .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
        } while (Security::passwordProblem($temp, $u['phone']) !== null);
        $this->db->prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')->execute([password_hash($temp, PASSWORD_DEFAULT), Clock::dt(), $u['id']]);
        $this->db->prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL')->execute([Clock::dt(), $u['id']]);
        \Beefrika\IdLogin::set($this->db, (int)$u['id'], false); // a temporary password is never strong enough for ID log-in
        $this->audit((int)$admin['id'], 'user.password_reset_by_admin', 'user', (int)$u['id']);
        return ['temporary_password' => $temp];
    }
}
