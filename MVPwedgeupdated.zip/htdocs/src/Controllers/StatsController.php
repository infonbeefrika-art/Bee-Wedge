<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\Auth;
use Beefrika\Clock;
use PDO;

/** Traction numbers for the Beefrika team. Counts only: no personal data leaves this endpoint except names of top referrers. */
final class StatsController
{
    public function __construct(private PDO $db)
    {
    }

    /** GET /admin/stats */
    public function summary(): array
    {
        (new Auth($this->db))->requireUser('admin');
        $one = function (string $sql, array $p = []): int {
            $st = $this->db->prepare($sql);
            $st->execute($p);
            return (int)($st->fetchColumn() ?: 0);
        };
        $roles = ['worker' => 0, 'employer' => 0];
        foreach ($this->db->query("SELECT role, COUNT(*) AS n FROM users WHERE role IN ('worker','employer') GROUP BY role")->fetchAll() as $r) {
            $roles[$r['role']] = (int)$r['n'];
        }
        $day7 = gmdate('Y-m-d', Clock::now() - 6 * 86400);

        // signups per day, last 14 days (zeros filled in)
        $from = gmdate('Y-m-d', Clock::now() - 13 * 86400);
        $st = $this->db->prepare('SELECT DATE(created_at) AS d, COUNT(*) AS n FROM users WHERE created_at >= ? GROUP BY DATE(created_at)');
        $st->execute([$from . ' 00:00:00']);
        $byDay = [];
        foreach ($st->fetchAll() as $r) {
            $byDay[$r['d']] = (int)$r['n'];
        }
        $signups = [];
        for ($i = 13; $i >= 0; $i--) {
            $d = gmdate('Y-m-d', Clock::now() - $i * 86400);
            $signups[] = ['day' => $d, 'n' => $byDay[$d] ?? 0];
        }

        $top = $this->db->query(
            'SELECT u.full_name, u.beefrika_id, COUNT(r.id) AS n FROM users r JOIN users u ON u.id = r.referrer_id
             GROUP BY u.id, u.full_name, u.beefrika_id ORDER BY n DESC LIMIT 5'
        )->fetchAll();

        return [
            'vouches' => $this->vouchStats($one),
            'people' => ['workers' => $roles['worker'], 'employers' => $roles['employer']],
            'workers' => [
                'profile_70' => $one('SELECT COUNT(*) FROM worker_profiles WHERE profile_completion >= 70'),
                'discoverable' => $one('SELECT COUNT(*) FROM worker_profiles WHERE is_discoverable = 1'),
                'public_pages' => $one('SELECT COUNT(*) FROM worker_profiles WHERE is_public = 1'),
            ],
            'proof' => [
                'pending' => $one("SELECT COUNT(*) FROM verification_records WHERE level = 'evidence_submitted'"),
                'verified' => $one("SELECT COUNT(*) FROM verification_records WHERE level = 'verified'"),
                'photos' => $one('SELECT COUNT(*) FROM evidence_files'),
            ],
            'hiring' => [
                'requests' => $one('SELECT COUNT(*) FROM hiring_requests'),
                'accepted' => $one("SELECT COUNT(*) FROM hiring_requests WHERE status IN ('accepted','hired','completed')"),
                'hires' => $one("SELECT COUNT(*) FROM hires WHERE status IN ('confirmed','completed')"),
                'completed' => $one("SELECT COUNT(*) FROM hires WHERE status = 'completed'"),
            ],
            'fees' => [
                'open_ngn' => $one("SELECT COALESCE(SUM(fee_amount_ngn), 0) FROM hires WHERE fee_status IN ('due','invoiced')"),
                'paid_ngn' => $one("SELECT COALESCE(SUM(fee_amount_ngn), 0) FROM hires WHERE fee_status = 'paid'"),
            ],
            'growth' => [
                'views_7d' => $one('SELECT COALESCE(SUM(views), 0) FROM page_views WHERE day >= ?', [$day7]),
                'views_total' => $one('SELECT COALESCE(SUM(views), 0) FROM page_views'),
                'signups_via_pages' => $one('SELECT COUNT(*) FROM users WHERE referrer_id IS NOT NULL'),
                'signups' => $signups,
                'top_referrers' => array_map(fn($r) => ['name' => $r['full_name'], 'beefrika_id' => $r['beefrika_id'], 'n' => (int)$r['n']], $top),
            ],
        ];
    }

    /** The pilot question: do workers collect vouches? Counts only. */
    private function vouchStats(callable $one): array
    {
        $rows = $this->db->query(
            "SELECT l.first_at, (SELECT MIN(v.created_at) FROM vouches v WHERE v.worker_id = l.worker_id AND v.status = 'published') AS first_vouch
             FROM (SELECT worker_id, MIN(created_at) AS first_at FROM vouch_links GROUP BY worker_id) l"
        )->fetchAll();
        $eligible = 0;
        $hit = 0;
        foreach ($rows as $r) {
            $start = strtotime($r['first_at'] . ' UTC');
            if ($start === false || $start > Clock::now() - 14 * 86400) {
                continue; // link is under 14 days old: too early to judge
            }
            $eligible++;
            $fv = $r['first_vouch'] === null ? false : strtotime($r['first_vouch'] . ' UTC');
            if ($fv !== false && $fv - $start <= 14 * 86400) {
                $hit++;
            }
        }
        return [
            'workers_with_link' => $one('SELECT COUNT(DISTINCT worker_id) FROM vouch_links'),
            'links_opened' => $one('SELECT COUNT(*) FROM vouch_links WHERE opens > 0'),
            'workers_vouched' => $one("SELECT COUNT(DISTINCT worker_id) FROM vouches WHERE status = 'published'"),
            'vouches' => $one("SELECT COUNT(*) FROM vouches WHERE status = 'published'"),
            'waiting' => $one("SELECT COUNT(*) FROM vouches WHERE status = 'held' OR (status = 'published' AND worker_flagged_at IS NOT NULL AND reviewed_at IS NULL)"),
            'cohort_eligible' => $eligible,
            'cohort_vouched_14d' => $hit,
        ];
    }
}
