<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Credits;
use Beefrika\Http;
use Beefrika\Invoices;
use Beefrika\Pricing;
use Beefrika\RateLimit;
use Beefrika\Security;
use PDO;
use PDOException;

/** Hiring credits (workers), invoices (workers and employers) and the Beefrika team's payment screen. */
final class BillingController
{
    public function __construct(private PDO $db)
    {
    }

    private function member(): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['worker', 'employer'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        return $u;
    }

    private function wrap(callable $f): mixed
    {
        try {
            return $f();
        } catch (PDOException $e) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
    }

    /** GET /me/credits (workers only) */
    public function credits(): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        return $this->wrap(function () use ($u) {
            $packs = [];
            foreach (Pricing::PACKS as $tier => [$hires, $price]) {
                $packs[] = ['tier' => $tier, 'hires' => $hires, 'price' => $price, 'per_hire' => (int)round($price / $hires)];
            }
            return ['balance' => Credits::balance($this->db, (int)$u['id']), 'packs' => $packs, 'recent' => Credits::recent($this->db, (int)$u['id']), 'opening' => Pricing::OPENING_CREDITS];
        });
    }

    /** POST /me/credits/buy {tier}: makes an invoice for the pack */
    public function buy(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        $tier = Input::enum($in, 'tier', array_keys(Pricing::PACKS), 'Choose one of the packs.');
        $limit = new RateLimit($this->db);
        $key = 'credits:buy:' . $u['id'];
        if ($limit->tooMany($key, 10, 86400)) {
            throw new ApiException('Too many invoices today. Please try again tomorrow.', 429);
        }
        $limit->hit($key);
        return $this->wrap(fn() => ['invoice_id' => Invoices::createCredits($this->db, (int)$u['id'], $tier)]);
    }

    /** GET /me/invoices */
    public function invoices(): array
    {
        $u = $this->member();
        return $this->wrap(fn() => ['items' => Invoices::listFor($this->db, (int)$u['id'])]);
    }

    /** GET /me/invoices/{id} */
    public function invoice(int $id): array
    {
        $u = $this->member();
        return $this->wrap(fn() => ['invoice' => Invoices::get($this->db, $id, (int)$u['id'])]);
    }

    /** POST /me/invoices/{id}/refund {reason} (employers, inside the refund window) */
    public function refund(int $id, array $in): array
    {
        $u = (new Auth($this->db))->requireUser('employer');
        $reason = Input::text($in, 'reason', 5, 300, 'Reason');
        $this->wrap(fn() => Invoices::requestRefund($this->db, $id, (int)$u['id'], $reason));
        return ['invoice' => Invoices::get($this->db, $id, (int)$u['id'])];
    }

    /** POST /me/invoices/{id}/pay-test {method, outcome: success|fail} (pilot checkout) */
    public function payTest(int $id, array $in): array
    {
        $u = $this->member();
        $method = Input::enum($in, 'method', ['card', 'transfer', 'ussd'], 'Choose how you want to pay.');
        $outcome = Input::enum($in, 'outcome', ['success', 'fail'], 'Choose an outcome.');
        $limit = new RateLimit($this->db);
        $key = 'paytest:user:' . $u['id'];
        if ($limit->tooMany($key, 30, 3600)) {
            throw new ApiException('Too many payment attempts. Please try again later.', 429);
        }
        $limit->hit($key);
        Invoices::payTest($this->db, $id, (int)$u['id'], $method, $outcome === 'success');
        return ['invoice' => Invoices::get($this->db, $id, (int)$u['id'])];
    }

    // ---------------------------------------------------------------- the Beefrika team

    /** POST /admin/credits/grant {beefrika_id, hires, note}: gives a worker test credits for the pilot */
    public function adminGrant(array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $bf = strtoupper(trim((string)($in['beefrika_id'] ?? '')));
        $hires = (int)($in['hires'] ?? 0);
        $note = Input::text($in, 'note', 3, 300, 'Note');
        if (!preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $bf) || $hires < 1 || $hires > 100) {
            throw new ApiException('Enter a Beefrika ID and a number of credits from 1 to 100.', 422);
        }
        $st = $this->db->prepare("SELECT id FROM users WHERE beefrika_id = ? AND role = 'worker'");
        $st->execute([$bf]);
        $uid = $st->fetchColumn();
        if (!$uid) {
            throw new ApiException('No worker has that Beefrika ID.', 404);
        }
        $this->wrap(function () use ($uid, $hires) {
            Credits::balance($this->db, (int)$uid); // makes sure the free opening credit is in first
            Credits::grant($this->db, (int)$uid, $hires, 'adjust', null);
        });
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$admin['id'], 'credits.grant', 'user', (int)$uid, json_encode(['hires' => $hires, 'note' => $note]), Security::ipHash(Http::ip()), Clock::dt()]);
        return ['ok' => true];
    }

    /** GET /admin/payments?tab=unpaid|refunds|paid */
    public function adminList(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $tab = in_array($q['tab'] ?? '', ['unpaid', 'refunds', 'paid'], true) ? $q['tab'] : 'unpaid';
        $status = ['unpaid' => 'unpaid', 'refunds' => 'refund_requested', 'paid' => 'paid'][$tab];
        return $this->wrap(function () use ($tab, $status) {
            $st = $this->db->prepare(
                'SELECT i.*, u.full_name, u.beefrika_id, u.role FROM invoices i JOIN users u ON u.id = i.payer_id WHERE i.status = ? ORDER BY i.id ' . ($tab === 'paid' ? 'DESC' : 'ASC') . ' LIMIT 50'
            );
            $st->execute([$status]);
            return ['tab' => $tab, 'items' => array_map(fn($r) => Invoices::present($r) + ['payer' => $r['full_name'], 'payer_bfid' => $r['beefrika_id']], $st->fetchAll())];
        });
    }

    /** POST /admin/payments/{id}/paid {note} */
    public function adminPaid(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $note = Input::text($in, 'note', 3, 500, 'Note (for example the transfer reference)');
        $this->wrap(fn() => Invoices::markPaid($this->db, $id, (int)$admin['id'], $note));
        $this->audit((int)$admin['id'], 'invoice.paid', $id);
        return ['ok' => true];
    }

    /** POST /admin/payments/{id}/refund {decision: approve|deny, note} */
    public function adminRefund(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $decision = Input::enum($in, 'decision', ['approve', 'deny'], 'Choose approve or deny.');
        $note = Input::text($in, 'note', 3, 500, 'Note');
        $this->wrap(fn() => Invoices::decideRefund($this->db, $id, $decision === 'approve', $note));
        $this->audit((int)$admin['id'], 'invoice.refund_' . $decision, $id);
        return ['ok' => true];
    }

    private function audit(int $actor, string $action, int $id): void
    {
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$actor, $action, 'invoice', $id, null, Security::ipHash(Http::ip()), Clock::dt()]);
    }
}
