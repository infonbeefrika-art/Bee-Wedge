<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\Env;
use PDO;

final class MetaController
{
    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        return [
            'trades' => $this->db->query(
                'SELECT t.id, t.name, c.slug AS category FROM trades t JOIN trade_categories c ON c.id = t.category_id WHERE t.is_active = 1 ORDER BY t.name'
            )->fetchAll(),
            'areas'  => $this->db->query('SELECT id, name FROM lagos_areas WHERE is_active = 1 ORDER BY name')->fetchAll(),
            'signup' => ['mode' => AuthController::signupMode(), 'sms_live' => Env::get('OTP_MODE', 'live') === 'live',
                         'whatsapp' => preg_match('#^https://wa\.me/[A-Za-z0-9/_\-]+$#', (string)Env::get('INVITE_WHATSAPP_URL', '')) ? Env::get('INVITE_WHATSAPP_URL') : 'https://wa.me/message/53K52RHSPHFWB1'],
            'pilot' => \Beefrika\Pilot::on(), 'payments_mode' => \Beefrika\Pilot::paymentsMode(),
            'countries' => \Beefrika\Phone::list(),
            'worker_types' => \Beefrika\WorkerTraits::TYPES,
            'experience'   => \Beefrika\WorkerTraits::EXPERIENCE,
            'economic_roles' => \Beefrika\WorkerTraits::ROLES,
            'employer_types' => EmployerController::TYPES,
            'engagement' => array_map(
                fn($r) => ['type' => $r['engagement_type'], 'multiplier' => (float)$r['multiplier']],
                $this->db->query('SELECT engagement_type, multiplier FROM hiring_fee_rules ORDER BY multiplier')->fetchAll()
            ),
        ];
    }
}
