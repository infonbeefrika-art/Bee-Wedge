<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\RateLimit;
use Beefrika\Security;
use Beefrika\Trust;
use PDO;

/**
 * Proof a person adds about themselves (text only in this phase). It is labelled "evidence" until
 * a named source (Beefrika team or a partner organisation) confirms it. The label is public;
 * the detail text is private to the owner and the Beefrika team.
 */
final class EvidenceController
{
    private const ALLOWED = [
        'worker'   => ['skill', 'training', 'work_experience'],
        'employer' => ['business'],
    ];
    private const MAX_ACTIVE = 10;

    public function __construct(private PDO $db)
    {
    }

    public function listMine(): array
    {
        $u = (new Auth($this->db))->requireUser();
        $st = $this->db->prepare(
            'SELECT id, claim_type, label, detail, level, source_name, review_note, created_at
             FROM verification_records WHERE user_id = ? ORDER BY id DESC'
        );
        $st->execute([$u['id']]);
        $ph = $this->db->prepare('SELECT f.id, f.verification_id FROM evidence_files f JOIN verification_records v ON v.id = f.verification_id WHERE v.user_id = ? ORDER BY f.id');
        $ph->execute([$u['id']]);
        $photos = [];
        foreach ($ph->fetchAll() as $row) {
            $photos[(int)$row['verification_id']][] = (int)$row['id'];
        }
        $items = array_map(fn($r) => [
            'id'          => (int)$r['id'],
            'claim_type'  => $r['claim_type'],
            'label'       => $r['label'],
            'detail'      => $r['detail'] ?? '',
            'level'       => Trust::apiLevel($r['level']),
            'source_name' => $r['source_name'],
            'review_note' => $r['review_note'],
            'created_at'  => $r['created_at'],
            'photos'      => $photos[(int)$r['id']] ?? [],
        ], $st->fetchAll());
        return ['items' => $items, 'allowed_types' => self::ALLOWED[$u['role']] ?? []];
    }

    /** POST /me/evidence {claim_type, label, detail} */
    public function add(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $allowed = self::ALLOWED[$u['role']] ?? [];
        $type = Input::enum($in, 'claim_type', $allowed, 'Choose what this proof is about.');
        $label = Input::text($in, 'label', 3, 80, 'Title');
        $detail = Input::multiline($in, 'detail', 500, 'Details');

        $limit = new RateLimit($this->db);
        $key = 'evidence:user:' . $u['id'];
        if ($limit->tooMany($key, 20, 3600)) {
            throw new ApiException('You are adding proof too quickly. Please try again later.', 429);
        }
        $st = $this->db->prepare('SELECT COUNT(*) FROM verification_records WHERE user_id = ? AND level <> ?');
        $st->execute([$u['id'], 'rejected']);
        if ((int)$st->fetchColumn() >= self::MAX_ACTIVE) {
            throw new ApiException('You have added the maximum number of proofs. Remove one to add another.', 422);
        }
        $limit->hit($key);

        $this->db->prepare(
            'INSERT INTO verification_records (user_id, claim_type, level, source, label, detail, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        )->execute([$u['id'], $type, 'evidence_submitted', 'self', $label, $detail === '' ? null : $detail, Clock::dt()]);
        $id = (int)$this->db->lastInsertId();
        $this->audit((int)$u['id'], 'evidence.added', $id);
        return ['id' => $id] + $this->listMine();
    }

    /** DELETE /me/evidence/{id}: only proof that has not been verified */
    public function remove(int $id): array
    {
        $u = (new Auth($this->db))->requireUser();
        $chk = $this->db->prepare('SELECT id FROM verification_records WHERE id = ? AND user_id = ? AND level IN (?, ?)');
        $chk->execute([$id, $u['id'], 'evidence_submitted', 'rejected']);
        if (!$chk->fetchColumn()) {
            throw new ApiException('This proof cannot be removed. Verified proof stays on your record.', 409);
        }
        $files = $this->db->prepare('SELECT storage_path FROM evidence_files WHERE verification_id = ?');
        $files->execute([$id]);
        $names = $files->fetchAll(PDO::FETCH_COLUMN);
        $this->db->prepare('DELETE FROM evidence_files WHERE verification_id = ?')->execute([$id]);
        $this->db->prepare('DELETE FROM verification_records WHERE id = ? AND user_id = ?')->execute([$id, $u['id']]);
        PhotoController::deleteFiles($names);
        $this->audit((int)$u['id'], 'evidence.removed', $id);
        return $this->listMine();
    }

    private function audit(int $actor, string $action, int $entityId): void
    {
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$actor, $action, 'verification_record', $entityId, Security::ipHash(Http::ip()), Clock::dt()]);
    }
}
