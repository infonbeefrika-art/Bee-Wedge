<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\FeeCalculator;
use Beefrika\RateLimit;
use Beefrika\Trust;
use PDO;

/**
 * Worker discovery for employers. Only workers who chose to be discoverable appear.
 * Phone numbers and private evidence text are never returned. Lists show a short name; the full name is on the profile.
 * Viewing is rate-limited per user to make bulk copying of the directory hard.
 */
final class WorkerSearchController
{
    private const PER_PAGE = 20;

    public function __construct(private PDO $db)
    {
    }

    public function search(array $q): array
    {
        $viewer = $this->viewer('search', 300);

        $where = ['wp.is_discoverable = 1', "u.status = 'active'", "u.role = 'worker'"];
        $params = [];
        if (isset($q['trade_id']) && ctype_digit((string)$q['trade_id'])) {
            $where[] = 'wp.primary_trade_id = ?';
            $params[] = (int)$q['trade_id'];
        }
        if (isset($q['area_id']) && ctype_digit((string)$q['area_id'])) {
            $where[] = 'wp.area_id = ?';
            $params[] = (int)$q['area_id'];
        }
        $traitsOn = \Beefrika\WorkerTraits::ready($this->db);
        if ($traitsOn && isset($q['worker_type']) && in_array($q['worker_type'], \Beefrika\WorkerTraits::TYPES, true)) {
            $where[] = 'wt.worker_type = ?';
            $params[] = $q['worker_type'];
        }
        if ($traitsOn && isset($q['experience']) && in_array($q['experience'], \Beefrika\WorkerTraits::EXPERIENCE, true)) {
            $where[] = 'wt.experience = ?';
            $params[] = $q['experience'];
        }
        if (($q['available'] ?? '') === '1') {
            $where[] = "wp.availability = 'available'";
        }
        if (($q['verified'] ?? '') === '1') {
            $where[] = "EXISTS (SELECT 1 FROM verification_records v WHERE v.user_id = u.id AND v.level = 'verified')";
        }
        $text = isset($q['q']) && is_string($q['q']) ? trim(mb_substr($q['q'], 0, 40)) : '';
        if ($text !== '') {
            $like = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $text) . '%';
            $where[] = "(u.full_name LIKE ? ESCAPE '!' OR wp.headline LIKE ? ESCAPE '!' OR t.name LIKE ? ESCAPE '!')";
            array_push($params, $like, $like, $like);
        }
        $page = (isset($q['page']) && ctype_digit((string)$q['page']) && (int)$q['page'] >= 1) ? min((int)$q['page'], 200) : 1;
        $offset = ($page - 1) * self::PER_PAGE;
        $limit = self::PER_PAGE + 1;

        $sql = "SELECT u.id AS user_id, u.beefrika_id, u.full_name, wp.headline, wp.availability,
                       t.name AS trade_name, a.name AS area_name,
                       (SELECT COUNT(*) FROM verification_records v WHERE v.user_id = u.id AND v.level = 'verified') AS verified_count,
                       (SELECT COUNT(*) FROM verification_records v WHERE v.user_id = u.id AND v.level = 'evidence_submitted') AS evidence_count,
                       (SELECT COUNT(*) FROM work_history wh WHERE wh.user_id = u.id AND wh.source = 'beefrika_hire') AS jobs_count,
                       (SELECT COUNT(*) FROM vouches vo WHERE vo.worker_id = u.id AND vo.status = 'published') AS vouch_count
                FROM worker_profiles wp
                JOIN users u ON u.id = wp.user_id
                LEFT JOIN trades t ON t.id = wp.primary_trade_id
                LEFT JOIN lagos_areas a ON a.id = wp.area_id
                " . ($traitsOn ? 'LEFT JOIN worker_traits wt ON wt.user_id = u.id' : '') . "
                WHERE " . implode(' AND ', $where) . "
                ORDER BY verified_count DESC, evidence_count DESC, wp.profile_completion DESC, u.id DESC
                LIMIT $limit OFFSET $offset"; // $limit/$offset are integers computed above
        $st = $this->db->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll();
        $hasMore = count($rows) > self::PER_PAGE;
        $rows = array_slice($rows, 0, self::PER_PAGE);
        $ids = array_map(fn($r) => (int)$r['user_id'], $rows);
        $traits = \Beefrika\WorkerTraits::many($this->db, $ids);
        $proof = \Beefrika\ProofLevel::forUsers($this->db, $ids);
        $avatars = \Beefrika\Avatar::tokens($this->db, $ids);

        return [
            'workers'  => array_map(fn($r) => [
                'beefrika_id'     => $r['beefrika_id'],
                'name'            => self::shortName($r['full_name']),
                'trade'           => $r['trade_name'],
                'area'            => $r['area_name'],
                'headline'        => $r['headline'],
                'worker_type'     => $traits[(int)$r['user_id']]['worker_type'],
                'experience'      => $traits[(int)$r['user_id']]['experience'],
                'proof_level'     => $proof[(int)$r['user_id']] ?? 'unverified',
                'avatar'          => \Beefrika\Avatar::url($avatars[(int)$r['user_id']] ?? null),
                'availability'    => $r['availability'],
                'verified_count'  => (int)$r['verified_count'],
                'evidence_count'  => (int)$r['evidence_count'],
                'jobs_count'      => (int)$r['jobs_count'],
                'vouch_count'     => (int)$r['vouch_count'],
                'headline_level'  => (int)$r['verified_count'] > 0 ? 'verified' : ((int)$r['evidence_count'] > 0 ? 'evidence' : 'self_reported'),
            ], $rows),
            'page'     => $page,
            'has_more' => $hasMore,
        ];
    }

    public function show(string $beefrikaId): array
    {
        $viewer = $this->viewer('profile', 150);
        if (!preg_match('/^BF-[A-HJKMNP-Z2-9]{6}$/', $beefrikaId)) {
            throw new ApiException('Worker not found.', 404);
        }
        $st = $this->db->prepare(
            "SELECT u.id, u.beefrika_id, u.full_name, u.phone_verified_at, u.email_verified_at,
                    wp.headline, wp.bio, wp.availability, wp.primary_trade_id, wp.is_discoverable,
                    t.name AS trade_name, a.name AS area_name
             FROM users u
             JOIN worker_profiles wp ON wp.user_id = u.id
             LEFT JOIN trades t ON t.id = wp.primary_trade_id
             LEFT JOIN lagos_areas a ON a.id = wp.area_id
             WHERE u.beefrika_id = ? AND u.role = 'worker' AND u.status = 'active'"
        );
        $st->execute([$beefrikaId]);
        $w = $st->fetch();
        if (!$w || ($viewer['role'] !== 'admin' && !(int)$w['is_discoverable'])) {
            throw new ApiException('Worker not found.', 404);
        }

        $traits = \Beefrika\WorkerTraits::get($this->db, (int)$w['id']);
        $claims = [
            ['key' => 'name', 'label' => 'Name', 'level' => 'self_reported', 'detail_code' => 'name_self'],
            ['key' => 'experience', 'label' => 'Experience', 'level' => 'self_reported', 'detail_code' => 'experience_self',
             'worker_type' => $traits['worker_type'], 'experience' => $traits['experience']],
            ['key' => 'area', 'label' => 'Work area', 'level' => 'self_reported', 'detail_code' => 'area_self', 'value' => $w['area_name']],
        ];
        $ev = $this->db->prepare(
            "SELECT id, claim_type, label, level, source_name FROM verification_records
             WHERE user_id = ? AND level IN ('verified','evidence_submitted') AND claim_type IN ('skill','training','work_experience')
             ORDER BY (level = 'verified') DESC, id DESC"
        );
        $ev->execute([$w['id']]);
        foreach ($ev->fetchAll() as $r) {
            $ph = $this->db->prepare('SELECT id FROM evidence_files WHERE verification_id = ? ORDER BY id');
            $ph->execute([$r['id']]);
            $claims[] = [
                'photos' => array_map('intval', $ph->fetchAll(PDO::FETCH_COLUMN)),
                'key' => 'ev' . $r['id'], 'label' => $r['label'], 'claim_type' => $r['claim_type'],
                'level' => Trust::apiLevel($r['level']), 'source' => $r['source_name'],
                'detail_code' => $r['level'] === 'verified' ? 'confirmed_by' : 'evidence_only',
            ];
        }
        $counts = Trust::counts($this->db, (int)$w['id']);

        return ['worker' => [
            'beefrika_id'  => $w['beefrika_id'],
            'name'         => $w['full_name'],
            'trade'        => $w['trade_name'],
            'area'         => $w['area_name'],
            'headline'     => $w['headline'],
            'about'        => $w['bio'],
            'worker_type'  => $traits['worker_type'],
            'experience'   => $traits['experience'],
            'economic_role' => $traits['economic_role'],
            'proof_level'  => \Beefrika\ProofLevel::forUser($this->db, (int)$w['id']),
            'avatar'       => \Beefrika\Avatar::urlOf($this->db, (int)$w['id']),
            'availability' => $w['availability'],
            'trust'        => $counts,
            'claims'       => $claims,
            'contact_checks' => ['phone' => (bool)$w['phone_verified_at'], 'email' => (bool)$w['email_verified_at']],
            'history'      => $this->history((int)$w['id']),
            'jobs_count'   => $this->jobsCount((int)$w['id']),
            'vouches'      => \Beefrika\Vouch::publicList($this->db, (int)$w['id']),
            'feedback'     => \Beefrika\Feedback::publicFor($this->db, (int)$w['id'], 'worker'),
            'fee_quotes'   => (new FeeCalculator($this->db))->quotesFor(
                $w['primary_trade_id'] === null ? null : (int)$w['primary_trade_id'], $traits['experience']
            ),
        ]];
    }

    private function viewer(string $kind, int $perHour): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['employer', 'admin'], true)) {
            throw new ApiException('Only employers can look for workers.', 403);
        }
        if ($u['role'] === 'employer' && !EmployerController::isComplete($this->db, (int)$u['id'])) {
            throw new ApiException('Add your business details first, so workers know who is looking.', 403, ['code' => 'business_profile_incomplete']);
        }
        $limit = new RateLimit($this->db);
        $key = "$kind:user:" . $u['id'];
        if ($limit->tooMany($key, $perHour, 3600)) {
            throw new ApiException('You are looking too fast. Please try again in a while.', 429);
        }
        $limit->hit($key);
        return $u;
    }

    private static function shortName(string $full): string
    {
        $parts = preg_split('/\s+/u', trim($full)) ?: [$full];
        if (count($parts) < 2) {
            return $parts[0];
        }
        return $parts[0] . ' ' . mb_strtoupper(mb_substr(end($parts), 0, 1)) . '.';
    }

    /** Jobs both sides confirmed on Beefrika. Shown as "recorded on Beefrika", never as "verified". */
    private function history(int $userId): array
    {
        $st = $this->db->prepare(
            "SELECT title, employer_name, description, created_at FROM work_history
             WHERE user_id = ? AND source = 'beefrika_hire' ORDER BY id DESC LIMIT 10"
        );
        $st->execute([$userId]);
        return array_map(fn($r) => [
            'title' => $r['title'], 'employer' => $r['employer_name'], 'engagement_type' => $r['description'], 'year' => (int)substr((string)$r['created_at'], 0, 4),
        ], $st->fetchAll());
    }

    private function jobsCount(int $userId): int
    {
        $st = $this->db->prepare("SELECT COUNT(*) FROM work_history WHERE user_id = ? AND source = 'beefrika_hire'");
        $st->execute([$userId]);
        return (int)$st->fetchColumn();
    }
}
