<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\RateLimit;
use Beefrika\Security;
use Beefrika\Vouch;
use PDO;

/** Worker side (link, inbox, report a vouch) and admin review of held or reported vouches. */
final class VouchController
{
    public function __construct(private PDO $db)
    {
    }

    /** GET /me/vouches */
    public function mine(): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        return $this->payload((int)$u['id']);
    }

    /** POST /me/vouches/link {rotate?: bool}. Creates the link on first use. */
    public function link(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        $rotate = ($in['rotate'] ?? false) === true;
        if ($rotate) {
            $limit = new RateLimit($this->db);
            if ($limit->tooMany('vouch:rotate:' . $u['id'], 5, 86400)) {
                throw new ApiException('You changed your link many times today. Please try again tomorrow.', 429);
            }
            $limit->hit('vouch:rotate:' . $u['id']);
        }
        Vouch::linkFor($this->db, (int)$u['id'], $rotate);
        return $this->payload((int)$u['id']);
    }

    /** POST /me/vouches/{id}/flag {reason} */
    public function flag(int $id, array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        $reason = Input::enum($in, 'reason', array_keys(Vouch::FLAG_REASONS), 'Choose a reason.');
        $limit = new RateLimit($this->db);
        if ($limit->tooMany('vouch:flag:' . $u['id'], 10, 86400)) {
            throw new ApiException('You reported many vouches today. Please try again tomorrow.', 429);
        }
        $limit->hit('vouch:flag:' . $u['id']);
        Vouch::flag($this->db, (int)$u['id'], $id, $reason);
        return ['ok' => true];
    }

    private function payload(int $workerId): array
    {
        $st = $this->db->prepare("SELECT token, opens FROM vouch_links WHERE worker_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
        $st->execute([$workerId]);
        $row = $st->fetch();
        return ['link' => $row ? ['token' => $row['token'], 'url' => Vouch::urlFor($row['token']), 'opens' => (int)$row['opens']] : null]
            + Vouch::mine($this->db, $workerId);
    }

    // ---------------------------------------------------------------- admin

    private const QUEUE_WHERE = [
        'review'   => "(v.status = 'held' OR (v.status = 'published' AND v.worker_flagged_at IS NOT NULL AND v.reviewed_at IS NULL))",
        'approved' => "(v.status = 'published' AND v.reviewed_at IS NOT NULL)",
        'removed'  => "(v.status = 'removed')",
    ];

    /** GET /admin/vouches?tab=review|approved|removed */
    public function adminQueue(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $tab = array_key_exists($q['tab'] ?? '', self::QUEUE_WHERE) ? $q['tab'] : 'review';
        $st = $this->db->query(
            'SELECT v.id, v.customer_name, v.rating, v.job_type, v.comment, v.status, v.hold_reason, v.worker_flag_reason, v.review_note, v.created_at,
                    w.full_name AS worker_name, w.beefrika_id AS worker_bfid, a.name AS area_name
             FROM vouches v JOIN users w ON w.id = v.worker_id LEFT JOIN lagos_areas a ON a.id = v.area_id
             WHERE ' . self::QUEUE_WHERE[$tab] . ' ORDER BY v.id ' . ($tab === 'review' ? 'ASC' : 'DESC') . ' LIMIT 50'
        );
        return ['tab' => $tab, 'items' => array_map(fn($r) => [
            'id' => (int)$r['id'], 'customer' => $r['customer_name'], 'area' => $r['area_name'], 'rating' => (int)$r['rating'], 'job_type' => $r['job_type'],
            'comment' => $r['comment'], 'status' => $r['status'], 'hold_reason' => $r['hold_reason'], 'worker_flag_reason' => $r['worker_flag_reason'],
            'review_note' => $r['review_note'], 'created_at' => $r['created_at'],
            'worker' => ['name' => $r['worker_name'], 'beefrika_id' => $r['worker_bfid']],
        ], $st->fetchAll())];
    }

    /** POST /admin/vouches/{id}/decide {decision: approve|remove, note} */
    public function adminDecide(int $id, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $decision = Input::enum($in, 'decision', ['approve', 'remove'], 'Choose approve or remove.');
        $note = Input::text($in, 'note', 3, 500, 'Note');
        // the queue condition uses the alias "v" for SELECT; UPDATE has no alias, so drop it
        $sql = 'UPDATE vouches SET status = ?, reviewed_by = ?, reviewed_at = ?, review_note = ? WHERE id = ? AND '
            . preg_replace('/\bv\./', '', self::QUEUE_WHERE['review']);
        $upd = $this->db->prepare($sql);
        $upd->execute([$decision === 'approve' ? 'published' : 'removed', $admin['id'], Clock::dt(), $note, $id]);
        if ($upd->rowCount() !== 1) {
            throw new ApiException('This vouch was already handled or does not exist.', 409);
        }
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$admin['id'], 'vouch.' . $decision, 'vouch', $id, null, Security::ipHash(Http::ip()), Clock::dt()]);
        return ['ok' => true];
    }
}
