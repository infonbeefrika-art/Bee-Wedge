<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Avatar;
use Beefrika\Clock;
use Beefrika\RateLimit;
use PDO;
use PDOException;

/**
 * Profile photo (workers and employers). The phone crops and shrinks it first. The server checks it is a real JPEG,
 * re-encodes it as a 512 pixel square when GD is available (this removes GPS and camera data) and stores it under a random name.
 */
final class AvatarController
{
    public const MAX_BYTES = 800000;
    public const MAX_SIDE = 4000;
    public const SIZE = 512;

    public function __construct(private PDO $db, private bool $allowNonUploads = false)
    {
    }

    /** POST /me/avatar (multipart field "photo") */
    public function upload(array $file): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['worker', 'employer'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        $limit = new RateLimit($this->db);
        $key = 'avatar:user:' . $u['id'];
        if ($limit->tooMany($key, 10, 3600)) {
            throw new ApiException('You are changing your photo too quickly. Please try again later.', 429);
        }
        $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
            throw new ApiException('That photo is too large. Please choose a smaller one.', 413);
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        if ($err !== UPLOAD_ERR_OK || $tmp === '' || (!$this->allowNonUploads && !is_uploaded_file($tmp))) {
            throw new ApiException('The photo could not be uploaded. Please try again.', 422);
        }
        $size = (int)filesize($tmp);
        if ($size < 100 || $size > self::MAX_BYTES) {
            throw new ApiException('That photo is too large. Please choose a smaller one.', 413);
        }
        $info = @getimagesize($tmp);
        if (!$info || $info[2] !== IMAGETYPE_JPEG || $info[0] > self::MAX_SIDE || $info[1] > self::MAX_SIDE || $info[0] < 1 || $info[1] < 1) {
            throw new ApiException('Only JPEG photos are accepted. Pick a photo from your gallery.', 422);
        }
        $bytes = (string)file_get_contents($tmp);
        if (function_exists('imagecreatefromstring') && function_exists('imagecreatetruecolor') && function_exists('imagejpeg')) {
            $src = @imagecreatefromstring($bytes);
            if ($src === false) {
                throw new ApiException('That photo could not be read. Please try another.', 422);
            }
            $w = imagesx($src);
            $h = imagesy($src);
            $side = min($w, $h);
            $dst = imagecreatetruecolor(self::SIZE, self::SIZE);
            imagefill($dst, 0, 0, (int)imagecolorallocate($dst, 255, 255, 255));
            imagecopyresampled($dst, $src, 0, 0, intdiv($w - $side, 2), intdiv($h - $side, 2), self::SIZE, self::SIZE, $side, $side);
            ob_start();
            imagejpeg($dst, null, 85);
            $bytes = (string)ob_get_clean(); // fresh encode: location and camera data are gone
        }
        $name = bin2hex(random_bytes(16)) . '.jpg';
        $token = bin2hex(random_bytes(12));
        $path = Avatar::dir() . '/' . $name;
        if (file_put_contents($path, $bytes, LOCK_EX) === false) {
            throw new ApiException('We could not save the photo. Please try again.', 500);
        }
        @chmod($path, 0640);
        try {
            $old = $this->db->prepare('SELECT file FROM user_avatars WHERE user_id = ?');
            $old->execute([$u['id']]);
            $oldFile = $old->fetchColumn();
            if ($oldFile !== false) {
                $this->db->prepare('UPDATE user_avatars SET token = ?, file = ?, created_at = ? WHERE user_id = ?')->execute([$token, $name, Clock::dt(), $u['id']]);
                @unlink(Avatar::dir() . '/' . basename((string)$oldFile));
            } else {
                $this->db->prepare('INSERT INTO user_avatars (user_id, token, file, created_at) VALUES (?, ?, ?, ?)')->execute([$u['id'], $token, $name, Clock::dt()]);
            }
        } catch (PDOException $e) {
            @unlink($path);
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
        $limit->hit($key);
        return ['avatar' => '/a/' . $token];
    }

    /** DELETE /me/avatar */
    public function remove(): array
    {
        $u = (new Auth($this->db))->requireUser();
        try {
            $st = $this->db->prepare('SELECT file FROM user_avatars WHERE user_id = ?');
            $st->execute([$u['id']]);
            $file = $st->fetchColumn();
            if ($file !== false) {
                $this->db->prepare('DELETE FROM user_avatars WHERE user_id = ?')->execute([$u['id']]);
                @unlink(Avatar::dir() . '/' . basename((string)$file));
            }
        } catch (PDOException $e) {
            // nothing stored yet
        }
        return ['avatar' => null];
    }
}
