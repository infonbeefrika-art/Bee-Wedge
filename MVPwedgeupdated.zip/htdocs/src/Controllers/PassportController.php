<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Passport;
use PDO;
use PDOException;

final class PassportController
{
    public function __construct(private PDO $db)
    {
    }

    /** GET /me/passports */
    public function mine(): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        try {
            return Passport::listFor($this->db, (int)$u['id']);
        } catch (PDOException $e) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
    }

    /** POST /me/passports {label, days, jobs, vouches, feedback} */
    public function create(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        try {
            Passport::create($this->db, (int)$u['id'], $in);
        } catch (PDOException $e) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
        return Passport::listFor($this->db, (int)$u['id']);
    }

    /** POST /me/passports/{id}/revoke */
    public function revoke(int $id): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        Passport::revoke($this->db, (int)$u['id'], $id);
        return Passport::listFor($this->db, (int)$u['id']);
    }
}
