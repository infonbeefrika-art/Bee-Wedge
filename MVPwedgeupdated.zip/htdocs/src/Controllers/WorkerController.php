<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\FeeCalculator;
use Beefrika\Avatar;
use Beefrika\ProofLevel;
use Beefrika\Trust;
use Beefrika\WorkerTraits;
use PDO;

final class WorkerController
{
    public const AVAILABILITY = ['available', 'busy', 'not_looking'];

    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        return $this->payload($u);
    }

    /** PUT /worker/profile */
    public function update(array $in): array
    {
        $u = (new Auth($this->db))->requireUser('worker');
        if (!WorkerTraits::ready($this->db)) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }

        $headline = Input::text($in, 'headline', 0, 100, 'Headline');
        $bio = Input::multiline($in, 'bio', 600, 'About you');
        $availability = $in['availability'] ?? 'available';
        if (!in_array($availability, self::AVAILABILITY, true)) {
            throw new ApiException('Choose a valid availability.', 422);
        }
        $type = Input::enum($in, 'worker_type', WorkerTraits::TYPES, 'Choose your worker type.', false);
        $experience = Input::enum($in, 'experience', WorkerTraits::EXPERIENCE, 'Choose how many years you have worked.', false);
        $economicRole = Input::enum($in, 'economic_role', WorkerTraits::ROLES, 'Choose your economic role.', false);
        $tradeId = $this->existingId('trades', $in['primary_trade_id'] ?? null, 'trade');
        $areaId = $this->existingId('lagos_areas', $in['area_id'] ?? null, 'area');

        $wantsDiscoverable = !empty($in['is_discoverable']);
        $wantsPublic = !empty($in['is_public']);
        if (($wantsDiscoverable || $wantsPublic) && ($tradeId === null || $areaId === null || $headline === '' || $type === null || $experience === null)) {
            throw new ApiException('Add your trade, area, worker type, experience and a short headline before employers can find you or you can share your page.', 422);
        }

        $this->db->prepare(
            'UPDATE worker_profiles SET headline = ?, bio = ?, primary_trade_id = ?, area_id = ?, availability = ?, is_discoverable = ?, is_public = ?, updated_at = ? WHERE user_id = ?'
        )->execute([$headline, $bio, $tradeId, $areaId, $availability, $wantsDiscoverable ? 1 : 0, $wantsPublic ? 1 : 0, Clock::dt(), $u['id']]);
        WorkerTraits::save($this->db, (int)$u['id'], $type, $experience, $economicRole);

        return $this->payload($u);
    }

    private function payload(array $u): array
    {
        $st = $this->db->prepare('SELECT * FROM worker_profiles WHERE user_id = ?');
        $st->execute([$u['id']]);
        $p = $st->fetch() ?: [];

        $counts = Trust::counts($this->db, (int)$u['id']);
        $traits = WorkerTraits::get($this->db, (int)$u['id']);
        $checklist = [
            ...(AuthController::signupMode() === 'open' ? [] : [['key' => 'phone', 'done' => (bool)$u['phone_verified_at']]]), // no SMS in the open pilot
            ['key' => 'trade',    'done' => !empty($p['primary_trade_id'])],
            ['key' => 'area',     'done' => !empty($p['area_id'])],
            ['key' => 'type',     'done' => !empty($traits['worker_type'])],
            ['key' => 'experience', 'done' => !empty($traits['experience'])],
            ['key' => 'headline', 'done' => !empty($p['headline'])],
            ['key' => 'bio',      'done' => !empty($p['bio'])],
            ['key' => 'evidence', 'done' => $counts['evidence'] + $counts['verified'] > 0],
        ];
        $done = count(array_filter($checklist, fn($c) => $c['done']));
        $completion = (int)round($done / count($checklist) * 100);
        $this->db->prepare('UPDATE worker_profiles SET profile_completion = ? WHERE user_id = ?')->execute([$completion, $u['id']]);


        return ['profile' => [
            'headline'         => $p['headline'] ?? '',
            'bio'              => $p['bio'] ?? '',
            'primary_trade_id' => isset($p['primary_trade_id']) ? (int)$p['primary_trade_id'] : null,
            'area_id'          => isset($p['area_id']) ? (int)$p['area_id'] : null,
            'worker_type'      => $traits['worker_type'],
            'experience'       => $traits['experience'],
            'economic_role'    => $traits['economic_role'],
            'proof_level'      => ProofLevel::forUser($this->db, (int)$u['id']),
            'availability'     => $p['availability'] ?? 'available',
            'is_discoverable'  => !empty($p['is_discoverable']),
            'is_public'        => !empty($p['is_public']),
            'beefrika_id'      => $u['beefrika_id'],
            'completion'       => $completion,
            'checklist'        => $checklist,
            'trust'            => $counts,
        ]];
    }

    private function existingId(string $table, mixed $value, string $label): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            throw new ApiException("Choose a valid $label.", 422);
        }
        // $table is one of two fixed names above, never user input.
        $st = $this->db->prepare("SELECT id FROM $table WHERE id = ? AND is_active = 1");
        $st->execute([(int)$value]);
        if (!$st->fetchColumn()) {
            throw new ApiException("Choose a valid $label.", 422);
        }
        return (int)$value;
    }
}
