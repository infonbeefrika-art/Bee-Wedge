<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\RateLimit;
use PDO;

/** "Report a problem": a person or a message. The Beefrika team reviews; nobody is judged automatically from one report. */
final class ReportController
{
    public const REASONS = ['scam', 'harassment', 'fake_profile', 'unsafe', 'other'];

    public function __construct(private PDO $db)
    {
    }

    /** POST /reports {target_type: user|message, target_id: BF-ID or message id, reason, details?} */
    public function create(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $type = Input::enum($in, 'target_type', ['user', 'message'], 'Choose what you are reporting.');
        $reason = Input::enum($in, 'reason', self::REASONS, 'Choose a reason.');
        $details = Input::optionalText($in, 'details', 500, 'Details');
        $raw = $in['target_id'] ?? '';

        if ($type === 'user') {
            $st = $this->db->prepare('SELECT id FROM users WHERE beefrika_id = ?');
            $st->execute([(string)$raw]);
            $target = $st->fetchColumn();
            if (!$target) {
                throw new ApiException('Person not found.', 404);
            }
            if ((int)$target === (int)$u['id']) {
                throw new ApiException('You cannot report yourself.', 422);
            }
            $target = (int)$target;
        } else {
            if (!ctype_digit((string)$raw)) {
                throw new ApiException('Message not found.', 404);
            }
            $st = $this->db->prepare(
                "SELECT m.id FROM messages m JOIN hiring_requests r ON r.id = m.request_id
                 WHERE m.id = ? AND m.kind = 'text' AND m.sender_id <> ? AND (r.employer_id = ? OR r.worker_id = ?)"
            );
            $st->execute([(int)$raw, $u['id'], $u['id'], $u['id']]);
            $target = $st->fetchColumn();
            if (!$target) {
                throw new ApiException('Message not found.', 404);
            }
            $target = (int)$target;
        }

        $dup = $this->db->prepare("SELECT 1 FROM reports WHERE reporter_id = ? AND target_type = ? AND target_id = ? AND status IN ('open','reviewing')");
        $dup->execute([$u['id'], $type, $target]);
        if ($dup->fetchColumn()) {
            throw new ApiException('You already reported this. The Beefrika team will look at it.', 409);
        }
        $limit = new RateLimit($this->db);
        $key = 'report:user:' . $u['id'];
        if ($limit->tooMany($key, 10, 86400)) {
            throw new ApiException('You have sent many reports today. Please try again tomorrow.', 429);
        }
        $limit->hit($key);
        $this->db->prepare('INSERT INTO reports (reporter_id, target_type, target_id, reason, details, status, created_at) VALUES (?,?,?,?,?,?,?)')
            ->execute([$u['id'], $type, $target, $reason, $details, 'open', Clock::dt()]);
        return ['ok' => true];
    }
}
