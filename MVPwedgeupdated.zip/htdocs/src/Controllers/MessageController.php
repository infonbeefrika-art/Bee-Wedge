<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\RateLimit;
use PDO;

/**
 * Text messages inside a hiring request. There is no open inbox: a worker can only be messaged through a request.
 * Messages are plain text and are never turned into links. "Seen" is recorded when the other person opens the thread.
 */
final class MessageController
{
    private const MAX_UNANSWERED = 3; // employer messages in a row before the worker replies

    public function __construct(private PDO $db)
    {
    }

    /** GET /requests/{id}/messages?after=ID  (also marks the other person's messages as seen) */
    public function list(int $id, array $q): array
    {
        $u = $this->user();
        $req = HiringController::loadFor($this->db, $id, $u);
        $after = (isset($q['after']) && ctype_digit((string)$q['after'])) ? (int)$q['after'] : 0;

        $this->db->prepare(
            "UPDATE messages SET read_at = ? WHERE request_id = ? AND kind = 'text' AND sender_id <> ? AND read_at IS NULL"
        )->execute([Clock::dt(), $id, $u['id']]);

        $st = $this->db->prepare('SELECT id, sender_id, kind, body, created_at FROM messages WHERE request_id = ? AND id > ? ORDER BY id ASC LIMIT 200');
        $st->execute([$id, $after]);
        $messages = array_map(fn($m) => [
            'id'         => (int)$m['id'],
            'kind'       => $m['kind'],
            'mine'       => (int)$m['sender_id'] === (int)$u['id'],
            'body'       => $m['body'],
            'created_at' => $m['created_at'],
        ], $st->fetchAll());

        $seen = $this->db->prepare("SELECT MAX(id) FROM messages WHERE request_id = ? AND kind = 'text' AND sender_id = ? AND read_at IS NOT NULL");
        $seen->execute([$id, $u['id']]);
        $hire = HiringController::hireOf($this->db, $id);

        return [
            'messages'    => $messages,
            'seen_up_to'  => (int)($seen->fetchColumn() ?: 0),
            'status'      => $req['status'],
            'hire_status' => $hire['status'] ?? null,
            'can_message' => in_array($req['status'], HiringController::OPEN, true),
        ];
    }

    /** POST /requests/{id}/messages {body} */
    public function send(int $id, array $in): array
    {
        $u = $this->user();
        $req = HiringController::loadFor($this->db, $id, $u);
        if (!in_array($req['status'], HiringController::OPEN, true)) {
            throw new ApiException('This conversation is closed.', 409);
        }
        $body = Input::multiline($in, 'body', 1000, 'Message');
        if ($body === '') {
            throw new ApiException('Write a message first.', 422);
        }
        $role = HiringController::roleIn($req, $u);
        if ($role === 'employer' && $req['status'] === 'sent') {
            $last = $this->db->prepare("SELECT MAX(id) FROM messages WHERE request_id = ? AND kind = 'text' AND sender_id = ?");
            $last->execute([$id, $req['worker_id']]);
            $lastWorker = (int)($last->fetchColumn() ?: 0);
            $cnt = $this->db->prepare("SELECT COUNT(*) FROM messages WHERE request_id = ? AND kind = 'text' AND sender_id = ? AND id > ?");
            $cnt->execute([$id, $u['id'], $lastWorker]);
            if ((int)$cnt->fetchColumn() >= self::MAX_UNANSWERED) {
                throw new ApiException('Please wait for the worker to reply before sending more.', 429);
            }
        }
        $limit = new RateLimit($this->db);
        $key = 'message:user:' . $u['id'];
        if ($limit->tooMany($key, 60, 3600)) {
            throw new ApiException('You are sending messages too fast. Please slow down.', 429);
        }
        $limit->hit($key);
        $now = Clock::dt();
        $this->db->prepare('INSERT INTO messages (request_id, sender_id, kind, body, created_at) VALUES (?,?,?,?,?)')->execute([$id, $u['id'], 'text', $body, $now]);
        $mid = (int)$this->db->lastInsertId();
        $this->db->prepare('UPDATE hiring_requests SET updated_at = ? WHERE id = ?')->execute([$now, $id]);
        return ['message' => ['id' => $mid, 'kind' => 'text', 'mine' => true, 'body' => $body, 'created_at' => $now]];
    }

    private function user(): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['employer', 'worker'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        return $u;
    }
}
