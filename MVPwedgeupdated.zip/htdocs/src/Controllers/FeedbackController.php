<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Feedback;
use PDO;

final class FeedbackController
{
    public function __construct(private PDO $db)
    {
    }

    /** POST /requests/{id}/feedback {rating, comment?} */
    public function give(int $requestId, array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (!in_array($u['role'], ['worker', 'employer'], true)) {
            throw new ApiException('You do not have access to this.', 403);
        }
        $req = HiringController::loadFor($this->db, $requestId, $u); // 404 unless this person is part of the request
        $hire = HiringController::hireOf($this->db, $requestId);
        if (!$hire) {
            throw new ApiException('There is no job to rate yet.', 409);
        }
        Feedback::give($this->db, $req, $hire, $u, $in);
        return ['ok' => true];
    }
}
