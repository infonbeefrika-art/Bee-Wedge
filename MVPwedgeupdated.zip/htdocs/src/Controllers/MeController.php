<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Avatar;
use Beefrika\IdLogin;
use Beefrika\Auth;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\RateLimit;
use Beefrika\Security;
use Beefrika\Messaging;
use Beefrika\Otp;
use Beefrika\Trust;
use PDO;
use PDOException;

final class MeController
{
    public function __construct(private PDO $db)
    {
    }

    public function show(): array
    {
        $u = (new Auth($this->db))->requireUser();
        $profile = null;
        if ($u['role'] === 'worker') {
            $st = $this->db->prepare('SELECT * FROM worker_profiles WHERE user_id = ?');
            $st->execute([$u['id']]);
            $profile = $st->fetch() ?: null;
        }
        return ['user' => [
            'beefrika_id' => $u['beefrika_id'],
            'role'        => $u['role'],
            'home_role'   => $u['home_role'] ?? $u['role'],
            'dual'        => !empty($u['dual']),
            'full_name'   => $u['full_name'],
            'phone'       => $this->maskPhone($u['phone']),
            'email'       => $u['email'],
            'trust'       => Trust::forUser($u, $profile),
            'avatar'      => Avatar::urlOf($this->db, (int)$u['id']),
            'id_login'    => IdLogin::enabled($this->db, (int)$u['id']),
        ]];
    }

    /** POST /me/email/request {email} */
    public function requestEmailCode(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $email = Input::email($in);
        $this->assertEmailFree($email, (int)$u['id']);
        $sender = Messaging::email();
        $otp = new Otp($this->db);
        $otp->issue('email', $email, 'verify_email', Http::ip(), function (string $code) use ($sender, $email, $otp): void {
            $minutes = intdiv($otp->ttl(), 60);
            $sender->send($email, 'Your Beefrika verification code', "Your Beefrika code is $code. It expires in $minutes minutes. If you did not ask for this, ignore this email.");
        });
        return ['sent' => true, 'expires_in' => $otp->ttl(), 'resend_after' => $otp->cooldown()];
    }

    /** POST /me/email/verify {email, code} */
    public function verifyEmail(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $email = Input::email($in);
        $this->assertEmailFree($email, (int)$u['id']);
        (new Otp($this->db))->verify('email', $email, 'verify_email', (string)($in['code'] ?? ''));
        try {
            $this->db->prepare('UPDATE users SET email = ?, email_verified_at = ?, updated_at = ? WHERE id = ?')
                ->execute([$email, Clock::dt(), Clock::dt(), $u['id']]);
        } catch (PDOException $e) {
            throw new ApiException('This email is already used by another account.', 409);
        }
        return ['ok' => true];
    }

    private function assertEmailFree(string $email, int $userId): void
    {
        $st = $this->db->prepare('SELECT 1 FROM users WHERE email = ? AND id <> ?');
        $st->execute([$email, $userId]);
        if ($st->fetchColumn()) {
            throw new ApiException('This email is already used by another account.', 409);
        }
    }

    private function maskPhone(string $e164): string
    {
        return substr($e164, 0, 7) . '***' . substr($e164, -2);
    }

    /** POST /me/password {current, password}: signs out every other device */
    public function changePassword(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        $limit = new RateLimit($this->db);
        $key = 'pwchange:user:' . $u['id'];
        if ($limit->tooMany($key, 10, 900)) {
            throw new ApiException('Too many attempts. Please wait 15 minutes.', 429);
        }
        $limit->hit($key);
        if (!password_verify((string)($in['current'] ?? ''), $u['password_hash'])) {
            throw new ApiException('Your current password is not right.', 422);
        }
        $new = (string)($in['password'] ?? '');
        $problem = IdLogin::enabled($this->db, (int)$u['id'])
            ? Security::veryStrongPasswordProblem($new, $u['phone'], $u['beefrika_id'], $u['full_name'])
            : Security::passwordProblem($new, $u['phone']);
        if ($problem) {
            throw new ApiException($problem, 422);
        }
        $this->db->prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), Clock::dt(), $u['id']]);
        $token = Http::bearerToken();
        $this->db->prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL AND token_hash <> ?')
            ->execute([Clock::dt(), $u['id'], $token === null ? '' : Security::hashToken($token)]);
        return ['ok' => true];
    }

    /** POST /me/id-login {enable: bool, password}. Turning it on needs the current password and a very strong one. */
    public function setIdLogin(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (($in['enable'] ?? false) !== true) {
            IdLogin::set($this->db, (int)$u['id'], false);
            return ['id_login' => false];
        }
        $limit = new RateLimit($this->db);
        $key = 'idlogin:user:' . $u['id'];
        if ($limit->tooMany($key, 5, 900)) {
            throw new ApiException('Too many attempts. Please wait 15 minutes.', 429);
        }
        $limit->hit($key);
        $password = (string)($in['password'] ?? '');
        if (!password_verify($password, $u['password_hash'])) {
            throw new ApiException('Your password is not right.', 422);
        }
        if ($problem = Security::veryStrongPasswordProblem($password, $u['phone'], $u['beefrika_id'], $u['full_name'])) {
            throw new ApiException($problem . ' Change your password first, then switch this on.', 422);
        }
        IdLogin::set($this->db, (int)$u['id'], true);
        return ['id_login' => true];
    }

    /** POST /me/mode {mode: worker|employer, confirm: true}. A worker may also hire as an employer; the ID stays the same. */
    public function setMode(array $in): array
    {
        $u = (new Auth($this->db))->requireUser();
        if (($u['home_role'] ?? $u['role']) !== 'worker') {
            throw new ApiException('Only worker accounts can switch modes. A business account stays an employer account.', 403);
        }
        if (($in['confirm'] ?? false) !== true) {
            throw new ApiException('Please confirm the switch.', 422);
        }
        $mode = Input::enum($in, 'mode', ['worker', 'employer'], 'Choose a mode.');
        $limit = new RateLimit($this->db);
        $key = 'mode:user:' . $u['id'];
        if ($limit->tooMany($key, 10, 3600)) {
            throw new ApiException('You switched many times. Please wait a little.', 429);
        }
        $limit->hit($key);
        $first = !\Beefrika\Modes::get($this->db, (int)$u['id'])['employer_enabled'];
        if ($mode === 'employer') {
            \Beefrika\Modes::enableEmployer($this->db, (int)$u['id']);
        }
        \Beefrika\Modes::setActive($this->db, (int)$u['id'], $mode);
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$u['id'], $first && $mode === 'employer' ? 'mode.employer_enabled' : 'mode.switch', 'user', $u['id'], json_encode(['to' => $mode]), Security::ipHash(Http::ip()), Clock::dt()]);
        return ['ok' => true, 'mode' => $mode];
    }
}
