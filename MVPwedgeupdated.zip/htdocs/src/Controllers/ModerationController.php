<?php
declare(strict_types=1);

namespace Beefrika\Controllers;

use Beefrika\ApiException;
use Beefrika\Auth;
use Beefrika\Avatar;
use Beefrika\Clock;
use Beefrika\Http;
use Beefrika\Passport;
use Beefrika\Security;
use PDO;

/** Admin tools to take down a profile photo, a feedback comment or a Work Passport. Every action needs a note and is written to the audit log. */
final class ModerationController
{
    public function __construct(private PDO $db)
    {
    }

    /** GET /admin/moderate?tab=photos|feedback|removed|passports */
    public function list(array $q): array
    {
        (new Auth($this->db))->requireUser('admin');
        $tab = in_array($q['tab'] ?? '', ['photos', 'feedback', 'removed', 'passports'], true) ? $q['tab'] : 'photos';
        try {
            if ($tab === 'photos') {
                $st = $this->db->query('SELECT a.user_id AS id, a.token, a.created_at, u.beefrika_id, u.full_name, u.role FROM user_avatars a JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT 40');
                $items = array_map(fn($r) => ['id' => (int)$r['id'], 'photo' => '/a/' . $r['token'], 'name' => $r['full_name'], 'beefrika_id' => $r['beefrika_id'],
                    'role' => $r['role'], 'created_at' => $r['created_at']], $st->fetchAll());
            } elseif ($tab === 'passports') {
                $st = $this->db->query('SELECT p.id, p.label, p.views, p.expires_at, p.revoked_at, p.created_at, u.full_name, u.beefrika_id FROM passports p JOIN users u ON u.id = p.worker_id ORDER BY p.id DESC LIMIT 40');
                $now = Clock::now();
                $items = array_map(function ($r) use ($now) {
                    $exp = $r['expires_at'] === null ? null : (strtotime($r['expires_at'] . ' UTC') ?: 0);
                    return ['id' => (int)$r['id'], 'label' => $r['label'], 'views' => (int)$r['views'], 'name' => $r['full_name'], 'beefrika_id' => $r['beefrika_id'],
                        'state' => $r['revoked_at'] !== null ? 'off' : ($exp !== null && $exp <= $now ? 'expired' : 'on'), 'created_at' => $r['created_at']];
                }, $st->fetchAll());
            } else {
                $st = $this->db->prepare(
                    'SELECT f.id, f.rating, f.comment, f.created_at, fu.full_name AS from_name, fu.role AS from_role, tu.full_name AS to_name, tu.beefrika_id AS to_bf
                     FROM job_feedback f JOIN users fu ON fu.id = f.from_user JOIN users tu ON tu.id = f.to_user WHERE f.status = ? ORDER BY f.id DESC LIMIT 40'
                );
                $st->execute([$tab === 'removed' ? 'removed' : 'published']);
                $items = array_map(fn($r) => ['id' => (int)$r['id'], 'rating' => (int)$r['rating'], 'comment' => $r['comment'], 'from' => $r['from_name'], 'from_role' => $r['from_role'],
                    'to' => $r['to_name'], 'to_bf' => $r['to_bf'], 'created_at' => $r['created_at']], $st->fetchAll());
            }
        } catch (\PDOException $e) {
            $items = []; // the table for this tab has not been created yet
        }
        return ['tab' => $tab, 'items' => $items];
    }

    /** POST /admin/moderate/{photos|feedback|passports}/{id}/{remove|restore|off} {note} */
    public function act(string $kind, int $id, string $action, array $in): array
    {
        $admin = (new Auth($this->db))->requireUser('admin');
        $note = Input::text($in, 'note', 3, 500, 'Note');
        $ok = match ([$kind, $action]) {
            ['photos', 'remove'] => $this->removePhoto($id),
            ['feedback', 'remove'] => $this->setFeedback($id, 'removed', 'published'),
            ['feedback', 'restore'] => $this->setFeedback($id, 'published', 'removed'),
            ['passports', 'off'] => $this->passportOff($id),
            default => throw new ApiException('That action is not available.', 404),
        };
        if (!$ok) {
            throw new ApiException('Nothing to change. It may already be done.', 409);
        }
        $this->db->prepare('INSERT INTO audit_log (actor_id, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$admin['id'], 'moderate.' . $kind . '.' . $action, $kind, $id, json_encode(['note' => $note]), Security::ipHash(Http::ip()), Clock::dt()]);
        return ['ok' => true];
    }

    private function removePhoto(int $userId): bool
    {
        $st = $this->db->prepare('SELECT file FROM user_avatars WHERE user_id = ?');
        $st->execute([$userId]);
        $file = $st->fetchColumn();
        if ($file === false) {
            return false;
        }
        $this->db->prepare('DELETE FROM user_avatars WHERE user_id = ?')->execute([$userId]);
        @unlink(Avatar::dir() . '/' . basename((string)$file));
        return true;
    }

    private function setFeedback(int $id, string $to, string $from): bool
    {
        $st = $this->db->prepare('UPDATE job_feedback SET status = ? WHERE id = ? AND status = ?');
        $st->execute([$to, $id, $from]);
        return $st->rowCount() === 1;
    }

    private function passportOff(int $id): bool
    {
        $st = $this->db->prepare('UPDATE passports SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL');
        $st->execute([Clock::dt(), $id]);
        return $st->rowCount() === 1;
    }
}
