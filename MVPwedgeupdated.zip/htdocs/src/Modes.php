<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/**
 * One person, one Beefrika ID, two modes. A worker can also hire as an employer, and switch between the two.
 * The ID, phone and password stay the same. Business accounts made with "I hire" stay employer-only.
 */
final class Modes
{
    /** @return array{employer_enabled:bool,active:string} */
    public static function get(PDO $db, int $userId): array
    {
        try {
            $st = $db->prepare('SELECT employer_enabled, active_mode FROM user_modes WHERE user_id = ?');
            $st->execute([$userId]);
            $r = $st->fetch();
        } catch (\Throwable $e) {
            $r = false;
        }
        return $r ? ['employer_enabled' => (int)$r['employer_enabled'] === 1, 'active' => $r['active_mode'] === 'employer' ? 'employer' : 'worker']
                  : ['employer_enabled' => false, 'active' => 'worker'];
    }

    /** Gives a worker an employer side (once), and writes it to the audit log. */
    public static function enableEmployer(PDO $db, int $userId): void
    {
        $now = Clock::dt();
        $has = $db->prepare('SELECT 1 FROM employer_profiles WHERE user_id = ?');
        $has->execute([$userId]);
        if (!$has->fetchColumn()) {
            $db->prepare('INSERT INTO employer_profiles (user_id, created_at, updated_at) VALUES (?, ?, ?)')->execute([$userId, $now, $now]);
        }
        try {
            $m = $db->prepare('SELECT employer_enabled FROM user_modes WHERE user_id = ?');
            $m->execute([$userId]);
            $row = $m->fetch();
            if (!$row) {
                $db->prepare('INSERT INTO user_modes (user_id, employer_enabled, active_mode, enabled_at, updated_at) VALUES (?, 1, ?, ?, ?)')->execute([$userId, 'worker', $now, $now]);
            } elseif ((int)$row['employer_enabled'] !== 1) {
                $db->prepare('UPDATE user_modes SET employer_enabled = 1, enabled_at = ?, updated_at = ? WHERE user_id = ?')->execute([$now, $now, $userId]);
            }
        } catch (\PDOException $e) {
            throw new ApiException('The site needs a quick database update first. Please try again later.', 503);
        }
    }

    public static function setActive(PDO $db, int $userId, string $mode): void
    {
        $db->prepare('UPDATE user_modes SET active_mode = ?, updated_at = ? WHERE user_id = ? AND employer_enabled = 1')->execute([$mode, Clock::dt(), $userId]);
    }

    /** For a worker's public page: the employer side, if they have one and its page is on. @return array{name:string,path:string}|null */
    public static function employerLine(PDO $db, int $userId): ?array
    {
        if (!self::get($db, $userId)['employer_enabled']) {
            return null;
        }
        $path = EmployerPage::pathFor($db, $userId);
        if ($path === null) {
            return null;
        }
        $st = $db->prepare('SELECT business_name FROM employer_profiles WHERE user_id = ?');
        $st->execute([$userId]);
        $name = (string)$st->fetchColumn();
        return $name === '' ? null : ['name' => $name, 'path' => $path];
    }
}
