<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/** Bearer-token sessions. Only a hash of the token is stored; tokens are never accepted in URLs. */
final class Auth
{
    public const SESSION_DAYS = 30;

    public function __construct(private PDO $db)
    {
    }

    public function startSession(int $userId, string $ip, string $userAgent): string
    {
        $token = Security::newToken();
        $this->db->prepare(
            'INSERT INTO sessions (user_id, token_hash, user_agent, ip_hash, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([
            $userId,
            Security::hashToken($token),
            mb_substr($userAgent, 0, 255),
            Security::ipHash($ip),
            Clock::dt(Clock::now() + self::SESSION_DAYS * 86400),
            Clock::dt(),
        ]);
        return $token;
    }

    /** @return array<string,mixed>|null the user row for a valid, active session */
    public function currentUser(): ?array
    {
        $token = Http::bearerToken();
        if ($token === null) {
            return null;
        }
        $st = $this->db->prepare(
            'SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
             WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.status = ? LIMIT 1'
        );
        $st->execute([Security::hashToken($token), Clock::dt(), 'active']);
        $u = $st->fetch();
        if (!$u) {
            return null;
        }
        // One person, two modes: a worker who switched to employer mode acts as an employer until they switch back.
        $u['home_role'] = $u['role'];
        if ($u['role'] === 'worker') {
            $modes = Modes::get($this->db, (int)$u['id']);
            $u['dual'] = $modes['employer_enabled'];
            if ($modes['employer_enabled'] && $modes['active'] === 'employer') {
                $u['role'] = 'employer';
            }
        }
        return $u;
    }

    public function requireUser(?string $role = null): array
    {
        $u = $this->currentUser();
        if ($u === null) {
            throw new ApiException('Please log in.', 401);
        }
        if ($role !== null && $u['role'] !== $role) {
            throw new ApiException('You do not have access to this.', 403);
        }
        return $u;
    }

    public function revokeCurrent(): void
    {
        $token = Http::bearerToken();
        if ($token !== null) {
            $this->db->prepare('UPDATE sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL')
                ->execute([Clock::dt(), Security::hashToken($token)]);
        }
    }
}
