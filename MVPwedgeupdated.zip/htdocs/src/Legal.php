<?php
declare(strict_types=1);

namespace Beefrika;

use PDO;

/** The Terms of Use and the Privacy Notice, served at /terms and /privacy, and the record of who agreed to which version. */
final class Legal
{
    public const VERSION = '1.1';
    public const UPDATED = '15 October 2026';

    public static function recordAcceptance(PDO $db, int $userId): void
    {
        try {
            $has = $db->prepare('SELECT 1 FROM terms_acceptance WHERE user_id = ? AND version = ?');
            $has->execute([$userId, self::VERSION]);
            if (!$has->fetchColumn()) {
                $db->prepare('INSERT INTO terms_acceptance (user_id, version, accepted_at) VALUES (?, ?, ?)')->execute([$userId, self::VERSION, Clock::dt()]);
            }
        } catch (\Throwable $e) {
            // table not created yet: sign-up must not fail because of it
        }
    }

    public static function contactEmail(): string
    {
        $m = Env::get('CONTACT_EMAIL');
        return $m !== null && filter_var($m, FILTER_VALIDATE_EMAIL) ? $m : 'infonbeefrika@gmail.com';
    }

    /** @return array{title:string,intro:string,sections:array<int,array{0:string,1:array<int,string>}>}|null */
    private static function content(string $page): ?array
    {
        $mail = self::contactEmail();
        if ($page === 'privacy') {
            return ['title' => 'Privacy Notice', 'intro' => 'This explains what Beefrika collects about you, why, who can see it, and what you can do about it. We follow the Nigeria Data Protection Act 2023 (NDPA). "We" and "Beefrika" mean the team running Beefrika in Lagos, Nigeria.', 'sections' => [
                ['This is a test pilot', ['Beefrika is currently a test pilot. It is not the final product. While it is a pilot, information may be reset or deleted, features may change or be switched off, and the people using it are testers. Please do not upload anything you cannot afford to lose.']],
                ['What Beefrika is', ['Beefrika helps workers keep a record of their work and helps employers find workers and check them. Because Beefrika is about trust, some of your information is shown to other people. This notice tells you exactly which.']],
                ['What we collect', [
                    'Account details: your name, phone number, role (worker or employer) and a scrambled (hashed) version of your password. We never store your password itself.',
                    'Profile details you add: trade, area, worker type, experience, headline, about you, business name and type, what you hire for, and your profile photo.',
                    'Proof you upload: photos and the names of the people or places that can confirm your work. Only upload what you are happy for us to hold.',
                    'Activity: hiring requests, chat messages, agreed jobs, fees recorded, reports you make, vouches and feedback you give or receive.',
                    'Vouches from customers: the customer\'s first name, area, rating, comment and phone number. The phone number is kept only in a scrambled form so we can stop fake vouches. It is never shown.',
                    'Technical data: a scrambled form of your IP address, sign-in times, and logs we need to keep the service safe and working.',
                ]],
                ['Why we use it, and our legal basis', [
                    'To run your account and the hiring service you asked for (contract).',
                    'To show your profile, proof, vouches and feedback to the people you choose, and to let employers find you if you switch that on (your consent, which you can withdraw).',
                    'To keep Beefrika safe: stopping fake accounts, scams and abuse, and handling reports (our legitimate interest and legal duties).',
                    'To send you codes and service messages by SMS or email (contract).',
                ]],
                ['Who can see what', [
                    'Your public page: if you switch it on, anyone with the link can see your name, photo, trade, area, proof level, proof items, jobs recorded on Beefrika, vouches and feedback. Your phone number is never on it.',
                    'Employers you deal with can see your profile and the chat. Your contact details stay inside Beefrika unless you choose to share them.',
                    'Your Work Passport: only the people you send a link to can see it, only what you tick, and only until it expires or you switch it off. You can see how many times each one was opened.',
                    'Employer pages: if an employer switches their page on, anyone with the link can see their business name, type, area, proof level, confirmed jobs and feedback from workers. Contact details stay private.',
                    'Our team can see account and activity information where needed to run the service, check proof, and act on reports.',
                    'We do not sell your information.',
                ]],
                ['Who we share it with', [
                    'Service providers that help us run Beefrika, for example our web hosting provider, an SMS provider to send codes, and an email provider. They may only use your information for that purpose.',
                    'In future, a licensed identity-check provider, if you choose to verify your identity. We will tell you first.',
                    'Authorities, when the law requires it.',
                    'We will never give a bank, lender or other organisation your record unless you create a Work Passport or otherwise agree.',
                ]],
                ['Where it is stored and for how long', [
                    'Your information is stored on servers run by our hosting provider, which may be outside Nigeria. We choose providers that protect information, and we only send what is needed.',
                    'We keep your information while your account is open. If you ask us to delete your account, we remove your profile, photos and passports. We may keep limited records where the law requires it, or where they are needed to handle a dispute, a fee or a safety issue, such as a confirmed job that involves another person.',
                    'Vouches and feedback written about someone else may stay on their record even if you close your account, with your name shown only as the first name you gave.',
                ]],
                ['How we protect it', [
                    'Passwords and phone numbers on vouches are stored in scrambled form, sign-in attempts are limited, and uploaded photos are stored outside the public folders and cleaned of location data.',
                    'No service is perfectly secure. Choose a strong password and do not share it. If you switch on log-in with your Beefrika ID, you are choosing a faster way back into your account in return for a higher risk, so use a very strong password.',
                ]],
                ['Your rights', [
                    'You can ask to see the information we hold about you, correct it, delete it, object to how we use it, take a copy of it, or withdraw consent you gave. You can do much of this yourself in the app.',
                    'To use a right that the app does not cover, email us. We will answer within a reasonable time and may ask you to prove who you are first.',
                    'If you are unhappy with how we handle your information, you can complain to the Nigeria Data Protection Commission (NDPC).',
                ]],
                ['Children', ['Beefrika is for people aged 18 and over. If you think someone under 18 has an account, tell us and we will act on it.']],
                ['Changes to this notice', ['If we change this notice in a way that matters, we will tell you in the app. The date and version are at the bottom of this page.']],
                ['Contact us', ['Email: ' . $mail . '. Please write "Privacy" in the subject.']],
            ]];
        }
        if ($page === 'terms') {
            return ['title' => 'Terms of Use', 'intro' => 'These are the rules for using Beefrika. By creating an account or using the service you agree to them and to our Privacy Notice. If you do not agree, please do not use Beefrika.', 'sections' => [
                ['This is a test pilot', ['Beefrika is currently a test pilot, not the final product. Features, prices, fees and rules may change or be switched off, and information may be reset. Payments made inside the pilot are pretend: no real money moves, and nothing is owed because of them. Never send real money or enter real card details because of anything in the pilot, and be careful of anyone who asks you to.']],
                ['What Beefrika is, and is not', [
                    'Beefrika is a platform where workers keep a record of their work and employers find and check workers. We are not the employer of any worker, we are not an employment agency, and we are not a party to any job you agree.',
                    'A Beefrika ID is not a government ID. A proof level or badge shows what has been added or checked on Beefrika, using the labels we explain in the app. It does not guarantee anyone\'s skill, honesty or conduct, and it is not a credit score.',
                    '"Verified" means a named source confirmed something. It does not mean Beefrika or the government has checked it unless we say so.',
                ]],
                ['Who can use it', [
                    'You must be 18 or older and able to make agreements in Nigeria.',
                    'One person, one account, with your own phone number. Do not pretend to be someone else, and do not create accounts for other people without their agreement.',
                    'You are responsible for what happens on your account. Keep your password safe. If you switch on log-in with your Beefrika ID, you accept the extra risk that comes with it.',
                ]],
                ['Being honest', [
                    'Give true information. Do not upload proof that is fake, altered or belongs to someone else. Use only your own photo as your profile photo.',
                    'Do not ask for, give or invent fake vouches or feedback. Do not ask customers or workers to rate you in exchange for money or favours.',
                    'Only confirm a job that really happened, and only mark it complete when it is.',
                ]],
                ['How to behave', [
                    'Do not use Beefrika to scam, threaten, harass, discriminate against or mislead anyone, to ask workers to pay for a job, or to break the law.',
                    'Do not upload anything unlawful, offensive or that you do not have the right to share.',
                    'Do not try to break into Beefrika, copy its data in bulk, or interfere with how it works.',
                    'Report anything that looks wrong, using the report button in the app.',
                ]],
                ['Hiring, jobs and money', [
                    'You and the other person agree the job, the pay and the working arrangements between yourselves. Beefrika does not hold or move your money, and payments for work happen outside the app.',
                    'Employers pay a hiring fee when a hire is confirmed. The fee is the worker\'s category price times the type of hire, and the category comes from the worker\'s years of experience. You see an invoice in the app before you pay. Payment is made by bank transfer, outside the app, using the invoice number as the reference.',
                    'If a job does not go ahead after an employer has paid, the employer can ask for a refund inside the refund period shown on the invoice (currently 7 days from payment). We review each request. A fee is not refunded once the job is marked complete or once the refund period has passed.',
                    'Workers get one free hiring credit. After that, each hire a worker confirms uses one hiring credit, which workers buy in packs. Credits are added once we have received payment and are not refundable once added.',
                    'Meet carefully, especially for a first job. Agree the job in the Beefrika chat so there is a record.',
                ]],
                ['Vouches, feedback and records', [
                    'Vouches and feedback are the opinions of the people who wrote them. We do not check them all, and we are not responsible for what they say.',
                    'A worker cannot edit or hide a vouch or feedback. They can report one, and our team decides. We may remove content that breaks these terms.',
                    'A job confirmed by both sides becomes part of both people\'s record. We may keep it even if one person later closes their account.',
                ]],
                ['Your content', [
                    'You keep ownership of what you upload. You give Beefrika permission to store it and to show it to the people you choose or as the product works, for example on your public page and Work Passports.',
                    'You decide whether your public page and Work Passports are on, and you can switch them off. Someone who already saw or copied something may still have it.',
                ]],
                ['Our right to act', [
                    'We may suspend or close an account, remove content, or switch off a page or passport if we believe these terms were broken, someone may be harmed, or the law requires it. Where we reasonably can, we will tell you why.',
                    'You can stop using Beefrika and ask us to delete your account at any time.',
                ]],
                ['Limits on our responsibility', [
                    'We work to keep Beefrika running and accurate, but it is provided "as is". Things can go wrong, and we cannot promise it will always be available or error free.',
                    'As far as the law allows, Beefrika is not responsible for losses that come from a job, a payment, a person\'s behaviour, or from relying on a profile, badge, vouch or feedback. Nothing here limits responsibility that the law does not allow us to limit.',
                ]],
                ['Changes and disputes', [
                    'We may update these terms. If a change matters, we will tell you in the app, and using Beefrika after that means you accept it.',
                    'These terms are governed by the laws of the Federal Republic of Nigeria. If we cannot settle a problem by talking, the courts of Lagos State will deal with it.',
                ]],
                ['Contact us', ['Email: ' . $mail . '.']],
            ]];
        }
        return null;
    }

    public static function render(string $page): ?string
    {
        $c = self::content($page);
        if ($c === null) {
            return null;
        }
        $e = [PublicProfile::class, 'e'];
        $other = $page === 'privacy' ? ['terms', 'Terms of Use'] : ['privacy', 'Privacy Notice'];
        $out = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
            . '<title>' . $e($c['title']) . ' | Beefrika</title><meta name="theme-color" content="#F0A500"><link rel="icon" href="/icons/logo-96.png">'
            . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
            . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"><link rel="stylesheet" href="/style.css"></head><body><main class="screen legal">'
            . '<div class="brandbar"><img src="/icons/logo-96.png" alt="" width="40" height="40"><b>Beefrika</b>' . Pilot::pill() . '</div>'
            . '<h1>' . $e($c['title']) . '</h1><p class="muted">Version ' . self::VERSION . ' &middot; ' . $e(self::UPDATED) . '</p><p class="lead">' . $e($c['intro']) . '</p>';
        foreach ($c['sections'] as $i => [$heading, $paras]) {
            $out .= '<h2>' . ($i + 1) . '. ' . $e($heading) . '</h2>';
            $list = count($paras) > 1;
            $out .= $list ? '<ul class="plain">' : '';
            foreach ($paras as $p) {
                $out .= $list ? '<li>' . $e($p) . '</li>' : '<p>' . $e($p) . '</p>';
            }
            $out .= $list ? '</ul>' : '';
        }
        return $out . '<a class="btn ghost" href="/' . $other[0] . '">' . $e($other[1]) . '</a><a class="btn" href="/">Back to Beefrika</a></main></body></html>';
    }

    /** Small footer line with both links, for the public pages. */
    public static function footer(): string
    {
        return '<p class="legalfoot"><a href="/terms">Terms</a> &middot; <a href="/privacy">Privacy</a>' . (Pilot::on() ? '<br>Beefrika is a test pilot, not the final product.' : '') . '</p>';
    }
}
