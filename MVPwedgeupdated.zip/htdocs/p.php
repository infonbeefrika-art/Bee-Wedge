<?php
declare(strict_types=1);

// Public worker page: /p/BF-XXXXXX (and /p/BF-XXXXXX/photo/ID for that page's photos). See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

use Beefrika\Controllers\PhotoController;
use Beefrika\Db;
use Beefrika\PublicProfile;

$id = (string)($_GET['id'] ?? '');
try {
    $db = Db::pdo();
    if (isset($_GET['photo'])) {
        PhotoController::servePublic($db, $id, (int)$_GET['photo']); // exits
    }
    $data = PublicProfile::find($db, $id);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-cache');
    if ($data === null) {
        http_response_code(404);
        echo PublicProfile::notFound();
        exit;
    }
    PublicProfile::recordView($db, (int)$data['id'], $_SERVER['HTTP_USER_AGENT'] ?? '');
    echo PublicProfile::render($data, PublicProfile::baseUrl());
} catch (Throwable $e) {
    error_log('Public page error: ' . get_class($e) . ': ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Something went wrong. Please try again.';
}
