<?php
declare(strict_types=1);

// Work Passport: /pass/<24 hex chars>. See .htaccess for the rewrite.
$bfBase = is_dir(__DIR__ . '/src') ? __DIR__ : dirname(__DIR__);
require $bfBase . '/src/bootstrap.php';

use Beefrika\Db;
use Beefrika\Passport;
use Beefrika\PublicProfile;

try {
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store');
    $db = Db::pdo();
    $token = (string)($_GET['t'] ?? '');
    $p = Passport::find($db, $token);
    if ($p === null) {
        http_response_code(404);
        echo Passport::notFound();
        exit;
    }
    Passport::recordView($db, (int)$p['id'], $_SERVER['HTTP_USER_AGENT'] ?? '');
    echo Passport::render($p, $db, PublicProfile::baseUrl() . '/pass/' . $token);
} catch (Throwable $e) {
    error_log('Passport page error: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Something went wrong. Please try again.';
}
