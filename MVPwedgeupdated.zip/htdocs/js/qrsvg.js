import { svg } from './dom.js';
import { qrMatrix } from './qr.js';

/** A scannable QR code as an SVG element. Includes the 4-module quiet zone scanners need. */
export function qrSvg(text, px = 240) {
  const m = qrMatrix(text);
  const n = m.length;
  const q = 4;
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (m[r][c]) d += `M${c + q} ${r + q}h1v1h-1z`;
  return svg('svg', { viewBox: `0 0 ${n + 2 * q} ${n + 2 * q}`, width: px, height: px, role: 'img', 'aria-label': 'QR code', 'shape-rendering': 'crispEdges', class: 'qr' },
    svg('rect', { width: n + 2 * q, height: n + 2 * q, fill: '#fff' }), svg('path', { d, fill: '#121212' }));
}
