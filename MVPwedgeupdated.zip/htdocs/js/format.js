// Pure helpers (no DOM) so they can be tested with `node --test`.
export function parseHash(hash) {
  const raw = (hash || '').replace(/^#/, '') || '/';
  const [pathPart, queryPart = ''] = raw.split('?');
  const path = '/' + pathPart.replace(/^\/+|\/+$/g, '');
  const query = Object.fromEntries(new URLSearchParams(queryPart));
  let m;
  if ((m = path.match(/^\/w\/(BF-[A-HJKMNP-Z2-9]{6})$/))) return { name: 'worker', params: { id: m[1] }, query };
  if ((m = path.match(/^\/invoice\/(\d{1,12})$/))) return { name: 'invoice', params: { id: Number(m[1]) }, query };
  if ((m = path.match(/^\/r\/(\d{1,12})$/))) return { name: 'thread', params: { id: Number(m[1]) }, query };
  const names = { '/': 'home', '/join': 'join', '/login': 'login', '/find': 'find', '/record': 'record', '/business': 'business', '/admin': 'admin', '/requests': 'requests', '/card': 'card', '/vouches': 'vouches', '/credits': 'credits', '/invoices': 'invoices', '/passport': 'passport', '/scan': 'scan', '/forgot': 'forgot' };
  return { name: names[path] || 'notfound', params: {}, query };
}

export function naira(amount) {
  return '\u20A6' + Math.round(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export function headlineLevel(verified, evidence) {
  return verified > 0 ? 'verified' : evidence > 0 ? 'evidence' : 'self_reported';
}

export function buildQuery(params) {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== '' && v != null && v !== false) q.set(k, v === true ? '1' : String(v));
  const s = q.toString();
  return s ? '?' + s : '';
}

/** "14:05" today, otherwise "12 Oct, 14:05". Input is a UTC "YYYY-MM-DD HH:MM:SS" string from the server. */
export function formatTime(utc, now = new Date()) {
  const d = new Date(String(utc).replace(' ', 'T') + 'Z');
  if (Number.isNaN(d.getTime())) return '';
  const hm = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (d.toDateString() === now.toDateString()) return hm;
  return d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ', ' + hm;
}

export const statusLabel = (T, role, status) => ((role === 'worker' && T.reqStatusWorker[status]) || T.reqStatus[status] || status);

/** Scale (w, h) down so the longer side is at most max. Never scales up. */
export function fitSize(w, h, max) {
  const m = Math.max(w, h);
  if (m <= max) return { w, h };
  const k = max / m;
  return { w: Math.max(1, Math.round(w * k)), h: Math.max(1, Math.round(h * k)) };
}

/** Only a worker profile path may be used as a post-login destination (no open redirects). */
export function safeNext(next) {
  return typeof next === 'string' && /^\/w\/BF-[A-HJKMNP-Z2-9]{6}$/.test(next) ? next : null;
}
export function safeRef(ref) {
  return typeof ref === 'string' && /^BF-[A-HJKMNP-Z2-9]{6}$/.test(ref) ? ref : null;
}

export const publicUrl = (origin, id) => `${String(origin).replace(/\/$/, '')}/p/${id}`;

export function shareText(name, trade, area, url) {
  const what = [trade, area ? 'in ' + area : null].filter(Boolean).join(' ');
  return `${name}${what ? ', ' + what : ''}. See my work record on Beefrika: ${url}`;
}

export const whatsappLink = (text) => 'https://wa.me/?text=' + encodeURIComponent(text);

/** Heights (0-100) for a small bar chart. The tallest bar is 100; zero stays zero. */
export function barHeights(values) {
  const max = Math.max(1, ...values);
  return values.map((v) => (v === 0 ? 0 : Math.max(6, Math.round((v / max) * 100))));
}

/** Copies text. Falls back to an old method on phones that block the clipboard. */
export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (e) { /* try the old way */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.append(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove(); return ok;
  } catch (e) { return false; }
}
