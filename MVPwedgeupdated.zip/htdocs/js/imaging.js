import { fitSize } from './format.js';

/** Shrinks a photo on the phone before upload (saves data) and re-encodes it as JPEG, which also drops location data. */
export async function compressImage(file, max = 1280, quality = 0.8) {
  let bmp;
  if (typeof createImageBitmap === 'function') {
    try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (e) { bmp = null; }
  }
  if (!bmp) {
    bmp = await new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not a photo.')); };
      img.src = url;
    });
  }
  const sw = bmp.width || bmp.naturalWidth;
  const sh = bmp.height || bmp.naturalHeight;
  const { w, h } = fitSize(sw, sh, max);
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
  ctx.drawImage(bmp, 0, 0, w, h);
  if (bmp.close) bmp.close();
  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('That file is not a photo.'))), 'image/jpeg', quality));
}
