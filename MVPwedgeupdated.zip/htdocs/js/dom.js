export function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  for (const c of kids.flat(Infinity)) e.append(c instanceof Node ? c : document.createTextNode(c == null ? '' : String(c)));
  return e;
}
export function svg(tag, attrs, ...kids) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs || {})) if (v != null) e.setAttribute(k, String(v));
  for (const c of kids.flat(Infinity)) if (c) e.append(c);
  return e;
}
export const note = (kind, text) => h('div', { class: 'msg ' + kind, role: kind === 'err' ? 'alert' : 'status' }, text);
export function field(label, input, hint) {
  const id = 'f_' + Math.random().toString(36).slice(2, 8);
  input.id = id;
  return [h('label', { for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : ''];
}
export function select(options, selected, placeholder) {
  const s = h('select', {});
  if (placeholder) s.append(h('option', { value: '' }, placeholder));
  for (const o of options) s.append(h('option', { value: o.value, selected: String(selected) === String(o.value) }, o.label));
  return s;
}
export const setBusy = (btn, busy) => { btn.disabled = busy; };
