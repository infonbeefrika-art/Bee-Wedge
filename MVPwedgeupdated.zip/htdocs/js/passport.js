import { qrSvg } from './qrsvg.js';

// Work Passport page: draws the QR code and wires the print button. No inline scripts are allowed on this site.
const box = document.getElementById('passportqr');
if (box && box.dataset.url) box.append(qrSvg(box.dataset.url, 160));
const print = document.getElementById('printpassport');
if (print) print.addEventListener('click', () => window.print());
