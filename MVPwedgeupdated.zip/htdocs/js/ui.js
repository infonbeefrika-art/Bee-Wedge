import { h } from './dom.js';
import { brand, bee } from './honey.js';
import { T } from './strings.js';
import { api, state, store } from './api.js';

export const go = (path) => {
  const target = '#' + path;
  if (location.hash === target) window.dispatchEvent(new Event('hashchange'));
  else location.hash = target;
};

export function bottomNav(current) {
  const role = state.me && state.me.role;
  const items = role === 'employer' ? [['/find', T.navFind], ['/requests', T.navRequests], ['/scan', T.navScan], ['/business', T.navBiz]]
    : role === 'admin' ? [['/admin', T.navQueue]]
    : [['/requests', T.navRequests], ['/record', T.navRecord], ['/vouches', T.navVouches], ['/scan', T.navScan]];
  if (items.length < 2) return '';
  return h('nav', { class: 'bottomnav', 'aria-label': 'Main' }, items.map(([to, label]) =>
    h('a', { href: '#' + to, class: current === to ? 'on' : '', 'aria-current': current === to ? 'page' : null },
      label, to === '/requests' ? h('span', { class: 'navbadge', hidden: true }) : '')));
}

export function paintBadge() {
  const n = state.summary ? state.summary.unread + state.summary.todo : 0;
  document.querySelectorAll('.navbadge').forEach((el) => { el.textContent = n > 99 ? '99+' : String(n); el.hidden = n === 0; });
  document.title = (n > 0 ? `(${n}) ` : '') + 'Beefrika';
}

export async function refreshSummary() {
  if (!state.me || !['employer', 'worker'].includes(state.me.role)) return;
  try { state.summary = await api('/summary'); paintBadge(); } catch (e) { /* offline: keep the old number */ }
}

/** Page frame for signed-in screens. */
export function shell(current, ...children) {
  const logout = h('button', { class: 'link', onclick: async () => {
    try { await api('/auth/logout', 'POST'); } catch (e) { /* ignore */ }
    store.token = null; state.me = null; go('/');
  } }, T.logout);
  return [h('div', { class: 'top' }, brand(), logout), ...children, legalLinks(), bottomNav(current)];
}

export function loadingView() {
  return [h('div', { class: 'empty' }, bee(44), h('p', {}, T.loading)), h('div', { class: 'skel', 'aria-hidden': 'true' }, h('i'), h('i'), h('i'))];
}

export function errorView(msg, retry) {
  return [brand(), h('div', { class: 'msg err', role: 'alert' }, msg), h('button', { class: 'btn', onclick: retry }, T.retry)];
}

/** Small Terms and Privacy links for the bottom of a screen. */
export function legalLinks() {
  return h('p', { class: 'legalfoot' }, h('a', { href: '/terms', target: '_blank', rel: 'noopener' }, T.legalFoot), ' \u00B7 ', h('a', { href: '/privacy', target: '_blank', rel: 'noopener' }, T.legalFoot2));
}

/** A confirmation toast that slides up from the bottom. Resolves true if the person taps the yes button. */
export function confirmToast({ title, text, yes, no }) {
  return new Promise((resolve) => {
    const done = (v) => { document.removeEventListener('keydown', onKey); wrap.remove(); resolve(v); };
    const onKey = (e) => { if (e.key === 'Escape') done(false); };
    const ok = h('button', { class: 'btn', onclick: () => done(true) }, yes);
    const sheet = h('div', { class: 'toast', role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': 'toasttitle' },
      h('b', { id: 'toasttitle', class: 'toasttitle' }, title), h('p', {}, text), ok, h('button', { class: 'btn ghost', onclick: () => done(false) }, no));
    const wrap = h('div', { class: 'toastwrap', onclick: (e) => { if (e.target === wrap) done(false); } }, sheet);
    document.addEventListener('keydown', onKey);
    document.body.append(wrap);
    ok.focus();
  });
}
