import { h } from '../dom.js';
import { T } from '../strings.js';
import { proofBadge, hexBadge, creditJar, dropIcon } from '../honey.js';
import { avatarImg } from './avatar.js';
import { copyText } from '../format.js';

/** The top of a profile: cover band, big photo, name, proof level, availability, ID and a few live numbers. */
export function profileHero({ name, avatar, line, proof, availability, id, headline, eyebrow, stats = [], extra = null }) {
  const status = h('span', { class: 'hint', role: 'status' });
  const avail = availability
    ? h('span', { class: 'availdot' + (availability === 'available' ? ' on' : '') }, availability === 'available' ? T.heroAvailNow : (T.availShort[availability] || ''))
    : '';
  const chip = id ? h('button', { type: 'button', class: 'idchip', 'aria-label': `${id}. ${T.idCopy}`, onclick: async () => {
    status.textContent = (await copyText(id)) ? T.idCopied : id;
  } }, id) : '';
  return h('section', { class: 'phero' },
    h('div', { class: 'phero-cover', 'aria-hidden': 'true' }),
    h('div', { class: 'phero-body' },
      avatarImg(avatar, name, 96),
      h('div', { class: 'phero-text' },
        eyebrow ? h('p', { class: 'eyebrow' }, eyebrow) : '',
        h('h1', {}, name),
        line ? h('p', { class: 'muted' }, line) : '',
        h('div', { class: 'phero-tags' }, proofBadge(proof), avail, chip), extra || '', status,
        headline ? h('p', { class: 'lead' }, headline) : '')),
    stats.length ? h('div', { class: 'phero-stats' }, stats.map((s) => h('div', { class: 'stat' }, h('b', {}, String(s.value)), h('span', {}, s.label)))) : '');
}

/** Honey badges a worker earns. Locked ones stay visible with a hint, so there is always a next thing to do. */
export function achievements({ photo, vouches, proof, completion }) {
  const rank = { unverified: 0, identity: 1, skill: 2, work: 3 }[proof] || 0;
  const done = { photo: !!photo, vouch1: vouches >= 1, vouch5: vouches >= 5, skill: rank >= 2, work: rank >= 3, jar: completion >= 100 };
  const got = Object.values(done).filter(Boolean).length;
  return h('section', { class: 'card' }, h('div', { class: 'evhead' }, h('b', {}, T.achTitle), h('span', { class: 'hint' }, T.achCount(got, 6))),
    h('ul', { class: 'ach' }, Object.keys(done).map((k) => h('li', { class: 'ach-item' + (done[k] ? ' done' : '') },
      hexBadge(done[k] ? 'verified' : 'self_reported', 30), h('b', {}, T.ach[k][0]), h('small', {}, done[k] ? T.ach[k][1] : T.ach[k][2])))));
}

/** Hiring credits chip for the top of a worker's profile: a small jar with the number left. Tap to see how to buy more. */
export function creditChip(balance) {
  if (balance === null) return '';
  return h('a', { class: 'creditchip' + (balance < 1 ? ' low' : ''), href: '#/credits', 'aria-label': T.crChipLabel(balance) },
    creditJar(balance, 26), h('span', {}, h('b', {}, String(balance)), ' ' + T.crChip(balance).replace(/^\d+ /, '')));
}

const ICONS = {
  passport: () => hexBadge('verified', 28),
  vouch: () => dropIcon(true, 26),
  hire: () => hexBadge('evidence', 28),
};

/** A row of compact shortcuts, so the profile stays short. Each tile: {icon, label, sub, href | onclick}. */
export function quickTiles(tiles) {
  return h('div', { class: 'tiles' }, tiles.map((t) => {
    const inner = [ICONS[t.icon](), h('b', {}, t.label), h('small', {}, t.sub)];
    return t.href ? h('a', { class: 'tile', href: t.href }, ...inner) : h('button', { type: 'button', class: 'tile', onclick: t.onclick }, ...inner);
  }));
}
