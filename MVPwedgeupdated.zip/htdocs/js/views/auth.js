import { h, field, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { brand } from '../honey.js';
import { phoneField } from './phonefield.js';
import { api, store, loadMe, loadMeta, entry, state } from '../api.js';
import { go } from '../ui.js';

const signup = () => (state.meta && state.meta.signup) || { mode: 'sms', sms_live: false };

export function join(roleHint, after) {
  let role = roleHint === 'employer' ? 'employer' : 'worker';
  return step1({ role }, after);
}

/** Invite-only: send people to WhatsApp to ask for their code. */
function whatsappCta() {
  const url = signup().whatsapp;
  if (!url) return '';
  return h('div', { class: 'card honeycard' }, h('b', {}, T.inviteNoCode), h('p', { class: 'hint' }, T.inviteWhatsHint),
    h('a', { class: 'btn', href: url, target: '_blank', rel: 'noopener' }, T.inviteWhatsapp));
}

function agreeRow(d) {
  const box = h('input', { type: 'checkbox', id: 'agree', checked: !!d.accepted });
  box.addEventListener('change', () => { d.accepted = box.checked; });
  return [box, h('div', { class: 'checkrow' }, box, h('label', { for: 'agree' }, T.agreePre + ' ',
    h('a', { href: '/terms', target: '_blank', rel: 'noopener' }, T.termsLink), ' ' + T.and + ' ', h('a', { href: '/privacy', target: '_blank', rel: 'noopener' }, T.privacyLink)))];
}

function step1(d, after) {
  const err = h('div');
  const name = h('input', { type: 'text', autocomplete: 'name', maxlength: 80, value: d.name || '' });
  const phone = phoneField(d.phoneState || {});
  const chips = h('div', { class: 'chips' });
  const draw = () => chips.replaceChildren(...['worker', 'employer'].map((r) =>
    h('button', { type: 'button', class: 'chip', 'aria-pressed': String(d.role === r), onclick: () => { d.role = r; draw(); } }, T[r])));
  draw();
  const mode = signup().mode;
  const keep = () => { d.name = name.value; d.phone = phone.get(); d.phoneState = phone.state(); };
  const [agreeBox, agreeEl] = agreeRow(d);
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      keep();
      if (!agreeBox.checked) throw new Error(T.agreeNeed);
      if (mode === 'invite' || mode === 'open') return after(stepInvite(d, after, mode === 'open'));
      const r = await api('/auth/otp/request', 'POST', { phone: d.phone });
      return after(step2(d, r, after));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, mode === 'invite' || mode === 'open' ? T.continue : T.sendCode);
  return [brand(), h('h1', {}, T.create), mode === 'invite' ? h('p', { class: 'muted' }, T.inviteIntro) : '', mode === 'invite' ? whatsappCta() : '', h('p', {}, T.roleQ), chips,
    ...field(T.name, name), ...phone.nodes, agreeEl, err, btn,
    mode === 'both' ? h('button', { class: 'link block', onclick: () => { keep(); after(stepInvite(d, after)); } }, T.inviteHave) : '',
    h('button', { class: 'btn ghost', onclick: () => go('/') }, T.back)];
}

function step2(d, sent, after) {
  const err = h('div');
  const code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, pattern: '[0-9]*' });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const resend = h('button', { class: 'link', disabled: true });
  let left = sent.resend_after || 60;
  const tick = () => {
    if (!resend.isConnected) return;
    if (left > 0) { resend.textContent = `${T.resendIn} ${left}s`; resend.disabled = true; left--; setTimeout(tick, 1000); }
    else { resend.textContent = T.resend; resend.disabled = false; }
  };
  resend.addEventListener('click', async () => {
    err.replaceChildren(); resend.disabled = true;
    try { const r = await api('/auth/otp/request', 'POST', { phone: d.phone }); left = r.resend_after || 60; err.replaceChildren(note('ok', T.codeSent)); }
    catch (e) { err.replaceChildren(note('err', e.message)); left = (e.data && e.data.retry_after) || 0; }
    tick();
  });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/register', 'POST', { phone: d.phone, code: code.value.trim(), password: pw.value, full_name: d.name, role: d.role, accept_terms: true, ref: entry.ref || undefined });
      entry.clearRef(); store.token = r.token; await loadMe(); go('/');
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.finish);
  const view = [brand(), h('h1', {}, T.create), h('p', {}, T.weSent(d.phone)), sent.dev_note ? note('info', sent.dev_note) : '',
    ...field(T.code, code), ...field(T.password, pw, T.passwordHint), err, btn, resend,
    h('button', { class: 'btn ghost', onclick: () => after(step1(d, after)) }, T.back)];
  setTimeout(tick, 0);
  return view;
}

function stepInvite(d, after, open = false) {
  const err = h('div');
  const code = h('input', { type: 'text', autocapitalize: 'characters', autocomplete: 'off', maxlength: 12, placeholder: T.inviteHint });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/auth/register', 'POST', { phone: d.phone, invite_code: open ? undefined : code.value, password: pw.value, full_name: d.name, role: d.role, accept_terms: true, ref: entry.ref || undefined });
      entry.clearRef(); store.token = r.token; await loadMe(); go('/');
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.finish);
  return [brand(), h('h1', {}, T.create), h('p', { class: 'muted' }, open ? T.openIntro : T.inviteIntro), open ? '' : whatsappCta(), ...(open ? [] : field(T.inviteCode, code)), ...field(T.password, pw, T.passwordHint),
    open ? '' : note('info', T.inviteNote), err, btn,
    signup().mode === 'both' ? h('button', { class: 'link block', onclick: async () => {
      try { const r = await api('/auth/otp/request', 'POST', { phone: d.phone }); after(step2(d, r, after)); } catch (e) { err.replaceChildren(note('err', e.message)); }
    } }, T.smsInstead) : '',
    h('button', { class: 'btn ghost', onclick: () => after(step1(d, after)) }, T.back)];
}

export function loginView() {
  const err = h('div');
  const phone = phoneField();
  const idIn = h('input', { type: 'text', autocomplete: 'username', autocapitalize: 'characters', spellcheck: 'false', placeholder: T.loginIdHint });
  const phoneWrap = h('div', {}, ...phone.nodes);
  const idWrap = h('div', { hidden: true }, ...field(T.loginIdLabel, idIn), h('p', { class: 'hint' }, T.loginIdRisk));
  let idMode = false;
  const swap = h('button', { type: 'button', class: 'link block', onclick: () => {
    idMode = !idMode; phoneWrap.hidden = idMode; idWrap.hidden = !idMode;
    swap.textContent = idMode ? T.loginUsePhone : T.loginUseId;
  } }, T.loginUseId);
  const pw = h('input', { type: 'password', autocomplete: 'current-password', maxlength: 128 });
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try { const r = await api('/auth/login', 'POST', { identifier: idMode ? idIn.value : phone.get(), password: pw.value }); store.token = r.token; await loadMe(); go('/'); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.login);
  return [brand(), h('h1', {}, T.login), phoneWrap, idWrap, ...field(T.password, pw), err, btn,
    h('a', { class: 'link block', href: '#/forgot' }, T.forgot), swap, h('button', { class: 'btn ghost', onclick: () => go('/') }, T.back)];
}

export function forgotView(after) {
  if (!signup().sms_live) {
    return [brand(), h('h1', {}, T.forgotTitle), note('info', T.resetUnavailable), h('button', { class: 'btn', onclick: () => go('/login') }, T.back)];
  }
  const err = h('div');
  const phone = phoneField();
  const send = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(send, true);
    try { const r = await api('/auth/reset/request', 'POST', { phone: phone.get() }); after(codeStep(phone.get(), r)); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(send, false); }
  } }, T.resetSend);
  function codeStep(ph, sent) {
    const e2 = h('div');
    const code = h('input', { type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 6, pattern: '[0-9]*' });
    const pw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
    const fin = h('button', { class: 'btn', onclick: async () => {
      e2.replaceChildren(); setBusy(fin, true);
      try { await api('/auth/reset', 'POST', { phone: ph, code: code.value.trim(), password: pw.value }); after([brand(), note('ok', T.resetDone), h('button', { class: 'btn', onclick: () => go('/login') }, T.login)]); }
      catch (e) { e2.replaceChildren(note('err', e.message)); setBusy(fin, false); }
    } }, T.resetFinish);
    return [brand(), h('h1', {}, T.forgotTitle), h('p', {}, T.weSent(ph)), ...field(T.code, code), ...field(T.resetNew, pw, T.passwordHint), e2, fin,
      h('button', { class: 'btn ghost', onclick: () => go('/login') }, T.back)];
  }
  return [brand(), h('h1', {}, T.forgotTitle), ...phone.nodes, err, send, h('button', { class: 'btn ghost', onclick: () => go('/login') }, T.back)];
}
