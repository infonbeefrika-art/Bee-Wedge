import { h } from '../dom.js';
import { T } from '../strings.js';
import { state } from '../api.js';
import { copyText } from '../format.js';

/**
 * The Beefrika ID card. The ID opens the person's public page (workers with the page on) and can be copied.
 * @param {{worker?: boolean, isPublic?: boolean}} opts
 */
export function idCard({ worker = false, isPublic = false } = {}) {
  const id = state.me.beefrika_id;
  const status = h('p', { class: 'hint idstatus', role: 'status' });
  const idEl = worker && isPublic
    ? h('a', { class: 'bfid', href: '/p/' + id, target: '_blank', rel: 'noopener', 'aria-label': `${id}. ${T.idOpenTip}` }, id)
    : h('button', { type: 'button', class: 'bfid bfidbtn', onclick: async () => {
      status.textContent = worker ? T.idPrivate : (await copyText(id) ? T.idCopied : id);
    } }, id);
  const copy = h('button', { type: 'button', class: 'btn ghost small', onclick: async () => {
    status.textContent = (await copyText(id)) ? T.idCopied : id;
  } }, T.idCopy);
  return h('div', { class: 'card idcard' },
    h('div', {}, h('div', { class: 'muted' }, T.yourId), idEl), copy,
    worker ? h('p', { class: 'idnote' }, T.idNote) : '', status);
}
