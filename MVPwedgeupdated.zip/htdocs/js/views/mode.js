import { h, note } from '../dom.js';
import { T } from '../strings.js';
import { api, loadMe } from '../api.js';
import { go, confirmToast } from '../ui.js';

/** Asks the person to confirm in a toast, then switches between worker mode and employer mode. Returns an error note, or nothing on success. */
export async function switchMode(to) {
  const employer = to === 'employer';
  const yes = await confirmToast({
    title: employer ? T.modeToEmployerTitle : T.modeToWorkerTitle, text: employer ? T.modeToEmployerText : T.modeToWorkerText, yes: T.modeYes, no: T.modeNo,
  });
  if (!yes) return null;
  try {
    await api('/me/mode', 'POST', { mode: to, confirm: true });
    await loadMe();
    go('/');
    return null;
  } catch (e) { return note('err', e.message); }
}

/** Worker screen card: also hire as an employer, with the same ID. */
export function modeToEmployerCard(rerender) {
  return h('section', { class: 'card' }, h('b', {}, T.modeTitle), h('p', { class: 'hint' }, T.modeText),
    h('button', { class: 'btn ghost', onclick: async () => { const n = await switchMode('employer'); if (n) rerender(n); } }, T.modeSwitch));
}

/** Employer screen card for a worker who is acting as an employer: back to worker mode. */
export function modeBackCard(rerender) {
  return h('section', { class: 'card honeycard' }, h('p', {}, T.modeBackText),
    h('button', { class: 'btn ghost', onclick: async () => { const n = await switchMode('worker'); if (n) rerender(n); } }, T.modeBack));
}
