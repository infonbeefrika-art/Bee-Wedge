import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { proofBadge, emptyHive, dropIcon } from '../honey.js';
import { avatarImg } from './avatar.js';
import { api, state } from '../api.js';
import { shell, go } from '../ui.js';
import { buildQuery } from '../format.js';

export function findView() {
  const meta = state.meta;
  const q = h('input', { type: 'search', maxlength: 40, placeholder: T.qHint, enterkeyhint: 'search' });
  const trade = select(meta.trades.map((t) => ({ value: t.id, label: t.name })), '', T.anyTrade);
  const area = select(meta.areas.map((a) => ({ value: a.id, label: a.name })), '', T.anyArea);
  const wtype = select(meta.worker_types.map((k) => ({ value: k, label: T.wtypes[k] })), '', T.anyType);
  const exp = select(meta.experience.map((k) => ({ value: k, label: T.exps[k] })), '', T.anyExp);
  const avail = h('input', { type: 'checkbox', id: 'fa' });
  const ver = h('input', { type: 'checkbox', id: 'fv' });
  const results = h('div', { class: 'results', 'aria-live': 'polite' });
  const more = h('div');
  let page = 1;

  const card = (w) => h('a', { class: 'card worker', href: '#/w/' + w.beefrika_id },
    h('div', { class: 'wtop' }, h('div', { class: 'whead' }, avatarImg(w.avatar, w.name, 48), h('b', {}, w.name)), h('span', { class: 'chip-s ' + (w.availability === 'available' ? 'good' : 'warn') }, T.availShort[w.availability] || '')),
    h('div', { class: 'muted' }, [w.trade, w.area, T.wtypes[w.worker_type], T.exps[w.experience]].filter(Boolean).join(' \u00B7 ')),
    w.headline ? h('p', {}, w.headline) : '',
    h('div', { class: 'evhead' }, proofBadge(w.proof_level)),
    w.vouch_count ? h('div', { class: 'evhead' }, h('span', { class: 'level level-vouch' }, dropIcon(true), h('span', {}, T.vcChip(w.vouch_count)))) : '');

  async function run(reset) {
    if (reset) { page = 1; results.replaceChildren(h('p', { class: 'muted' }, T.searching)); more.replaceChildren(); }
    try {
      const qs = buildQuery({ q: q.value.trim(), trade_id: trade.value, area_id: area.value, worker_type: wtype.value, experience: exp.value, available: avail.checked, verified: ver.checked, page });
      const data = await api('/workers' + qs);
      if (reset) results.replaceChildren();
      if (data.workers.length === 0 && reset) results.append(emptyHive(T.noBees));
      data.workers.forEach((w) => results.append(card(w)));
      more.replaceChildren();
      if (data.has_more) more.append(h('button', { class: 'btn ghost', onclick: () => { page += 1; run(false); } }, T.moreBtn));
    } catch (e) {
      results.replaceChildren(note('err', e.message));
      if (e.data && e.data.code === 'business_profile_incomplete') { go('/business'); }
    }
  }
  const btn = h('button', { class: 'btn', onclick: () => run(true) }, T.search);
  const view = shell('/find',
    h('h1', {}, T.findTitle),
    h('div', { class: 'card filters' }, q, h('div', { class: 'two' }, trade, area),
      h('details', { class: 'more' }, h('summary', {}, T.moreFilters), wtype, exp,
        h('div', { class: 'checkrow' }, avail, h('label', { for: 'fa' }, T.fAvail)),
        h('div', { class: 'checkrow' }, ver, h('label', { for: 'fv' }, T.fVerified))), btn),
    results, more);
  setTimeout(() => run(true), 0);
  return view;
}
