import { h } from '../dom.js';
import { T } from '../strings.js';
import { emptyHive } from '../honey.js';
import { api, state } from '../api.js';
import { shell } from '../ui.js';
import { formatTime, statusLabel } from '../format.js';

export async function requestsView() {
  const { requests } = await api('/requests');
  const role = state.me.role;
  const cards = requests.map((r) => h('a', { class: 'card reqcard', href: '#/r/' + r.id },
    h('div', { class: 'wtop' }, h('b', {}, r.other_name), r.unread ? h('span', { class: 'unread' }, T.newMsgs(r.unread)) : ''),
    h('div', { class: 'muted' }, [r.title, r.trade].filter(Boolean).join(' \u00B7 ')),
    r.last_message ? h('p', { class: 'preview' }, r.last_message) : '',
    h('div', { class: 'wtop' }, h('span', { class: 'chip-s ' + (['accepted', 'hired', 'completed'].includes(r.status) ? 'good' : 'warn') }, statusLabel(T, role, r.status)),
      h('span', { class: 'hint' }, formatTime(r.updated_at)))));
  return shell('/requests', h('h1', {}, T.reqTitle),
    cards.length ? cards : emptyHive(role === 'employer' ? T.reqEmptyEmployer : T.reqEmptyWorker));
}
