import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { idCard } from './idcard.js';
import { avatarBox } from './avatar.js';
import { modeBackCard } from './mode.js';
import { levelBadge } from '../honey.js';
import { api, state, entry } from '../api.js';
import { safeNext } from '../format.js';
import { shell, go } from '../ui.js';
import { trustBadges, evidenceBox, emailBox, passwordBox, idLoginBox, checklistView } from './shared.js';

export async function businessView(flash, rerender) {
  const { profile } = await api('/employer/profile');
  const meta = state.meta;
  const type = select(meta.employer_types.map((t) => ({ value: t, label: T.types[t] })), profile.employer_type, T.choose);
  const name = h('input', { type: 'text', maxlength: 120, value: profile.business_name });
  const area = select(meta.areas.map((a) => ({ value: a.id, label: a.name })), profile.area_id, T.choose);
  const hires = h('input', { type: 'text', maxlength: 120, placeholder: T.bizHiresHint, value: profile.hires_for });
  const where = h('input', { type: 'text', maxlength: 255, placeholder: T.bizWhereHint, value: profile.location_note });
  const assoc = h('input', { type: 'text', maxlength: 120, value: profile.association_name });
  const cac = h('input', { type: 'text', maxlength: 20, value: profile.cac_number });
  const err = h('div');
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/employer/profile', 'PUT', { employer_type: type.value, business_name: name.value, area_id: area.value,
        hires_for: hires.value, location_note: where.value, association_name: assoc.value, cac_number: cac.value });
      if (r.profile.complete && !profile.complete) { const nx = safeNext(entry.next); if (nx) { entry.clearNext(); return go(nx); } return go('/find'); }
      return rerender(note('ok', T.saved));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.save);

  return shell('/business',
    flash || '',
    h('h1', {}, T.bizTitle), h('p', { class: 'muted' }, T.bizIntro),
    state.me.dual ? modeBackCard(rerender) : '',
    avatarBox(rerender, true),
    h('a', { class: 'card bannerlink', href: '#/invoices' }, T.invTitle),
    pageBox(profile, rerender),
    checklistView(profile.checklist, T.bChecklist),
    idCard(),
    h('div', { class: 'card' }, h('div', { class: 'muted' }, T.bizTrust),
      h('div', { class: 'evhead' }, levelBadge(profile.business_trust), h('span', {}, T.bizLevel[profile.business_trust]))),
    h('h2', {}, T.trustTitle), trustBadges(state.me.trust),
    ...field(T.bizType, type), ...field(T.bizName, name, T.bizNameHint), ...field(T.bizArea, area),
    ...field(T.bizHires, hires), ...field(T.bizWhere, where), ...field(T.bizAssoc, assoc), ...field(T.bizCac, cac, T.bizCacHint),
    err, btn, evidenceBox(), emailBox(), passwordBox(), idLoginBox(rerender));
}

/** Switch the public business page on or off and print the QR card. */
function pageBox(profile, rerender) {
  const msg = h('div');
  const on = h('input', { type: 'checkbox', id: 'bizpub', checked: profile.is_public, disabled: !profile.complete && !profile.is_public });
  on.addEventListener('change', async () => {
    msg.replaceChildren();
    try { await api('/employer/page', 'POST', { public: on.checked }); rerender(note('ok', on.checked ? T.bizPageOn : T.bizPageOff)); }
    catch (e) { on.checked = !on.checked; msg.replaceChildren(note('err', e.message)); }
  });
  const url = '/e/' + state.me.beefrika_id;
  return h('section', { class: 'card' }, h('b', {}, T.bizPageTitle), h('p', { class: 'hint' }, T.bizPageText),
    h('div', { class: 'checkrow' }, on, h('label', { for: 'bizpub' }, T.bizPageToggle)),
    !profile.complete && !profile.is_public ? h('p', { class: 'hint' }, T.bizPageNeed) : '', msg,
    profile.is_public ? [h('a', { class: 'btn', href: '#/card?for=employer' }, T.bizQrOpen),
      h('a', { class: 'btn ghost', href: url, target: '_blank', rel: 'noopener' }, T.bizViewPage)] : '');
}
