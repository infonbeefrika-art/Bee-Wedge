import { h, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api, apiUpload, state } from '../api.js';
import { compressImage } from '../imaging.js';

/** Round photo, or the person's initials when there is no photo yet. */
export function avatarImg(url, name, size = 48) {
  const cls = 'avatar' + (size <= 56 ? ' sm' : '');
  if (url) return h('img', { class: cls, src: url, width: size, height: size, alt: '', loading: 'lazy' });
  const parts = String(name || '?').trim().split(/\s+/);
  const initials = ((parts[0] || '?')[0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
  return h('div', { class: cls + ' ph', role: 'img', 'aria-label': name || '' }, initials);
}

/** Profile photo card: shows the photo, lets the person add, change or remove it. */
export function avatarBox(rerender, employer = false) {
  const status = h('div');
  const pick = h('input', { type: 'file', accept: 'image/*', class: 'sr', id: 'avatarfile' });
  const url = state.me.avatar;
  pick.addEventListener('change', async () => {
    const file = pick.files && pick.files[0];
    if (!file) return;
    status.replaceChildren(h('p', { class: 'hint' }, T.avatarSending));
    try {
      const blob = await compressImage(file, 800, 0.85);
      const fd = new FormData();
      fd.append('photo', blob, 'photo.jpg');
      const r = await apiUpload('/me/avatar', fd);
      state.me.avatar = r.avatar;
      rerender(note('ok', T.avatarSaved));
    } catch (e) { status.replaceChildren(note('err', e.message)); }
  });
  const remove = url ? h('button', { type: 'button', class: 'btn ghost small', onclick: async function () {
    setBusy(this, true);
    try { await api('/me/avatar', 'DELETE'); state.me.avatar = null; rerender(note('ok', T.avatarRemoved)); }
    catch (e) { status.replaceChildren(note('err', e.message)); setBusy(this, false); }
  } }, T.avatarRemove) : '';
  return h('section', { class: 'card avatarbox' },
    avatarImg(url, state.me.full_name, 56),
    h('div', {}, h('b', {}, T.avatarTitle),
      h('p', { class: 'hint' }, employer ? T.avatarHintEmployer : T.avatarHint),
      h('label', { class: 'btn ghost small', for: 'avatarfile' }, url ? T.avatarChange : T.avatarAdd), pick, remove),
    status);
}
