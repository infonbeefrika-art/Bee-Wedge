import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { idCard } from './idcard.js';
import { honeyJar, levelBadge, proofBadge } from '../honey.js';
import { avatarBox } from './avatar.js';
import { switchMode } from './mode.js';
import { profileHero, achievements, creditChip, quickTiles } from './hero.js';
import { api, state } from '../api.js';
import { shell } from '../ui.js';
import { trustBadges, evidenceBox, emailBox, passwordBox, idLoginBox, checklistView } from './shared.js';
import { shareCard } from './share.js';

export async function recordView(flash, rerender) {
  const { profile } = await api('/worker/profile');
  let credits = null;
  try { credits = (await api('/me/credits')).balance; } catch (e) { /* credits not set up yet */ }
  let vcount = 0;
  try { vcount = (await api('/me/vouches')).counts.published; } catch (e) { /* vouches not set up yet */ }
  const meta = state.meta;
  const trade = select(meta.trades.map((t) => ({ value: t.id, label: t.name })), profile.primary_trade_id, T.choose);
  const area = select(meta.areas.map((a) => ({ value: a.id, label: a.name })), profile.area_id, T.choose);
  const wtype = select(meta.worker_types.map((k) => ({ value: k, label: T.wtypes[k] })), profile.worker_type, T.choose);
  const exp = select(meta.experience.map((k) => ({ value: k, label: T.exps[k] })), profile.experience, T.choose);
  const erole = select(meta.economic_roles.map((k) => ({ value: k, label: T.eroles[k] })), profile.economic_role, T.choose);
  const headline = h('input', { type: 'text', maxlength: 100, placeholder: T.headlineHint, value: profile.headline });
  const bio = h('textarea', { maxlength: 600 }, profile.bio);
  const avail = select(Object.entries(T.availOpts).map(([k, v]) => ({ value: k, label: v })), profile.availability);
  const disc = h('input', { type: 'checkbox', id: 'disc', checked: profile.is_discoverable });
  const pub = h('input', { type: 'checkbox', id: 'pub', checked: profile.is_public });
  const err = h('div');
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      await api('/worker/profile', 'PUT', { primary_trade_id: trade.value, area_id: area.value, worker_type: wtype.value, experience: exp.value, economic_role: erole.value,
        headline: headline.value, bio: bio.value, availability: avail.value, is_discoverable: disc.checked, is_public: pub.checked });
      return rerender(note('ok', T.saved));
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
  } }, T.save);
  return shell('/record',
    flash || '',
    state.summary && state.summary.todo ? h('a', { class: 'msg info bannerlink', href: '#/requests' }, T.todoBanner(state.summary.todo)) : '',
    profileHero({ name: state.me.full_name, avatar: state.me.avatar, eyebrow: `${T.welcome}, ${state.me.full_name.split(' ')[0]}`, proof: profile.proof_level,
      availability: profile.availability, id: state.me.beefrika_id, headline: profile.headline,
      line: [(meta.trades.find((x) => String(x.id) === String(profile.primary_trade_id)) || {}).name, (meta.areas.find((x) => String(x.id) === String(profile.area_id)) || {}).name, T.wtypes[profile.worker_type]].filter(Boolean).join(' \u00B7 '),
      extra: creditChip(credits),
      stats: [{ value: vcount, label: T.statVouches }, { value: profile.completion + '%', label: T.statProfile }] }),
    quickTiles([{ icon: 'vouch', label: T.tileVouches, sub: String(vcount), href: '#/vouches' }, { icon: 'passport', label: T.tilePassport, sub: T.tilePassportSub, href: '#/passport' },
      { icon: 'hire', label: T.tileHire, sub: T.tileHireSub, onclick: async () => { const n = await switchMode('employer'); if (n) rerender(n); } }]),
    achievements({ photo: state.me.avatar, vouches: vcount, proof: profile.proof_level, completion: profile.completion }),
    avatarBox(rerender),
    h('div', { class: 'jarcard card' }, honeyJar(profile.completion), h('div', {}, h('b', {}, T.jarTitle(profile.completion)), h('p', { class: 'muted' }, T.jarSub))),
    checklistView(profile.checklist, T.checklist),
    idCard({ worker: true, isPublic: profile.is_public }),
    h('h2', {}, T.trustTitle), trustBadges(state.me.trust),
    h('h2', {}, T.proofTitle),
    h('div', { class: 'card' }, h('div', { class: 'evhead' }, proofBadge(profile.proof_level), h('span', { class: 'muted' }, T.proof[profile.proof_level].meaning)),
      h('p', { class: 'hint' }, T.proof[profile.proof_level].next), h('p', { class: 'hint' }, T.proofSoon)),
    h('h2', {}, T.navRecord),
    ...field(T.trade, trade), ...field(T.area, area), ...field(T.wtype, wtype), ...field(T.exp, exp), ...field(T.eroleLabel, erole),
    ...field(T.headline, headline), ...field(T.bio, bio), ...field(T.avail, avail),
    h('div', { class: 'checkrow' }, disc, h('label', { for: 'disc' }, T.discover)),
    h('div', { class: 'checkrow' }, pub, h('label', { for: 'pub' }, T.shareToggle)),
    h('p', { class: 'hint' }, T.discoverNeed), err, btn,
    shareCard(profile, state.me, meta),
    evidenceBox(), emailBox(), passwordBox(), idLoginBox(rerender));
}
