import { h, field, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api, state } from '../api.js';
import { shell, go } from '../ui.js';
import { naira } from '../format.js';
import { creditJar } from '../honey.js';

const home = () => (state.me.role === 'employer' ? '/business' : '/record');
const chip = (status) => h('span', { class: 'chip-s ' + (status === 'paid' ? 'good' : status === 'refunded' ? '' : 'warn') }, T.invStatus[status] || status);

/** Workers: balance, how to buy more, packs, history. Employers never see this screen. */
export async function creditsView(flash, rerender) {
  const d = await api('/me/credits');
  const packs = d.packs.map((p) => h('div', { class: 'card packcard' },
    creditJar(p.hires, 46, 50),
    h('div', { class: 'packinfo' }, h('b', {}, T.crPack(p.hires, p.per_hire)), h('div', { class: 'num' }, naira(p.price))),
    h('button', { class: 'btn small', onclick: async function () {
      setBusy(this, true);
      try { const r = await api('/me/credits/buy', 'POST', { tier: p.tier }); go('/invoice/' + r.invoice_id); }
      catch (e) { setBusy(this, false); rerender(note('err', e.message)); }
    } }, T.crGet)));
  return shell('/record', flash || '', h('h1', {}, T.crTitle),
    h('div', { class: 'card creditshero' }, creditJar(d.balance, 110, 10),
      h('div', {}, h('b', { class: 'bignum' }, T.crBalance(d.balance)), h('p', { class: 'muted' }, T.crJarSub))),
    d.balance < 1 ? h('div', { class: 'msg err' }, T.crNone) : '',
    h('p', { class: 'muted' }, T.crIntro),
    h('h2', {}, T.crHow), h('ol', { class: 'steps' }, T.crSteps.map((s) => h('li', {}, s))),
    h('h2', {}, T.crPacks), ...packs, h('p', { class: 'hint' }, T.crNote),
    h('a', { class: 'btn ghost', href: '#/invoices' }, T.crInvoices),
    h('h2', {}, T.crHistory),
    h('ul', { class: 'plain' }, d.recent.map((r) => h('li', {}, `${r.date} \u00B7 ${T.crReasons[r.reason] || r.reason} (${r.delta > 0 ? '+' : ''}${r.delta})`))),
    h('a', { class: 'btn ghost', href: '#' + home() }, T.back));
}

/** Both roles: my invoices. */
export async function invoicesView() {
  const { items } = await api('/me/invoices');
  const list = items.map((i) => h('a', { class: 'card invlink', href: '#/invoice/' + i.id },
    h('div', { class: 'evhead' }, h('b', {}, i.number), chip(i.status)), h('div', { class: 'muted' }, i.description), h('div', { class: 'num' }, naira(i.amount))));
  return shell(home(), h('h1', {}, T.invTitle), list.length ? list : h('p', { class: 'muted' }, T.invNone),
    state.me.role === 'worker' ? h('a', { class: 'btn ghost', href: '#/credits' }, T.crTitle) : '', h('a', { class: 'btn ghost', href: '#' + home() }, T.back));
}

/** One invoice, with how to pay and (for employers) the refund note. */
export async function invoiceView(id, flash, rerender) {
  const { invoice: v } = await api('/me/invoices/' + id);
  const rows = v.lines.map((l) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, l.label), h('span', {}, l.value)));
  const parts = [flash || '', h('p', { class: 'eyebrow' }, `${T.invNumber} ${v.number}`), h('h1', {}, v.description),
    h('div', { class: 'card invoicedoc' }, h('div', { class: 'evhead' }, chip(v.status), h('span', { class: 'hint' }, `${T.invIssued}: ${v.issued}${v.paid ? ` \u00B7 ${T.invPaidOn}: ${v.paid}` : ''}`)),
      ...rows, h('div', { class: 'kv total' }, h('b', {}, T.invTotal), h('b', { class: 'num' }, naira(v.amount))))];
  if (v.payments_mode === 'test') parts.splice(2, 0, h('div', { class: 'card testbanner' }, h('b', {}, T.payTestBanner)));
  if (v.status === 'unpaid' && v.payments_mode === 'test') {
    let method = 'card';
    const err = h('div');
    const chips = h('div', { class: 'chips' });
    const draw = () => chips.replaceChildren(...Object.entries(T.payMethods).map(([k, l]) =>
      h('button', { type: 'button', class: 'chip', 'aria-pressed': String(method === k), onclick: () => { method = k; draw(); } }, l)));
    draw();
    const run = (outcome, btn) => async () => {
      err.replaceChildren(); setBusy(btn, true);
      try { await api(`/me/invoices/${v.id}/pay-test`, 'POST', { method, outcome }); rerender(note('ok', T.payTestDone)); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    };
    const pay = h('button', { class: 'btn' }, T.payTestBtn(naira(v.amount)));
    const fail = h('button', { class: 'btn ghost' }, T.payTestFail);
    pay.onclick = run('success', pay);
    fail.onclick = run('fail', fail);
    parts.push(h('h2', {}, T.payTestTitle), h('div', { class: 'card' }, h('p', { class: 'hint' }, T.payTestHow), chips, err, pay, fail));
  } else if (v.status === 'unpaid') parts.push(h('h2', {}, T.invHow), h('div', { class: 'card' }, h('p', { class: 'prewrap' }, v.payment), h('p', { class: 'hint' }, T.invUnpaidNote)));
  if (v.receipt) parts.push(h('h2', {}, T.receiptTitle), h('div', { class: 'card invoicedoc' },
    h('div', { class: 'kv' }, h('span', { class: 'muted' }, T.receiptRef), h('b', {}, v.receipt.reference)),
    h('div', { class: 'kv' }, h('span', { class: 'muted' }, T.receiptVia), h('span', {}, T.payMethods[v.receipt.method] || v.receipt.method)),
    h('div', { class: 'kv' }, h('span', { class: 'muted' }, T.invPaidOn), h('span', {}, v.receipt.date)),
    h('p', { class: 'hint' }, T.receiptNote)));
  if (v.kind === 'hire_fee') {
    parts.push(h('h2', {}, T.invRefundTitle), h('div', { class: 'card' }, h('p', {}, T.invRefundText(v.refund_days)),
      v.refund_until && v.status === 'paid' ? h('p', { class: 'hint' }, T.invWindow(v.refund_until)) : ''));
    if (v.can_refund) {
      const reason = h('textarea', { maxlength: 300 });
      const err = h('div');
      const send = h('button', { class: 'btn ghost', onclick: async () => {
        err.replaceChildren(); setBusy(send, true);
        try { await api(`/me/invoices/${v.id}/refund`, 'POST', { reason: reason.value }); rerender(note('ok', T.invAsked)); }
        catch (e) { err.replaceChildren(note('err', e.message)); setBusy(send, false); }
      } }, T.invAskSend);
      parts.push(h('div', { class: 'card' }, h('b', {}, T.invAsk), ...field(T.invReason, reason), err, send));
    }
    if (v.refund_reason) parts.push(h('p', { class: 'hint' }, v.refund_reason));
  } else parts.push(h('p', { class: 'hint' }, T.invNoRefundCredits));
  if (v.admin_note) parts.push(h('p', { class: 'hint' }, v.admin_note));
  parts.push(h('button', { class: 'btn noprint', onclick: () => window.print() }, T.invPrint), h('a', { class: 'btn ghost noprint', href: '#/invoices' }, T.back));
  return shell(home(), ...parts);
}
