import { h } from '../dom.js';
import { T } from '../strings.js';
import { brand } from '../honey.js';
import { qrSvg } from '../qrsvg.js';
import { api, state } from '../api.js';
import { shell } from '../ui.js';
import { publicUrl } from '../format.js';

const nameOf = (list, id) => (list.find((x) => Number(x.id) === Number(id)) || {}).name || null;

/** Printable card with a QR code that opens the worker's public page. */
export async function cardView(kind) {
  if (kind === 'vouch') return vouchCard();
  if (kind === 'employer') return employerCard();
  const { profile } = await api('/worker/profile');
  if (!profile.is_public) {
    return shell('/record', h('h1', {}, T.cardTitle), h('p', { class: 'muted' }, T.cardNeedsPublic), h('a', { class: 'btn', href: '#/record' }, T.cardGoBack));
  }
  const url = publicUrl(location.origin, profile.beefrika_id);
  const where = [nameOf(state.meta.trades, profile.primary_trade_id), nameOf(state.meta.areas, profile.area_id)].filter(Boolean).join(' \u00B7 ');
  return shell('/record',
    h('h1', { class: 'noprint' }, T.cardTitle), h('p', { class: 'muted noprint' }, T.cardTip),
    h('div', { class: 'qrcard' }, brand(), h('h2', { class: 'cardname' }, state.me.full_name), h('p', { class: 'muted' }, where),
      qrSvg(url, 240), h('p', { class: 'cardscan' }, T.cardScan), h('p', { class: 'cardurl' }, url.replace(/^https?:\/\//, '')), h('div', { class: 'bfid' }, profile.beefrika_id)),
    h('button', { class: 'btn noprint', onclick: () => window.print() }, T.cardPrint),
    h('a', { class: 'btn ghost noprint', href: '#/record' }, T.cardGoBack));
}

/** Same card, but the QR opens the customer vouch page. Works even if the public page is off. */
async function vouchCard() {
  const { link } = await api('/me/vouches');
  if (!link) return shell('/vouches', h('h1', {}, T.vcCardTitle), h('p', { class: 'muted' }, T.vcNeedLink), h('a', { class: 'btn', href: '#/vouches' }, T.vcTitle));
  return shell('/vouches',
    h('h1', { class: 'noprint' }, T.vcCardTitle), h('p', { class: 'muted noprint' }, T.vcCardTip),
    h('div', { class: 'qrcard' }, brand(), h('h2', { class: 'cardname' }, state.me.full_name), qrSvg(link.url, 240),
      h('p', { class: 'cardscan' }, T.vcCardScan), h('p', { class: 'cardurl' }, link.url.replace(/^https?:\/\//, ''))),
    h('button', { class: 'btn noprint', onclick: () => window.print() }, T.cardPrint),
    h('a', { class: 'btn ghost noprint', href: '#/vouches' }, T.back));
}

/** The employer's QR card: workers scan it to check the employer before a job. */
async function employerCard() {
  const { profile } = await api('/employer/profile');
  if (!profile.is_public) {
    return shell('/business', h('h1', {}, T.bizQrTitle), h('p', { class: 'muted' }, T.bizQrNeedPublic), h('a', { class: 'btn', href: '#/business' }, T.back));
  }
  const url = location.origin + '/e/' + state.me.beefrika_id;
  const where = [(state.meta.areas.find((a) => String(a.id) === String(profile.area_id)) || {}).name].filter(Boolean).join(' \u00B7 ');
  return shell('/business',
    h('h1', { class: 'noprint' }, T.bizQrTitle), h('p', { class: 'muted noprint' }, T.bizQrTip),
    h('div', { class: 'qrcard' }, brand(), h('h2', { class: 'cardname' }, profile.business_name || state.me.full_name), h('p', { class: 'muted' }, where),
      qrSvg(url, 240), h('p', { class: 'cardscan' }, T.bizQrScan), h('p', { class: 'cardurl' }, url.replace(/^https?:\/\//, '')), h('div', { class: 'bfid' }, state.me.beefrika_id)),
    h('button', { class: 'btn noprint', onclick: () => window.print() }, T.cardPrint),
    h('a', { class: 'btn ghost noprint', href: '#/business' }, T.back));
}
