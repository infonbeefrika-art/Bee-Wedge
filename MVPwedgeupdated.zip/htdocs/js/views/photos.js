import { h } from '../dom.js';
import { photoUrl } from '../api.js';

/** A small photo loaded with the login header. Tap to enlarge. */
export function photoThumb(id, label) {
  const img = h('img', { alt: label || '', class: 'thumbimg', width: 96, height: 96 });
  const btn = h('button', { type: 'button', class: 'thumb', 'aria-label': label || 'Photo', onclick: () => btn.classList.toggle('big') }, img);
  photoUrl(id).then((u) => { img.src = u; }).catch(() => { btn.classList.add('broken'); });
  return btn;
}
