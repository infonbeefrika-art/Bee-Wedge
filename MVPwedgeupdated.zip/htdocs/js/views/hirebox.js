import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api, state } from '../api.js';
import { go } from '../ui.js';
import { naira } from '../format.js';

/** Hiring request form shown on a worker's profile (employers only). */
export function hireBox(w) {
  const unverified = w.trust.verified === 0;
  let type = 'contract';
  const chips = h('div', { class: 'chips' });
  const draw = () => chips.replaceChildren(...['short_gig', 'contract'].map((t) =>
    h('button', { type: 'button', class: 'chip', 'aria-pressed': String(type === t), onclick: () => { type = t; draw(); feeLine(); } }, T[t])));
  const fee = h('p', { class: 'hint' });
  const feeLine = () => {
    const q = w.fee_quotes && w.fee_quotes[type];
    fee.textContent = q ? `${T.feeIfHired}: ${naira(q.fee)} (${q.multiplier}x)` : (w.experience ? '' : T.feeNeedExp);
  };
  draw(); feeLine();

  const title = h('input', { type: 'text', maxlength: 100, placeholder: T.hireJobHint });
  const details = h('textarea', { maxlength: 1000, placeholder: T.hireDetailsHint });
  const hours = h('input', { type: 'text', maxlength: 160, placeholder: T.hireHoursHint });
  const where = h('input', { type: 'text', maxlength: 255 });
  const pay = h('input', { type: 'number', inputmode: 'numeric', min: 1, max: 100000000 });
  const period = select(Object.entries(T.periods).map(([v, l]) => ({ value: v, label: l })), 'per_job');
  const ack = h('input', { type: 'checkbox', id: 'ack' });
  const err = h('div');
  const btn = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(btn, true);
    try {
      const r = await api('/requests', 'POST', {
        worker_id: w.beefrika_id, engagement_type: type, title: title.value, details: details.value, working_hours: hours.value,
        location_note: where.value, pay_offer_ngn: pay.value, pay_period: pay.value ? period.value : '', ack_unverified: ack.checked,
      });
      go('/r/' + r.id);
    } catch (e) {
      const msg = e.message;
      err.replaceChildren(note('err', msg)); setBusy(btn, false);
    }
  } }, T.hireSend);

  return h('section', { class: 'card hirebox' }, h('h2', {}, T.hireTitle),
    h('p', { class: 'muted' }, T.hireType), chips, fee,
    ...field(T.hireJobTitle, title), ...field(T.hireDetails, details), ...field(T.hireHours, hours), ...field(T.hireWhere, where),
    ...field(T.hirePay, pay), ...field(T.hirePeriod, period),
    unverified ? h('div', { class: 'checkrow' }, ack, h('label', { for: 'ack' }, T.hireAck)) : '',
    h('p', { class: 'hint' }, T.hireSafe), err, btn);
}
