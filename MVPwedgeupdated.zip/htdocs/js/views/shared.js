import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { levelBadge } from '../honey.js';
import { api, apiUpload, state, loadMe } from '../api.js';
import { photoThumb } from './photos.js';
import { compressImage } from '../imaging.js';

export function trustBadges(trust) {
  const items = [];
  for (const [key, val] of Object.entries(trust)) {
    const label = (T.trust[key] || {})[val];
    if (label) items.push(h('span', { class: 'chip-s ' + (val === 'verified' ? 'good' : 'warn') }, label));
  }
  return h('div', {}, h('div', { class: 'badges' }, items), h('p', { class: 'hint' }, T.trustNote));
}

/** Proof list + add form. Used by workers (skills, training, past work) and employers (business). */
export function evidenceBox() {
  const isEmployer = state.me.role === 'employer';
  const box = h('section', { class: 'card' });
  async function draw(flash) {
    let data;
    try { data = await api('/me/evidence'); } catch (e) { box.replaceChildren(note('err', e.message)); return; }
    const list = data.items.length === 0
      ? h('p', { class: 'muted' }, T.evNone)
      : h('ul', { class: 'evlist' }, data.items.map((it) => h('li', {},
          h('div', { class: 'evhead' }, levelBadge(it.level), h('b', {}, it.label)),
          h('div', { class: 'hint' }, T.claimTypes[it.claim_type] || it.claim_type),
          it.level === 'verified' ? h('div', { class: 'hint' }, T.confirmedBy(it.source_name || 'Beefrika team')) : '',
          it.detail ? h('div', { class: 'evdetail' }, h('span', { class: 'hint' }, T.evPrivate + ': '), it.detail) : '',
          it.review_note ? h('div', { class: 'msg info' }, it.review_note) : '',
          proofPhotos(it),
          it.level !== 'verified' ? h('button', { class: 'link', onclick: async () => {
            try { await api('/me/evidence/' + it.id, 'DELETE'); draw(); } catch (e) { draw(note('err', e.message)); }
          } }, T.evRemove) : '')));
    const err = h('div');
    const type = select(data.allowed_types.map((t) => ({ value: t, label: T.claimTypes[t] })), data.allowed_types[0]);
    const label = h('input', { type: 'text', maxlength: 80, placeholder: T.evLabelHint });
    const detail = h('textarea', { maxlength: 500, placeholder: T.evDetailHint });
    const btn = h('button', { class: 'btn ghost', onclick: async () => {
      err.replaceChildren(); setBusy(btn, true);
      try { await api('/me/evidence', 'POST', { claim_type: type.value, label: label.value, detail: detail.value }); draw(note('ok', T.evAdded)); }
      catch (e) { err.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    } }, T.evAdd);
    box.replaceChildren(h('h2', {}, isEmployer ? T.evTitleB : T.evTitle), h('p', { class: 'muted' }, isEmployer ? T.evIntroB : T.evIntro),
      flash || '', list,
      ...(data.allowed_types.length > 1 ? field(T.evType, type) : []), ...field(T.evLabel, label), ...field(T.evDetail, detail), err, btn,
      h('p', { class: 'hint' }, T.evMax), h('p', { class: 'hint' }, isEmployer ? T.photoNoteB : T.photoNote));

    function proofPhotos(it) {
      const wrap = h('div', { class: 'photos' });
      for (const id of it.photos || []) {
        const cell = h('span', { class: 'photocell' }, photoThumb(id, it.label));
        if (it.level !== 'verified') {
          cell.append(h('button', { type: 'button', class: 'link tiny', onclick: async () => {
            try { await api('/me/evidence/photos/' + id, 'DELETE'); draw(); } catch (e) { draw(note('err', e.message)); }
          } }, T.removePhoto));
        }
        wrap.append(cell);
      }
      if (it.level !== 'verified' && (it.photos || []).length < 3) {
        const pick = h('input', { type: 'file', accept: 'image/*', class: 'filepick', hidden: true });
        const add = h('button', { type: 'button', class: 'btn ghost small', onclick: () => pick.click() }, T.addPhoto);
        pick.addEventListener('change', async () => {
          const file = pick.files && pick.files[0];
          if (!file) return;
          setBusy(add, true);
          try {
            const blob = await compressImage(file);
            const fd = new FormData();
            fd.append('photo', blob, 'photo.jpg');
            await apiUpload('/me/evidence/' + it.id + '/photos', fd);
            draw(note('ok', T.photoAdded));
          } catch (e) { draw(note('err', e.message)); }
        });
        wrap.append(add, pick);
      }
      return wrap;
    }
  }
  draw();
  return box;
}

export function emailBox() {
  const box = h('section', { class: 'card' });
  const draw = (stage, email, msg) => {
    if (state.me.trust.email === 'verified') { box.replaceChildren(h('b', {}, T.trust.email.verified), h('p', { class: 'muted' }, state.me.email)); return; }
    const em = h('input', { type: 'email', autocomplete: 'email', value: email || '', maxlength: 190 });
    const code = h('input', { type: 'text', inputmode: 'numeric', maxlength: 6, autocomplete: 'one-time-code' });
    const err = h('div'); if (msg) err.append(msg);
    const out = [h('b', {}, T.emailTitle)];
    if (stage === 'enter') {
      const b = h('button', { class: 'btn ghost', onclick: async () => {
        setBusy(b, true);
        try { await api('/me/email/request', 'POST', { email: em.value }); draw('code', em.value.trim().toLowerCase(), note('ok', T.codeSent)); }
        catch (e) { err.replaceChildren(note('err', e.message)); setBusy(b, false); }
      } }, T.emailSend);
      out.push(...field(T.email, em), err, b);
    } else {
      const b = h('button', { class: 'btn', onclick: async () => {
        setBusy(b, true);
        try { await api('/me/email/verify', 'POST', { email, code: code.value.trim() }); await loadMe(); draw(); }
        catch (e) { err.replaceChildren(note('err', e.message)); setBusy(b, false); }
      } }, T.emailConfirm);
      out.push(h('p', { class: 'muted' }, email), ...field(T.emailCode, code), err, b, h('button', { class: 'btn ghost', onclick: () => draw('enter', email) }, T.back));
    }
    box.replaceChildren(...out);
  };
  draw('enter');
  return box;
}

export function passwordBox() {
  const box = h('section', { class: 'card' }, h('b', {}, T.pwTitle));
  const cur = h('input', { type: 'password', autocomplete: 'current-password', maxlength: 128 });
  const nw = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 128 });
  const msg = h('div');
  const btn = h('button', { class: 'btn ghost', onclick: async () => {
    msg.replaceChildren(); setBusy(btn, true);
    try { await api('/me/password', 'POST', { current: cur.value, password: nw.value }); cur.value = ''; nw.value = ''; msg.replaceChildren(note('ok', T.pwDone)); }
    catch (e) { msg.replaceChildren(note('err', e.message)); }
    setBusy(btn, false);
  } }, T.pwSave);
  box.append(...field(T.pwCurrent, cur), ...field(T.pwNew, nw, T.passwordHint), msg, btn);
  return box;
}

/** Opt-in: log in with the Beefrika ID if the phone is lost. Off by default; needs a very strong password; at the person's own risk. */
export function idLoginBox(rerender) {
  const on = !!state.me.id_login;
  const box = h('section', { class: 'card' }, h('b', {}, T.idlTitle), h('p', { class: 'hint' }, T.idlText),
    h('div', { class: 'msg ' + (on ? 'info' : 'ok') + ' idlstate', role: 'status' }, on ? T.idlOn : T.idlOff));
  const msg = h('div');
  if (on) {
    box.append(msg, h('button', { class: 'btn ghost', onclick: async function () {
      setBusy(this, true);
      try { await api('/me/id-login', 'POST', { enable: false }); state.me.id_login = false; rerender(note('ok', T.idlOff)); }
      catch (e) { msg.replaceChildren(note('err', e.message)); setBusy(this, false); }
    } }, T.idlDisable));
  } else {
    const pw = h('input', { type: 'password', autocomplete: 'current-password', maxlength: 128 });
    const btn = h('button', { class: 'btn ghost', onclick: async () => {
      msg.replaceChildren(); setBusy(btn, true);
      try { await api('/me/id-login', 'POST', { enable: true, password: pw.value }); state.me.id_login = true; rerender(note('ok', T.idlOn)); }
      catch (e) { msg.replaceChildren(note('err', e.message)); setBusy(btn, false); }
    } }, T.idlEnable);
    box.append(...field(T.idlConfirm, pw), msg, btn);
  }
  return box;
}

export function checklistView(items, labels) {
  return h('ul', { class: 'check' }, items.map((c) => h('li', { class: c.done ? 'done' : '' }, labels[c.key][c.done ? 1 : 0])));
}
