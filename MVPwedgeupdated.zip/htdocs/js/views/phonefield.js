import { h } from '../dom.js';
import { T } from '../strings.js';
import { state } from '../api.js';

/**
 * Phone number with a country picker (African countries). get() returns the number with the country code in front,
 * for example +2330241234567. The server removes a leading 0 where the country uses one.
 */
export function phoneField(initial = {}) {
  const countries = (state.meta && state.meta.countries) || [{ iso: 'NG', name: 'Nigeria', dial: '234' }];
  const id = 'f_' + Math.random().toString(36).slice(2, 8);
  const sel = h('select', { class: 'dialsel', 'aria-label': T.country }, countries.map((c) => h('option', { value: c.iso, selected: c.iso === (initial.country || 'NG') }, `${c.name} (+${c.dial})`)));
  const input = h('input', { type: 'tel', inputmode: 'tel', autocomplete: 'tel-national', placeholder: T.phoneHint, value: initial.national || '', id });
  return {
    nodes: [h('label', { for: id }, T.phone), h('div', { class: 'phonerow' }, sel, input)],
    country: () => sel.value,
    get: () => {
      const raw = input.value.trim();
      if (/^(\+|00)/.test(raw)) return raw; // typed in full international form
      const dial = (countries.find((c) => c.iso === sel.value) || { dial: '234' }).dial;
      return '+' + dial + raw;
    },
    state: () => ({ country: sel.value, national: input.value }),
  };
}
