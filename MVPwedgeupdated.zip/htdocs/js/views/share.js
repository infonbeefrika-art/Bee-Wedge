import { h } from '../dom.js';
import { T } from '../strings.js';
import { publicUrl, shareText, whatsappLink } from '../format.js';

const nameOf = (list, id) => (list.find((x) => Number(x.id) === Number(id)) || {}).name || null;

/** "Your public page": link, copy, WhatsApp, share sheet, QR card. Shown on the worker's record screen. */
export function shareCard(profile, me, meta) {
  const box = h('section', { class: 'card sharecard' }, h('h2', {}, T.shareTitle));
  if (!profile.is_public) { box.append(h('p', { class: 'muted' }, T.shareOff)); return box; }
  const url = publicUrl(location.origin, profile.beefrika_id);
  const text = shareText(me.full_name, nameOf(meta.trades, profile.primary_trade_id), nameOf(meta.areas, profile.area_id), url);
  const link = h('input', { type: 'text', readonly: true, value: url, 'aria-label': T.shareLink });
  const done = h('span', { class: 'hint', role: 'status' });
  const copy = h('button', { type: 'button', class: 'btn ghost small', onclick: async () => {
    try { await navigator.clipboard.writeText(url); } catch (e) { link.select(); try { document.execCommand('copy'); } catch (e2) { /* user can copy by hand */ } }
    done.textContent = T.shareCopied;
  } }, T.shareCopy);
  const row = [h('a', { class: 'btn', href: whatsappLink(text), target: '_blank', rel: 'noopener' }, T.shareWhatsApp), copy];
  if (navigator.share) row.push(h('button', { type: 'button', class: 'btn ghost small', onclick: () => navigator.share({ title: 'Beefrika', text, url }).catch(() => {}) }, T.shareSend));
  box.append(link, done, ...row, h('a', { class: 'btn ghost', href: '#/card' }, T.sharePrint), h('p', { class: 'hint' }, T.shareHint));
  return box;
}
