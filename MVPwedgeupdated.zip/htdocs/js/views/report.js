import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api } from '../api.js';

/** Small inline "report a problem" panel. target: {target_type: 'user'|'message', target_id} */
export function reportPanel(target, onDone) {
  const box = h('div', { class: 'card reportbox' });
  const reason = select(Object.entries(T.reasons).map(([v, l]) => ({ value: v, label: l })), 'scam');
  const details = h('textarea', { maxlength: 500 });
  const err = h('div');
  const send = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(send, true);
    try {
      await api('/reports', 'POST', { ...target, reason: reason.value, details: details.value });
      box.replaceChildren(note('ok', T.reportDone));
      if (onDone) setTimeout(onDone, 2500);
    } catch (e) { err.replaceChildren(note('err', e.message)); setBusy(send, false); }
  } }, T.reportSend);
  box.append(h('b', {}, T.reportTitle), ...field(T.reportReason, reason), ...field(T.reportDetails, details), err, send,
    h('button', { class: 'btn ghost', onclick: () => { box.remove(); } }, T.back));
  return box;
}
