import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { honeyJar, drops, dropIcon, emptyHive } from '../honey.js';
import { api } from '../api.js';
import { shell } from '../ui.js';
import { whatsappLink } from '../format.js';

const who = (v) => [v.name + (v.area ? ', ' + v.area : ''), v.month].filter(Boolean).join(' \u00B7 ');

/** Vouches as employers and visitors see them (published only). Used on the worker profile an employer opens. */
export function vouchSummary(v) {
  if (!v || v.count === 0) return [h('h2', {}, T.vcPublicTitle), h('p', { class: 'muted' }, T.vcNone)];
  return [
    h('h2', {}, T.vcPublicTitle),
    h('div', { class: 'card' }, h('div', { class: 'evhead' },
      h('span', { class: 'level level-vouch' }, dropIcon(true), h('span', {}, T.vcBadge)), h('span', {}, T.vcOf(v.count, v.average)))),
    h('ul', { class: 'claims' }, v.items.map((i) => h('li', { class: 'vouch' }, drops(i.rating), h('div', {}, h('b', {}, who(i))),
      h('div', { class: 'muted' }, T.vcJobTypes[i.job_type] || ''), i.comment ? h('p', { class: 'prewrap' }, i.comment) : ''))),
    h('p', { class: 'hint' }, T.vcNote),
  ];
}

function flagPanel(v, rerender) {
  const box = h('div', { class: 'card reportbox' });
  const reason = select(Object.entries(T.vcFlagReasons).map(([k, l]) => ({ value: k, label: l })), 'not_a_customer');
  const err = h('div');
  const send = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(send, true);
    try { await api(`/me/vouches/${v.id}/flag`, 'POST', { reason: reason.value }); rerender(note('ok', T.vcReported)); }
    catch (e) { err.replaceChildren(note('err', e.message)); setBusy(send, false); }
  } }, T.vcReportSend);
  box.append(...field(T.vcReportWhy, reason), err, send, h('button', { class: 'btn ghost', onclick: () => box.remove() }, T.back));
  return box;
}

/** Worker screen: get the link, ask on WhatsApp, see vouches. */
export async function vouchesView(flash, rerender) {
  const data = await api('/me/vouches');
  const make = async (rotate) => {
    try { await api('/me/vouches/link', 'POST', rotate ? { rotate: true } : {}); rerender(); }
    catch (e) { rerender(note('err', e.message)); }
  };
  const parts = [flash || '', h('h1', {}, T.vcTitle), h('p', { class: 'muted' }, T.vcIntro)];

  if (!data.link) {
    parts.push(h('button', { class: 'btn', onclick: () => make(false) }, T.vcGet));
  } else {
    const url = data.link.url;
    const link = h('input', { type: 'text', readonly: true, value: url, 'aria-label': T.vcLinkLabel });
    const done = h('span', { class: 'hint', role: 'status' });
    const copy = h('button', { type: 'button', class: 'btn ghost small', onclick: async () => {
      try { await navigator.clipboard.writeText(url); } catch (e) { link.select(); try { document.execCommand('copy'); } catch (e2) { /* copy by hand */ } }
      done.textContent = T.shareCopied;
    } }, T.shareCopy);
    parts.push(h('section', { class: 'card sharecard' }, link, done,
      h('a', { class: 'btn', href: whatsappLink(T.vcMessage(url)), target: '_blank', rel: 'noopener' }, T.vcWhatsApp), copy,
      h('a', { class: 'btn ghost', href: '#/card?for=vouch' }, T.vcPrint),
      h('p', { class: 'hint' }, T.vcOpens(data.link.opens)), h('p', { class: 'hint' }, T.vcHint),
      h('button', { class: 'btn ghost', onclick: () => { if (confirm(T.vcNewAsk)) make(true); } }, T.vcNew)));
  }

  const n = data.counts.published;
  parts.push(h('div', { class: 'jarcard card' }, honeyJar(Math.min(100, n * 20), T.vcJarTitle(Math.min(n, 5))),
    h('div', {}, h('b', {}, T.vcJarTitle(Math.min(n, 5))), h('p', { class: 'muted' }, T.vcJarSub))));
  if (data.counts.waiting) parts.push(h('div', { class: 'msg info' }, T.vcWaiting(data.counts.waiting)));
  parts.push(h('h2', {}, T.vcTitle));
  if (!data.items.length) parts.push(emptyHive(T.vcEmpty));
  else {
    parts.push(h('p', { class: 'muted' }, T.vcCount(n)));
    parts.push(h('ul', { class: 'claims' }, data.items.map((v) => {
      const slot = h('div');
      return h('li', { class: 'vouch' }, drops(v.rating), h('div', {}, h('b', {}, who(v))), h('div', { class: 'muted' }, T.vcJobTypes[v.job_type] || ''),
        v.comment ? h('p', { class: 'prewrap' }, v.comment) : '',
        v.status === 'held' ? h('span', { class: 'chip-s warn' }, T.tr.vWaiting) : '',
        v.flagged ? h('div', { class: 'hint' }, T.vcReported)
          : h('button', { class: 'link tiny', onclick: () => slot.replaceChildren(flagPanel(v, rerender)) }, T.vcReport), slot);
    })));
  }
  return shell('/vouches', ...parts);
}
