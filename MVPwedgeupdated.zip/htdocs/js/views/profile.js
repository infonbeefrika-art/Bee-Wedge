import { h, note } from '../dom.js';
import { T } from '../strings.js';
import { levelBadge, hexBadge, proofBadge } from '../honey.js';
import { profileHero } from './hero.js';
import { api } from '../api.js';
import { shell } from '../ui.js';
import { naira } from '../format.js';
import { api as _api, state } from '../api.js';
import { hireBox } from './hirebox.js';
import { photoThumb } from './photos.js';
import { reportPanel } from './report.js';
import { vouchSummary } from './vouches.js';
import { feedbackSummary } from './feedbackbox.js';

export async function workerProfileView(id) {
  const { worker: w } = await api('/workers/' + id);
  const typeLabel = w.worker_type ? T.wtypes[w.worker_type] : null;
  const expLabel = w.experience ? T.exps[w.experience] : null;
  const detail = (c) => {
    switch (c.detail_code) {
      case 'name_self': return T.claimDetail.name_self;
      case 'area_self': return T.claimDetail.area_self(c.value);
      case 'experience_self': return T.claimDetail.experience_self(typeLabel, expLabel);
      case 'confirmed_by': return T.confirmedBy(c.source || 'Beefrika team');
      default: return T.claimDetail.evidence_only;
    }
  };
  const claims = w.claims.map((c) => h('li', { class: 'claim' },
    h('div', { class: 'evhead' }, levelBadge(c.level), h('b', {}, T.claimNames[c.key] || c.label)),
    h('p', { class: 'muted' }, detail(c)),
    c.photos && c.photos.length ? h('div', { class: 'photos' }, c.photos.map((id) => photoThumb(id, c.label))) : ''));

  const q = w.fee_quotes;
  const feeBox = h('div', { class: 'card' }, h('b', {}, T.feeBoxTitle),
    q ? h('ul', { class: 'plain' }, Object.entries(q).map(([type, v]) => h('li', {}, h('span', {}, `${T.cats[v.category] || ''} \u00B7 ${T[type] || type} (${v.multiplier}x): `), h('b', { class: 'num' }, naira(v.fee)))))
      : h('p', { class: 'muted' }, w.experience ? T.feePending : T.feeNeedExp),
    h('p', { class: 'hint' }, T.feeBoxNote));

  const contact = [
    h('li', {}, w.contact_checks.phone ? T.trust.phone.verified : T.trust.phone.unverified),
    h('li', {}, w.contact_checks.email ? T.trust.email.verified : T.trust.email.not_added),
  ];

  const reportSlot = h('div');
  const reportBtn = h('button', { class: 'link', onclick: () => { reportSlot.replaceChildren(reportPanel({ target_type: 'user', target_id: w.beefrika_id }, () => reportSlot.replaceChildren())); } }, T.reportPerson);
  reportSlot.append(reportBtn);

  return shell('/find',
    h('a', { class: 'link', href: '#/find' }, '\u2190 ' + T.back),
    profileHero({ name: w.name, avatar: w.avatar, line: [w.trade, w.area, typeLabel, expLabel].filter(Boolean).join(' \u00B7 '), proof: w.proof_level,
      availability: w.availability, id: w.beefrika_id, headline: w.headline,
      stats: [{ value: w.vouches ? w.vouches.count : 0, label: T.statVouches }, { value: w.vouches && w.vouches.average !== null ? w.vouches.average : '\u2013', label: T.statDrops }, { value: w.jobs_count || 0, label: T.statJobs }] }),
    h('p', { class: 'hint' }, T.proof[w.proof_level].meaning),
    w.about ? [h('h2', {}, T.profAbout), h('p', { class: 'prewrap' }, w.about)] : '',
    h('h2', {}, T.profRecord), h('ul', { class: 'claims' }, claims),
    h('h2', {}, T.profHistory2),
    w.history.length
      ? [h('p', { class: 'muted' }, T.jobsCount(w.jobs_count)),
         h('ul', { class: 'plain' }, w.history.map((j) => h('li', {}, T.histLine(j.title, j.employer, j.year) + (j.engagement_type ? ` (${T[j.engagement_type] || j.engagement_type})` : '')))),
         h('p', { class: 'hint' }, T.histNote)]
      : h('p', { class: 'muted' }, T.profNoHistory),
    ...vouchSummary(w.vouches),
    ...feedbackSummary(w.feedback),
    h('h2', {}, T.profContact), h('ul', { class: 'plain' }, contact), h('p', { class: 'hint' }, T.contactNote),
    state.me.role === 'employer' ? hireBox(w) : feeBox,
    reportSlot);
}
