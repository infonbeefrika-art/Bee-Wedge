import { h, field, note } from '../dom.js';
import { T } from '../strings.js';
import { state } from '../api.js';
import { shell, go } from '../ui.js';

const ID = /^BF-[A-HJKMNP-Z2-9]{6}$/;

/** Reads a scanned code or typed text. Returns {kind:'worker'|'employer'|'passport', id|path} or null. */
export function parseScan(raw) {
  const text = String(raw || '').trim();
  const typed = text.toUpperCase().replace(/\s+/g, '');
  if (ID.test(typed)) return { kind: 'id', id: typed };
  let url;
  try { url = new URL(text); } catch (e) { return null; }
  if (url.origin !== location.origin) return { kind: 'foreign' };
  const m = url.pathname.match(/^\/(p|e)\/(BF-[A-HJKMNP-Z2-9]{6})$/);
  if (m) return { kind: m[1] === 'p' ? 'worker' : 'employer', id: m[2] };
  if (/^\/pass\/[a-f0-9]{24}$/.test(url.pathname)) return { kind: 'passport', path: url.pathname };
  return { kind: 'foreign' };
}

function open(result, say) {
  if (!result) return say(T.scanBad);
  if (result.kind === 'foreign') return say(T.scanUnknown);
  if (result.kind === 'passport') { location.assign(result.path); return; }
  if (result.kind === 'employer') { location.assign('/e/' + result.id); return; }
  // a worker: employers see the in-app profile, everyone else the public page
  if (state.me.role === 'employer') return go('/w/' + result.id);
  location.assign('/p/' + result.id);
}

export async function scanView() {
  const say = (msg) => msgBox.replaceChildren(note('err', msg));
  const msgBox = h('div');
  const video = h('video', { class: 'scanvideo', playsinline: true, muted: true, hidden: true });
  const canDetect = 'BarcodeDetector' in window && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
  let stream = null;
  let timer = null;
  const stop = () => { if (timer) clearInterval(timer); timer = null; if (stream) stream.getTracks().forEach((t) => t.stop()); stream = null; video.hidden = true; };
  window.addEventListener('hashchange', stop, { once: true });

  const start = h('button', { class: 'btn', onclick: async () => {
    msgBox.replaceChildren();
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      video.srcObject = stream; video.hidden = false; await video.play();
      const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
      timer = setInterval(async () => {
        try {
          const codes = await detector.detect(video);
          if (codes.length) { const res = parseScan(codes[0].rawValue); stop(); open(res, say); }
        } catch (e) { /* keep trying */ }
      }, 300);
    } catch (e) { stop(); say(T.scanDenied); }
  } }, T.scanOpen);

  const typed = h('input', { type: 'text', autocapitalize: 'characters', spellcheck: 'false', placeholder: T.scanTypeHint });
  const asWorker = h('button', { class: 'btn', onclick: () => { const p = parseScan(typed.value); open(p && p.kind === 'id' ? { kind: 'worker', id: p.id } : null, say); } }, T.scanWorker);
  const asEmployer = h('button', { class: 'btn ghost', onclick: () => { const p = parseScan(typed.value); open(p && p.kind === 'id' ? { kind: 'employer', id: p.id } : null, say); } }, T.scanEmployer);

  return shell('/scan', h('h1', {}, T.scanTitle), h('p', { class: 'muted' }, T.scanIntro),
    canDetect ? [video, h('p', { class: 'hint' }, T.scanAim), start, h('button', { class: 'btn ghost', onclick: stop }, T.scanStop)] : h('div', { class: 'msg info' }, T.scanNoCam),
    msgBox, ...field(T.scanType, typed), asWorker, asEmployer);
}
