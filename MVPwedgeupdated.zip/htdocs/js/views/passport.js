import { h, field, note, select, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api } from '../api.js';
import { shell } from '../ui.js';
import { copyText, whatsappLink } from '../format.js';

/** Worker screen: make a Work Passport for one person, see who opened it, switch it off. */
export async function passportView(flash, rerender) {
  const { items } = await api('/me/passports');
  const label = h('input', { type: 'text', maxlength: 60, placeholder: T.ppLabelHint });
  const days = select(Object.entries(T.ppDaysOpts).map(([v, l]) => ({ value: v, label: l })), '30');
  const box = (id, text, on = true) => { const c = h('input', { type: 'checkbox', id, checked: on }); return [c, h('div', { class: 'checkrow' }, c, h('label', { for: id }, text))]; };
  const [jobs, jobsRow] = box('pp-jobs', T.ppJobs);
  const [vouches, vouchesRow] = box('pp-vouches', T.ppVouches);
  const [feedback, feedbackRow] = box('pp-feedback', T.ppFeedback);
  const err = h('div');
  const make = h('button', { class: 'btn', onclick: async () => {
    err.replaceChildren(); setBusy(make, true);
    try { await api('/me/passports', 'POST', { label: label.value, days: Number(days.value), jobs: jobs.checked, vouches: vouches.checked, feedback: feedback.checked }); rerender(note('ok', T.ppMade)); }
    catch (e) { err.append(note('err', e.message)); setBusy(make, false); }
  } }, T.ppMake);

  const list = items.map((p) => {
    const status = h('span', { class: 'hint', role: 'status' });
    const on = p.state === 'on';
    return h('div', { class: 'card' }, h('div', { class: 'evhead' }, h('b', {}, p.label),
      h('span', { class: 'chip-s ' + (on ? 'good' : 'warn') }, p.state === 'on' ? T.ppStateOn : p.state === 'off' ? T.ppStateOff : T.ppStateExpired)),
      h('p', { class: 'hint' }, [T.ppViews(p.views, p.last_viewed), on ? T.ppUntil(p.expires) : ''].filter(Boolean).join('. ')),
      on ? [h('a', { class: 'btn small', href: whatsappLink(T.ppMessage(p.label, p.url)), target: '_blank', rel: 'noopener' }, T.ppSend),
        h('button', { class: 'btn ghost small', onclick: async () => { status.textContent = (await copyText(p.url)) ? T.shareCopied : p.url; } }, T.ppCopy),
        h('a', { class: 'btn ghost small', href: p.url, target: '_blank', rel: 'noopener' }, T.bizViewPage),
        h('button', { class: 'btn ghost small', onclick: async () => {
          if (!window.confirm(T.ppOffAsk)) return;
          try { await api(`/me/passports/${p.id}/revoke`, 'POST', {}); rerender(note('ok', T.ppOffDone)); } catch (e) { status.textContent = e.message; }
        } }, T.ppOff), status] : '');
  });
  return shell('/record', flash || '', h('h1', {}, T.ppTitle), h('p', { class: 'muted' }, T.ppIntro),
    h('section', { class: 'card' }, ...field(T.ppLabel, label), ...field(T.ppDays, days),
      h('p', { class: 'muted' }, T.ppInclude), jobsRow, vouchesRow, feedbackRow, h('p', { class: 'hint' }, T.ppAlways), h('p', { class: 'hint' }, T.ppConsent), err, make),
    h('h2', {}, T.ppYours), list.length ? list : h('p', { class: 'muted' }, T.ppNone),
    h('a', { class: 'btn ghost', href: '#/record' }, T.back));
}
