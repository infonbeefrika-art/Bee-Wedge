import { h, note, setBusy } from '../dom.js';
import { T } from '../strings.js';
import { api } from '../api.js';
import { dropIcon, drops } from '../honey.js';

const line = (row) => [drops(row.rating), row.comment ? h('p', { class: 'prewrap' }, row.comment) : ''];

/** Feedback card on a completed job: leave one rating, see your own and (when open) theirs. */
export function feedbackBox(requestId, fb, rerender) {
  if (!fb) return '';
  const parts = [h('b', {}, fb.can ? T.fbTitle : T.fbMine)];
  if (fb.can) {
    let rating = 0;
    const err = h('div');
    const buttons = [1, 2, 3, 4, 5].map((n) => h('button', { type: 'button', class: 'dropbtn', 'aria-label': `${n}`, 'aria-pressed': 'false', onclick: () => {
      rating = n;
      buttons.forEach((b, i) => { b.setAttribute('aria-pressed', String(i < n)); b.replaceChildren(dropIcon(i < n, 34)); });
    } }, dropIcon(false, 34)));
    const comment = h('input', { type: 'text', maxlength: 160, 'aria-label': T.fbComment, placeholder: T.fbComment });
    const send = h('button', { class: 'btn', onclick: async () => {
      err.replaceChildren();
      if (!rating) { err.append(note('err', T.fbPick)); return; }
      setBusy(send, true);
      try { await api(`/requests/${requestId}/feedback`, 'POST', { rating, comment: comment.value }); rerender(note('ok', T.fbSent)); }
      catch (e) { err.append(note('err', e.message)); setBusy(send, false); }
    } }, T.fbSend);
    parts.push(h('p', { class: 'hint' }, T.fbText), h('div', { class: 'droprow' }, buttons), comment, err, send);
  } else if (fb.mine) {
    parts.push(...line(fb.mine));
  }
  if (fb.theirs) parts.push(h('div', { class: 'divider' }), h('b', {}, T.fbTheirs), ...line(fb.theirs));
  else if (fb.theirs_waiting) parts.push(h('p', { class: 'hint' }, T.fbWaiting));
  return h('section', { class: 'card' }, ...parts);
}

/** Feedback received, as shown on a profile page. */
export function feedbackSummary(f, title = T.fbPublicTitle) {
  if (!f || f.count === 0) return [h('h2', {}, title), h('p', { class: 'muted' }, T.fbNone)];
  return [h('h2', {}, title),
    h('div', { class: 'card' }, h('div', { class: 'evhead' }, h('b', {}, T.fbOf(f.count, f.average)))),
    h('ul', { class: 'claims' }, f.items.map((i) => h('li', { class: 'vouch' }, drops(i.rating),
      h('div', {}, h('b', {}, [i.from, i.month].filter(Boolean).join(' \u00B7 '))), i.comment ? h('p', { class: 'prewrap' }, i.comment) : ''))),
    h('p', { class: 'hint' }, T.fbNote)];
}
